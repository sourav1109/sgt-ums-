export default function App() {
  return <h1>Flipbook will be added here</h1>
}
