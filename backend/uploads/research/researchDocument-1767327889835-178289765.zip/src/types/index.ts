// Type definitions for the IPR Management System

export type UserRole = 'applicant' | 'mentor' | 'drd' | 'dean';

export type SubmissionType = 'patent' | 'research-paper' | 'copyright' | 'book' | 'ipr';

export type SubmissionStatus = 
  | 'draft'
  | 'pending-mentor'
  | 'mentor-review'
  | 'mentor-approved'
  | 'drd-review'
  | 'drd-recommended'
  | 'drd-revision'
  | 'dean-review'
  | 'dean-approved'
  | 'incentive-calculation'
  | 'ipr-filed'
  | 'published'
  | 'certified'
  | 'rejected';

export type IPRType = 'patent' | 'trademark' | 'copyright' | 'design';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  avatar?: string;
}

export interface Submission {
  id: string;
  title: string;
  abstract: string;
  type: SubmissionType;
  status: SubmissionStatus;
  department: string;
  fieldOfInvention: string;
  applicantId: string;
  applicantName: string;
  coAuthors: string[];
  mentorId?: string;
  mentorName?: string;
  mentorStatus?: 'pending' | 'approved' | 'rejected';
  mentorRemarks?: string;
  prototypeStatus: string;
  fundingSource: string;
  stage: string;
  commercialViability: string;
  documents: Document[];
  createdAt: string;
  updatedAt: string;
  timeline: TimelineEvent[];
  drdRemarks?: string;
  deanRemarks?: string;
  assignedReviewer?: string;
  
  // Research Paper specific fields
  researchPaperData?: ResearchPaperData;
  
  // Incentive tracking
  incentives?: IncentiveData;
}

export interface Document {
  id: string;
  name: string;
  type: string;
  size: string;
  uploadedAt: string;
  url: string;
}

export interface TimelineEvent {
  id: string;
  status: string;
  action: string;
  actor: string;
  timestamp: string;
  remarks?: string;
}

export interface IPRRequest {
  id: string;
  submissionId: string;
  submissionTitle: string;
  iprType: IPRType;
  jurisdiction: string;
  budgetEstimate: string;
  legalAdvisor: string;
  priorArtReferences: string[];
  status: 'pending' | 'in-progress' | 'filed' | 'rejected';
  filedDate?: string;
  applicationNumber?: string;
  createdAt: string;
}

export interface Permission {
  view: boolean;
  edit: boolean;
  recommend: boolean;
  approve: boolean;
  delete: boolean;
  grantAdditional: boolean;
  manageForms: boolean;
  viewAnalytics: boolean;
  exportData: boolean;
  expiryDate?: string;
}

export interface ResearchPaperData {
  reqId?: string;
  entryDate: string;
  entryBy: string;
  paperTitle: string;
  journalName: string;
  dateOfPublication: string;
  impactFactor?: string;
  sjrRanking?: string;
  authorNumber: number;
  authorType: 'First Author' | 'Co-Author' | 'Corresponding Author';
  volumeNumber?: string;
  issueNumber?: string;
  pageNumbers?: string;
  publicationPhase: 'Submitted' | 'Under Review' | 'Accepted' | 'Published';
  doi?: string;
  indexing?: string[];
}

export interface IncentiveData {
  bonusPoints: number;
  leavePoints: number;
  monetaryIncentive: string;
  status: 'pending' | 'calculated' | 'approved' | 'disbursed';
  calculatedBy?: string;
  calculatedDate?: string;
  remarks?: string;
}

export interface DRDMember {
  id: string;
  name: string;
  email: string;
  department: string;
  permissions: Permission;
  lastActive: string;
}

export interface Notification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  actionUrl?: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  target: string;
  timestamp: string;
  details: string;
}

export interface DepartmentStats {
  department: string;
  submissions: number;
  approved: number;
  iprFiled: number;
}
