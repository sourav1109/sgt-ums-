import { Badge } from './ui/badge';
import { SubmissionStatus } from '../types';

interface StatusBadgeProps {
  status: SubmissionStatus;
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const getStatusConfig = () => {
    switch (status) {
      case 'draft':
      case 'pending-mentor':
        return { label: 'Pending', className: 'bg-gray-500' };
      case 'mentor-review':
      case 'drd-review':
      case 'dean-review':
        return { label: 'Under Review', className: 'bg-blue-500' };
      case 'drd-recommended':
        return { label: 'Recommended', className: 'bg-yellow-500' };
      case 'mentor-approved':
      case 'dean-approved':
        return { label: 'Approved', className: 'bg-green-500' };
      case 'ipr-filed':
        return { label: 'Filed', className: 'bg-purple-500' };
      case 'drd-revision':
        return { label: 'Revision Required', className: 'bg-orange-500' };
      case 'rejected':
        return { label: 'Rejected', className: 'bg-red-500' };
      default:
        return { label: status, className: 'bg-gray-500' };
    }
  };

  const config = getStatusConfig();

  return (
    <Badge className={`${config.className} text-white hover:${config.className}`}>
      {config.label}
    </Badge>
  );
}
