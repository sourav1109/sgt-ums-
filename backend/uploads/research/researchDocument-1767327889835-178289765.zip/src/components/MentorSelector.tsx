import { useState } from 'react';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { User, Mail, BookOpen, Award } from 'lucide-react';

interface Mentor {
  id: string;
  name: string;
  department: string;
  email?: string;
  expertise?: string[];
  totalGuidance?: number;
  successRate?: number;
}

interface MentorSelectorProps {
  mentors: Mentor[];
  value: string;
  onChange: (mentorId: string) => void;
  filterByDepartment?: string;
}

export function MentorSelector({ mentors, value, onChange, filterByDepartment }: MentorSelectorProps) {
  const [showPreview, setShowPreview] = useState(false);
  
  const filteredMentors = filterByDepartment
    ? mentors.filter(m => m.department === filterByDepartment)
    : mentors;
  
  const selectedMentor = mentors.find(m => m.id === value);

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="mentor">Select Mentor</Label>
        <Select
          value={value}
          onValueChange={(val) => {
            onChange(val);
            setShowPreview(true);
          }}
        >
          <SelectTrigger id="mentor">
            <SelectValue placeholder="Choose a mentor" />
          </SelectTrigger>
          <SelectContent>
            {filteredMentors.map((mentor) => (
              <SelectItem key={mentor.id} value={mentor.id}>
                <div className="flex items-center gap-2">
                  <span>{mentor.name}</span>
                  <span className="text-gray-500 text-sm">- {mentor.department}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <p className="text-sm text-gray-500">
          Mentor approval required before DRD review
        </p>
      </div>

      {selectedMentor && showPreview && (
        <Card className="p-4 bg-blue-50 border-blue-200">
          <div className="flex items-start gap-4">
            <Avatar className="w-12 h-12 bg-[#1A237E]">
              <AvatarFallback className="bg-[#1A237E] text-white">
                {selectedMentor.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 space-y-2">
              <div>
                <h4 className="text-gray-900">{selectedMentor.name}</h4>
                <p className="text-sm text-gray-600">{selectedMentor.department}</p>
              </div>
              
              {selectedMentor.email && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Mail className="w-4 h-4" />
                  <span>{selectedMentor.email}</span>
                </div>
              )}
              
              <div className="flex flex-wrap gap-2">
                {selectedMentor.expertise && selectedMentor.expertise.map((skill, idx) => (
                  <Badge key={idx} variant="outline" className="text-xs">
                    {skill}
                  </Badge>
                ))}
              </div>
              
              <div className="flex gap-6 text-sm">
                {selectedMentor.totalGuidance && (
                  <div className="flex items-center gap-1 text-gray-600">
                    <BookOpen className="w-4 h-4" />
                    <span>{selectedMentor.totalGuidance} students guided</span>
                  </div>
                )}
                {selectedMentor.successRate && (
                  <div className="flex items-center gap-1 text-green-600">
                    <Award className="w-4 h-4" />
                    <span>{selectedMentor.successRate}% success rate</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
