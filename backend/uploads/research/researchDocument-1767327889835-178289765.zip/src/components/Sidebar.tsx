import { 
  LayoutDashboard, 
  FileText, 
  Users, 
  CheckSquare, 
  BarChart3, 
  Settings, 
  Bell,
  LogOut,
  Shield,
  ClipboardList,
  Award,
  FileCheck
} from 'lucide-react';
import { UserRole } from '../types';
import { Button } from './ui/button';

interface SidebarProps {
  role: UserRole;
  activeView: string;
  onViewChange: (view: string) => void;
  onLogout: () => void;
}

export function Sidebar({ role, activeView, onViewChange, onLogout }: SidebarProps) {
  const getMenuItems = () => {
    switch (role) {
      case 'applicant':
        return [
          { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
          { id: 'submissions', label: 'My Submissions', icon: FileText },
          { id: 'new-submission', label: 'New Request', icon: FileCheck },
          { id: 'ipr-requests', label: 'IPR Requests', icon: Award },
          { id: 'notifications', label: 'Notifications', icon: Bell },
        ];
      case 'mentor':
        return [
          { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
          { id: 'pending-reviews', label: 'Pending Reviews', icon: ClipboardList },
          { id: 'mentees', label: 'My Mentees', icon: Users },
          { id: 'notifications', label: 'Notifications', icon: Bell },
        ];
      case 'drd':
        return [
          { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
          { id: 'review-queue', label: 'Review Queue', icon: ClipboardList },
          { id: 'recommended', label: 'Recommended', icon: CheckSquare },
          { id: 'analytics', label: 'Analytics', icon: BarChart3 },
          { id: 'notifications', label: 'Notifications', icon: Bell },
        ];
      case 'dean':
        return [
          { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
          { id: 'approvals', label: 'Approvals', icon: CheckSquare },
          { id: 'permissions', label: 'Permission Management', icon: Shield },
          { id: 'analytics', label: 'Analytics & Reports', icon: BarChart3 },
          { id: 'audit-logs', label: 'Audit Logs', icon: FileText },
          { id: 'notifications', label: 'Notifications', icon: Bell },
        ];
      default:
        return [];
    }
  };

  const menuItems = getMenuItems();

  return (
    <div className="w-64 bg-white border-r border-gray-200 flex flex-col h-screen">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#1A237E] rounded-lg flex items-center justify-center">
            <Award className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-gray-900">IPR Portal</h2>
            <p className="text-sm text-gray-500 capitalize">{role}</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? 'bg-[#1A237E] text-white'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-200">
        <Button
          variant="outline"
          className="w-full justify-start gap-3"
          onClick={onLogout}
        >
          <LogOut className="w-5 h-5" />
          Logout
        </Button>
      </div>
    </div>
  );
}
