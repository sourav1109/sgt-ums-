import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { SubmissionType } from '../types';

interface DynamicFormFieldsProps {
  type: SubmissionType;
  formData: any;
  onChange: (field: string, value: any) => void;
}

export function DynamicFormFields({ type, formData, onChange }: DynamicFormFieldsProps) {
  // Common fields for all types
  const renderCommonFields = () => (
    <>
      <div className="space-y-2">
        <Label htmlFor="title">Title <span className="text-red-500">*</span></Label>
        <Input
          id="title"
          placeholder="Enter submission title"
          value={formData.title || ''}
          onChange={(e) => onChange('title', e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="abstract">Abstract / Description <span className="text-red-500">*</span></Label>
        <Textarea
          id="abstract"
          placeholder="Provide a detailed description"
          rows={4}
          value={formData.abstract || ''}
          onChange={(e) => onChange('abstract', e.target.value)}
          required
        />
      </div>
    </>
  );

  // Research Paper specific fields
  const renderResearchPaperFields = () => (
    <>
      {renderCommonFields()}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="journalName">Journal Name <span className="text-red-500">*</span></Label>
          <Input
            id="journalName"
            placeholder="e.g., IEEE Transactions"
            value={formData.journalName || ''}
            onChange={(e) => onChange('journalName', e.target.value)}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="dateOfPublication">Date of Publication</Label>
          <Input
            id="dateOfPublication"
            type="date"
            value={formData.dateOfPublication || ''}
            onChange={(e) => onChange('dateOfPublication', e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-2">
          <Label htmlFor="impactFactor">Impact Factor</Label>
          <Input
            id="impactFactor"
            placeholder="e.g., 5.2"
            type="number"
            step="0.01"
            value={formData.impactFactor || ''}
            onChange={(e) => onChange('impactFactor', e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="sjrRanking">SJR Ranking</Label>
          <Input
            id="sjrRanking"
            placeholder="e.g., Q1"
            value={formData.sjrRanking || ''}
            onChange={(e) => onChange('sjrRanking', e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="doi">DOI</Label>
          <Input
            id="doi"
            placeholder="e.g., 10.1234/example"
            value={formData.doi || ''}
            onChange={(e) => onChange('doi', e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="authorNumber">Author Position <span className="text-red-500">*</span></Label>
          <Input
            id="authorNumber"
            type="number"
            min="1"
            placeholder="e.g., 1 for first author"
            value={formData.authorNumber || ''}
            onChange={(e) => onChange('authorNumber', e.target.value)}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="authorType">Author Type <span className="text-red-500">*</span></Label>
          <Select
            value={formData.authorType || ''}
            onValueChange={(value) => onChange('authorType', value)}
          >
            <SelectTrigger id="authorType">
              <SelectValue placeholder="Select author type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="First Author">First Author</SelectItem>
              <SelectItem value="Co-Author">Co-Author</SelectItem>
              <SelectItem value="Corresponding Author">Corresponding Author</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-2">
          <Label htmlFor="volumeNumber">Volume Number</Label>
          <Input
            id="volumeNumber"
            placeholder="e.g., 45"
            value={formData.volumeNumber || ''}
            onChange={(e) => onChange('volumeNumber', e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="issueNumber">Issue Number</Label>
          <Input
            id="issueNumber"
            placeholder="e.g., 3"
            value={formData.issueNumber || ''}
            onChange={(e) => onChange('issueNumber', e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="pageNumbers">Page Numbers</Label>
          <Input
            id="pageNumbers"
            placeholder="e.g., 123-145"
            value={formData.pageNumbers || ''}
            onChange={(e) => onChange('pageNumbers', e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="publicationPhase">Publication Phase <span className="text-red-500">*</span></Label>
        <Select
          value={formData.publicationPhase || ''}
          onValueChange={(value) => onChange('publicationPhase', value)}
        >
          <SelectTrigger id="publicationPhase">
            <SelectValue placeholder="Select phase" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Submitted">Submitted</SelectItem>
            <SelectItem value="Under Review">Under Review</SelectItem>
            <SelectItem value="Accepted">Accepted</SelectItem>
            <SelectItem value="Published">Published</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="indexing">Indexing (comma separated)</Label>
        <Input
          id="indexing"
          placeholder="e.g., Scopus, Web of Science, IEEE Xplore"
          value={formData.indexing || ''}
          onChange={(e) => onChange('indexing', e.target.value)}
        />
        <p className="text-sm text-gray-500">
          Enter databases where the paper is indexed
        </p>
      </div>
    </>
  );

  // Patent specific fields
  const renderPatentFields = () => (
    <>
      {renderCommonFields()}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="fieldOfInvention">Field of Invention <span className="text-red-500">*</span></Label>
          <Input
            id="fieldOfInvention"
            placeholder="e.g., Artificial Intelligence"
            value={formData.fieldOfInvention || ''}
            onChange={(e) => onChange('fieldOfInvention', e.target.value)}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="prototypeStatus">Prototype Status <span className="text-red-500">*</span></Label>
          <Select
            value={formData.prototypeStatus || ''}
            onValueChange={(value) => onChange('prototypeStatus', value)}
          >
            <SelectTrigger id="prototypeStatus">
              <SelectValue placeholder="Select status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Conceptual Design">Conceptual Design</SelectItem>
              <SelectItem value="Design Phase">Design Phase</SelectItem>
              <SelectItem value="Proof of Concept">Proof of Concept</SelectItem>
              <SelectItem value="Working Prototype">Working Prototype</SelectItem>
              <SelectItem value="Laboratory Testing">Laboratory Testing</SelectItem>
              <SelectItem value="Pilot Testing">Pilot Testing</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="fundingSource">Funding Source</Label>
          <Input
            id="fundingSource"
            placeholder="e.g., University Research Grant"
            value={formData.fundingSource || ''}
            onChange={(e) => onChange('fundingSource', e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="stage">Development Stage</Label>
          <Select
            value={formData.stage || ''}
            onValueChange={(value) => onChange('stage', value)}
          >
            <SelectTrigger id="stage">
              <SelectValue placeholder="Select stage" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Research Phase">Research Phase</SelectItem>
              <SelectItem value="Development">Development</SelectItem>
              <SelectItem value="Testing">Testing</SelectItem>
              <SelectItem value="Ready for Commercialization">Ready for Commercialization</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="commercialViability">Commercial Viability</Label>
        <Input
          id="commercialViability"
          placeholder="e.g., High - Healthcare Industry"
          value={formData.commercialViability || ''}
          onChange={(e) => onChange('commercialViability', e.target.value)}
        />
      </div>
    </>
  );

  // Copyright/Book specific fields
  const renderCopyrightFields = () => (
    <>
      {renderCommonFields()}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="publisher">Publisher</Label>
          <Input
            id="publisher"
            placeholder="e.g., Springer, Oxford University Press"
            value={formData.publisher || ''}
            onChange={(e) => onChange('publisher', e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="isbn">ISBN / Registration Number</Label>
          <Input
            id="isbn"
            placeholder="e.g., 978-3-16-148410-0"
            value={formData.isbn || ''}
            onChange={(e) => onChange('isbn', e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="publicationDate">Publication Date</Label>
          <Input
            id="publicationDate"
            type="date"
            value={formData.publicationDate || ''}
            onChange={(e) => onChange('publicationDate', e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="copyrightType">Copyright Type</Label>
          <Select
            value={formData.copyrightType || ''}
            onValueChange={(value) => onChange('copyrightType', value)}
          >
            <SelectTrigger id="copyrightType">
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Literary Work">Literary Work</SelectItem>
              <SelectItem value="Artistic Work">Artistic Work</SelectItem>
              <SelectItem value="Software">Software</SelectItem>
              <SelectItem value="Musical Work">Musical Work</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </>
  );

  // IPR specific fields
  const renderIPRFields = () => (
    <>
      {renderCommonFields()}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="iprType">IPR Type <span className="text-red-500">*</span></Label>
          <Select
            value={formData.iprType || ''}
            onValueChange={(value) => onChange('iprType', value)}
          >
            <SelectTrigger id="iprType">
              <SelectValue placeholder="Select IPR type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="patent">Patent</SelectItem>
              <SelectItem value="trademark">Trademark</SelectItem>
              <SelectItem value="copyright">Copyright</SelectItem>
              <SelectItem value="design">Design Registration</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="jurisdiction">Jurisdiction</Label>
          <Input
            id="jurisdiction"
            placeholder="e.g., India (IN), USA (US)"
            value={formData.jurisdiction || ''}
            onChange={(e) => onChange('jurisdiction', e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="budgetEstimate">Budget Estimate</Label>
        <Input
          id="budgetEstimate"
          placeholder="e.g., ₹2,50,000"
          value={formData.budgetEstimate || ''}
          onChange={(e) => onChange('budgetEstimate', e.target.value)}
        />
      </div>
    </>
  );

  // Render fields based on submission type
  switch (type) {
    case 'research-paper':
      return <>{renderResearchPaperFields()}</>;
    case 'patent':
      return <>{renderPatentFields()}</>;
    case 'copyright':
    case 'book':
      return <>{renderCopyrightFields()}</>;
    case 'ipr':
      return <>{renderIPRFields()}</>;
    default:
      return <>{renderCommonFields()}</>;
  }
}
