import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Textarea } from '../ui/textarea';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { CheckCircle, XCircle, AlertCircle, User, FileText, ChevronLeft, ChevronRight } from 'lucide-react';
import { Submission } from '../../types';
import { StatusBadge } from '../StatusBadge';
import { SubmissionTimeline } from '../SubmissionTimeline';
import { Skeleton } from '../ui/skeleton';
import { IncentiveCalculator } from '../IncentiveCalculator';
import { toast } from 'sonner@2.0.3';

interface ReviewQueueProps {
  submissions: Submission[];
}

export function ReviewQueue({ submissions }: ReviewQueueProps) {
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null);
  const [remarks, setRemarks] = useState('');
  const [noveltyScore, setNoveltyScore] = useState('');
  const [feasibilityScore, setFeasibilityScore] = useState('');
  const [assignedReviewer, setAssignedReviewer] = useState('');
  const [filterDepartment, setFilterDepartment] = useState('all');
  const [isLoading, setIsLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const pendingSubmissions = submissions.filter(s => s.status === 'drd-review');

  const filteredSubmissions = filterDepartment === 'all' 
    ? pendingSubmissions
    : pendingSubmissions.filter(s => s.department === filterDepartment);

  // Pagination
  const totalPages = Math.ceil(filteredSubmissions.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedSubmissions = filteredSubmissions.slice(startIndex, startIndex + itemsPerPage);

  const handleRecommend = () => {
    setIsLoading(true);
    setTimeout(() => {
      toast.success('Submission recommended and forwarded to Dean');
      setSelectedSubmission(null);
      resetForm();
      setIsLoading(false);
    }, 1000);
  };

  const handleRevision = () => {
    setIsLoading(true);
    setTimeout(() => {
      toast.warning('Revision request sent to applicant');
      setSelectedSubmission(null);
      resetForm();
      setIsLoading(false);
    }, 1000);
  };

  const handleReject = () => {
    setIsLoading(true);
    setTimeout(() => {
      toast.error('Submission rejected');
      setSelectedSubmission(null);
      resetForm();
      setIsLoading(false);
    }, 1000);
  };

  const resetForm = () => {
    setRemarks('');
    setNoveltyScore('');
    setFeasibilityScore('');
    setAssignedReviewer('');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-gray-900 mb-2">Review Queue</h1>
          <p className="text-gray-600">Evaluate submissions for patent potential and IPR readiness</p>
        </div>
        <Select value={filterDepartment} onValueChange={setFilterDepartment}>
          <SelectTrigger className="w-64">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Departments</SelectItem>
            <SelectItem value="Computer Science">Computer Science</SelectItem>
            <SelectItem value="Electrical Engineering">Electrical Engineering</SelectItem>
            <SelectItem value="Chemical Engineering">Chemical Engineering</SelectItem>
            <SelectItem value="Mechanical Engineering">Mechanical Engineering</SelectItem>
            <SelectItem value="Biotechnology">Biotechnology</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {isLoading ? (
          // Skeleton loader for lazy loading simulation
          Array(3).fill(0).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-6 w-3/4 mb-4" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-2/3" />
              </CardContent>
            </Card>
          ))
        ) : (
          paginatedSubmissions.map((submission) => (
            <Card key={submission.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle>{submission.title}</CardTitle>
                    <p className="text-sm text-gray-600 mt-2">
                      {submission.applicantName} • {submission.department}
                    </p>
                  </div>
                  <StatusBadge status={submission.status} />
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">{submission.abstract}</p>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Field</p>
                    <p className="text-gray-900">{submission.fieldOfInvention}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Stage</p>
                    <p className="text-gray-900">{submission.stage || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Prototype</p>
                    <p className="text-gray-900">{submission.prototypeStatus}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Viability</p>
                    <p className="text-gray-900">{submission.commercialViability}</p>
                  </div>
                </div>

                {submission.mentorName && (
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-sm text-green-800">
                      <User className="w-4 h-4 inline mr-2" />
                      Mentor: {submission.mentorName} (Approved)
                    </p>
                  </div>
                )}

                <Button
                  className="w-full bg-[#1A237E] hover:bg-[#0D47A1]"
                  onClick={() => setSelectedSubmission(submission)}
                >
                  Review Submission
                </Button>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {!isLoading && filteredSubmissions.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <CheckCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600">No submissions in review queue</p>
          </CardContent>
        </Card>
      )}

      <Dialog open={!!selectedSubmission} onOpenChange={() => setSelectedSubmission(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Review Submission</DialogTitle>
          </DialogHeader>
          {selectedSubmission && (
            <Tabs defaultValue="details" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="review">Review</TabsTrigger>
                <TabsTrigger value="timeline">Timeline</TabsTrigger>
              </TabsList>

              <TabsContent value="details" className="space-y-4 mt-4">
                <div>
                  <h3 className="text-gray-900 mb-2">{selectedSubmission.title}</h3>
                  <p className="text-gray-600">{selectedSubmission.abstract}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Applicant</p>
                    <p className="text-gray-900">{selectedSubmission.applicantName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Department</p>
                    <p className="text-gray-900">{selectedSubmission.department}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Field of Invention</p>
                    <p className="text-gray-900">{selectedSubmission.fieldOfInvention}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Mentor</p>
                    <p className="text-gray-900">{selectedSubmission.mentorName || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Prototype Status</p>
                    <p className="text-gray-900">{selectedSubmission.prototypeStatus}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Funding Source</p>
                    <p className="text-gray-900">{selectedSubmission.fundingSource}</p>
                  </div>
                </div>

                {selectedSubmission.documents && selectedSubmission.documents.length > 0 && (
                  <div>
                    <h3 className="text-gray-900 mb-3">Documents</h3>
                    <div className="space-y-2">
                      {selectedSubmission.documents.map((doc) => (
                        <div
                          key={doc.id}
                          className="flex items-center justify-between p-3 border border-gray-200 rounded"
                        >
                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4 text-gray-400" />
                            <div>
                              <p className="text-sm text-gray-900">{doc.name}</p>
                              <p className="text-xs text-gray-500">{doc.size}</p>
                            </div>
                          </div>
                          <Button size="sm" variant="outline">Download</Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="review" className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="novelty">Novelty Assessment</Label>
                    <Select value={noveltyScore} onValueChange={setNoveltyScore}>
                      <SelectTrigger id="novelty">
                        <SelectValue placeholder="Select score" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="feasibility">Feasibility Score</Label>
                    <Select value={feasibilityScore} onValueChange={setFeasibilityScore}>
                      <SelectTrigger id="feasibility">
                        <SelectValue placeholder="Select score" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reviewer">Assign Reviewer (Optional)</Label>
                  <Input
                    id="reviewer"
                    placeholder="Enter reviewer name"
                    value={assignedReviewer}
                    onChange={(e) => setAssignedReviewer(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="remarks">DRD Remarks & Recommendations</Label>
                  <Textarea
                    id="remarks"
                    placeholder="Provide detailed assessment and recommendations..."
                    rows={6}
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                  />
                </div>

                <div className="flex gap-3">
                  <Button
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    onClick={handleRecommend}
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Recommend to Dean
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 text-orange-600 border-orange-600 hover:bg-orange-50"
                    onClick={handleRevision}
                  >
                    <AlertCircle className="w-4 h-4 mr-2" />
                    Request Revision
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 text-red-600 border-red-600 hover:bg-red-50"
                    onClick={handleReject}
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    Reject
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="timeline" className="mt-4">
                <SubmissionTimeline timeline={selectedSubmission.timeline} />
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
