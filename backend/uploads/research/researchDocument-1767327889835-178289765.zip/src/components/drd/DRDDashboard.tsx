import { Card, CardContent } from '../ui/card';
import { ClipboardList, CheckSquare, AlertCircle, TrendingUp } from 'lucide-react';
import { Submission, DepartmentStats } from '../../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface DRDDashboardProps {
  submissions: Submission[];
  departmentStats: DepartmentStats[];
}

export function DRDDashboard({ submissions, departmentStats }: DRDDashboardProps) {
  const pendingReviews = submissions.filter(s => s.status === 'drd-review').length;
  const recommended = submissions.filter(s => s.status === 'drd-recommended').length;
  const revisionsRequested = submissions.filter(s => s.status === 'drd-revision').length;
  const totalProcessed = submissions.filter(s => 
    s.status === 'drd-recommended' || s.status === 'dean-review' || s.status === 'dean-approved'
  ).length;

  const stats = [
    {
      title: 'Pending Reviews',
      value: pendingReviews,
      icon: ClipboardList,
      color: 'bg-blue-500',
    },
    {
      title: 'Recommended',
      value: recommended,
      icon: CheckSquare,
      color: 'bg-green-500',
    },
    {
      title: 'Revisions Requested',
      value: revisionsRequested,
      icon: AlertCircle,
      color: 'bg-orange-500',
    },
    {
      title: 'Total Processed',
      value: totalProcessed,
      icon: TrendingUp,
      color: 'bg-purple-500',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 mb-2">DRD Dashboard</h1>
        <p className="text-gray-600">Research & Development Team - Review & Recommendation Center</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                    <p className="text-gray-900">{stat.value}</p>
                  </div>
                  <div className={`${stat.color} w-12 h-12 rounded-lg flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardContent className="p-6">
          <h2 className="text-gray-900 mb-6">Department-wise Submissions</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={departmentStats}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="department" angle={-45} textAnchor="end" height={100} />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="submissions" fill="#1A237E" name="Total Submissions" />
              <Bar dataKey="approved" fill="#4CAF50" name="Approved" />
              <Bar dataKey="iprFiled" fill="#9C27B0" name="IPR Filed" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <h2 className="text-gray-900 mb-4">Recent Submissions for Review</h2>
          <div className="space-y-3">
            {submissions
              .filter(s => s.status === 'drd-review')
              .slice(0, 5)
              .map((submission) => (
                <div
                  key={submission.id}
                  className="p-4 border border-gray-200 rounded-lg hover:border-[#1A237E] transition-colors cursor-pointer"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-gray-900 mb-1">{submission.title}</h3>
                      <p className="text-sm text-gray-600 mb-2">
                        {submission.applicantName} • {submission.department}
                      </p>
                      <div className="flex items-center gap-2">
                        <span className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded">
                          {submission.type}
                        </span>
                        {submission.mentorName && (
                          <span className="text-xs px-2 py-1 bg-green-100 text-green-700 rounded">
                            Mentor Approved
                          </span>
                        )}
                      </div>
                    </div>
                    <span className="text-sm text-gray-500 whitespace-nowrap ml-4">
                      {new Date(submission.updatedAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
