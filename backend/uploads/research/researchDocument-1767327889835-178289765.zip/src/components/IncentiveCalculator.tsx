import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Award, Coins, Calendar, User } from 'lucide-react';
import { IncentiveData } from '../types';

interface IncentiveCalculatorProps {
  incentives?: IncentiveData;
  submissionType: string;
  compact?: boolean;
}

export function IncentiveCalculator({ incentives, submissionType, compact = false }: IncentiveCalculatorProps) {
  if (!incentives) {
    return (
      <Card className="bg-gray-50">
        <CardContent className="p-4">
          <p className="text-sm text-gray-600 text-center">
            Incentives will be calculated after Dean approval
          </p>
        </CardContent>
      </Card>
    );
  }

  const statusColors = {
    pending: 'bg-yellow-100 text-yellow-800 border-yellow-300',
    calculated: 'bg-blue-100 text-blue-800 border-blue-300',
    approved: 'bg-green-100 text-green-800 border-green-300',
    disbursed: 'bg-purple-100 text-purple-800 border-purple-300',
  };

  if (compact) {
    return (
      <div className="flex items-center gap-4 p-3 bg-gradient-to-r from-amber-50 to-yellow-50 rounded-lg border border-amber-200">
        <Award className="w-5 h-5 text-amber-600" />
        <div className="flex-1 flex items-center gap-6 text-sm">
          <div>
            <span className="text-gray-600">Bonus:</span>
            <span className="ml-1 text-gray-900">{incentives.bonusPoints} pts</span>
          </div>
          <div>
            <span className="text-gray-600">Leave:</span>
            <span className="ml-1 text-gray-900">{incentives.leavePoints} days</span>
          </div>
          <div>
            <span className="text-gray-600">Incentive:</span>
            <span className="ml-1 text-gray-900">{incentives.monetaryIncentive}</span>
          </div>
        </div>
        <Badge className={statusColors[incentives.status]}>
          {incentives.status.charAt(0).toUpperCase() + incentives.status.slice(1)}
        </Badge>
      </div>
    );
  }

  return (
    <Card className="border-2 border-amber-200 bg-gradient-to-br from-amber-50 to-yellow-50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-600" />
            Incentive Calculation
          </CardTitle>
          <Badge className={statusColors[incentives.status]}>
            {incentives.status.charAt(0).toUpperCase() + incentives.status.slice(1)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white rounded-lg p-4 border border-amber-200">
            <div className="flex items-center gap-2 mb-2">
              <Award className="w-4 h-4 text-amber-600" />
              <span className="text-sm text-gray-600">Bonus Points</span>
            </div>
            <p className="text-gray-900">{incentives.bonusPoints} points</p>
          </div>

          <div className="bg-white rounded-lg p-4 border border-amber-200">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-4 h-4 text-blue-600" />
              <span className="text-sm text-gray-600">Leave Points</span>
            </div>
            <p className="text-gray-900">{incentives.leavePoints} days</p>
          </div>

          <div className="bg-white rounded-lg p-4 border border-amber-200">
            <div className="flex items-center gap-2 mb-2">
              <Coins className="w-4 h-4 text-green-600" />
              <span className="text-sm text-gray-600">Monetary Incentive</span>
            </div>
            <p className="text-gray-900">{incentives.monetaryIncentive}</p>
          </div>
        </div>

        {(incentives.calculatedBy || incentives.remarks) && (
          <>
            <Separator />
            <div className="space-y-2">
              {incentives.calculatedBy && (
                <div className="flex items-start gap-2 text-sm">
                  <User className="w-4 h-4 text-gray-500 mt-0.5" />
                  <div>
                    <span className="text-gray-600">Calculated by:</span>
                    <span className="ml-1 text-gray-900">{incentives.calculatedBy}</span>
                    {incentives.calculatedDate && (
                      <span className="ml-2 text-gray-500">on {incentives.calculatedDate}</span>
                    )}
                  </div>
                </div>
              )}
              {incentives.remarks && (
                <p className="text-sm text-gray-600">
                  <span className="font-medium">Remarks:</span> {incentives.remarks}
                </p>
              )}
            </div>
          </>
        )}

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <p className="text-sm text-blue-900">
            <strong>Note:</strong> Incentives are calculated based on journal impact factor, SJR ranking, 
            author position, and publication phase. Final approval required from Dean.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
