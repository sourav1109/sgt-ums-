import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { Submission } from '../../types';
import { StatusBadge } from '../StatusBadge';
import { SubmissionTimeline } from '../SubmissionTimeline';
import { toast } from 'sonner@2.0.3';

interface ApprovalsProps {
  submissions: Submission[];
}

export function Approvals({ submissions }: ApprovalsProps) {
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null);
  const [remarks, setRemarks] = useState('');

  const pendingApprovals = submissions.filter(s => s.status === 'dean-review');

  const handleApprove = () => {
    toast.success('Submission approved. Applicant can now file IPR.');
    setSelectedSubmission(null);
    setRemarks('');
  };

  const handleRevision = () => {
    toast.warning('Revision requested. Notification sent to DRD.');
    setSelectedSubmission(null);
    setRemarks('');
  };

  const handleReject = () => {
    toast.error('Submission rejected.');
    setSelectedSubmission(null);
    setRemarks('');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 mb-2">Pending Approvals</h1>
        <p className="text-gray-600">Review and approve DRD-recommended submissions</p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {pendingApprovals.map((submission) => (
          <Card key={submission.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle>{submission.title}</CardTitle>
                  <p className="text-sm text-gray-600 mt-2">
                    {submission.applicantName} • {submission.department}
                  </p>
                </div>
                <StatusBadge status={submission.status} />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-gray-600 mb-1">Abstract</p>
                <p className="text-gray-900">{submission.abstract}</p>
              </div>

              {submission.drdRemarks && (
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-blue-900">
                    <strong>DRD Recommendation:</strong> {submission.drdRemarks}
                  </p>
                </div>
              )}

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Field</p>
                  <p className="text-gray-900">{submission.fieldOfInvention}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Prototype</p>
                  <p className="text-gray-900">{submission.prototypeStatus}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Commercial Viability</p>
                  <p className="text-gray-900">{submission.commercialViability}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Funding</p>
                  <p className="text-gray-900">{submission.fundingSource}</p>
                </div>
              </div>

              <div className="flex gap-2 pt-4 border-t">
                <Button
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={() => setSelectedSubmission(submission)}
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Review & Approve
                </Button>
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setSelectedSubmission(submission)}
                >
                  View Full Details
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {pendingApprovals.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <CheckCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600">No pending approvals</p>
          </CardContent>
        </Card>
      )}

      <Dialog open={!!selectedSubmission} onOpenChange={() => setSelectedSubmission(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Final Approval Review</DialogTitle>
          </DialogHeader>
          {selectedSubmission && (
            <div className="space-y-6">
              <div>
                <h3 className="text-gray-900 mb-2">{selectedSubmission.title}</h3>
                <p className="text-gray-600">{selectedSubmission.abstract}</p>
              </div>

              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-900">
                  <strong>DRD Recommendation:</strong> {selectedSubmission.drdRemarks || 'Approved by DRD'}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Applicant</p>
                  <p className="text-gray-900">{selectedSubmission.applicantName}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Department</p>
                  <p className="text-gray-900">{selectedSubmission.department}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Mentor</p>
                  <p className="text-gray-900">{selectedSubmission.mentorName || 'N/A'}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Type</p>
                  <p className="text-gray-900">{selectedSubmission.type}</p>
                </div>
              </div>

              <div>
                <h3 className="text-gray-900 mb-3">Submission Timeline</h3>
                <SubmissionTimeline timeline={selectedSubmission.timeline} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="deanRemarks">Dean Remarks</Label>
                <Textarea
                  id="deanRemarks"
                  placeholder="Add your remarks and decision rationale..."
                  rows={4}
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                />
              </div>

              <div className="flex gap-3">
                <Button
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={handleApprove}
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Approve Patent Filing
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 text-orange-600 border-orange-600 hover:bg-orange-50"
                  onClick={handleRevision}
                >
                  <AlertCircle className="w-4 h-4 mr-2" />
                  Request Revision
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 text-red-600 border-red-600 hover:bg-red-50"
                  onClick={handleReject}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Reject
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
