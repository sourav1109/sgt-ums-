import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Checkbox } from '../ui/checkbox';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Shield, Save, Search } from 'lucide-react';
import { DRDMember, Permission } from '../../types';
import { toast } from 'sonner@2.0.3';

interface PermissionManagementProps {
  drdMembers: DRDMember[];
}

export function PermissionManagement({ drdMembers }: PermissionManagementProps) {
  const [members, setMembers] = useState(drdMembers);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredMembers = members.filter(member =>
    member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handlePermissionChange = (
    memberId: string,
    permissionType: keyof Permission,
    value: boolean
  ) => {
    setMembers(members.map(member => {
      if (member.id === memberId) {
        return {
          ...member,
          permissions: {
            ...member.permissions,
            [permissionType]: value
          }
        };
      }
      return member;
    }));
  };

  const handleSavePermissions = () => {
    toast.success('Permissions updated successfully');
    // In a real app, this would save to backend
  };

  const permissionTypes: { key: keyof Permission; label: string }[] = [
    { key: 'view', label: 'View' },
    { key: 'edit', label: 'Edit' },
    { key: 'recommend', label: 'Recommend' },
    { key: 'approve', label: 'Approve' },
    { key: 'delete', label: 'Delete' },
    { key: 'manageForms', label: 'Manage Forms' },
    { key: 'viewAnalytics', label: 'View Analytics' },
    { key: 'exportData', label: 'Export Data' },
    { key: 'grantAdditional', label: 'Grant Additional' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 mb-2">Permission Management</h1>
        <p className="text-gray-600">Manage access rights for DRD members and mentors</p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>DRD Member Permissions</CardTitle>
            <div className="flex items-center gap-4">
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search members..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button
                onClick={handleSavePermissions}
                className="bg-[#1A237E] hover:bg-[#0D47A1]"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-64">Member</TableHead>
                  <TableHead>Department</TableHead>
                  {permissionTypes.map(({ key, label }) => (
                    <TableHead key={key} className="text-center">
                      {label}
                    </TableHead>
                  ))}
                  <TableHead>Last Active</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMembers.map((member) => (
                  <TableRow key={member.id}>
                    <TableCell>
                      <div>
                        <p className="text-gray-900">{member.name}</p>
                        <p className="text-sm text-gray-600">{member.email}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{member.department}</Badge>
                    </TableCell>
                    {permissionTypes.map(({ key }) => (
                      <TableCell key={key} className="text-center">
                        <Checkbox
                          checked={member.permissions[key]}
                          onCheckedChange={(checked) =>
                            handlePermissionChange(member.id, key, checked as boolean)
                          }
                        />
                      </TableCell>
                    ))}
                    <TableCell className="text-sm text-gray-600">
                      {member.lastActive}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Permission Expiry Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-600">
            Set temporary access rights with automatic expiry dates
          </p>
          {filteredMembers.slice(0, 3).map((member) => (
            <div key={member.id} className="flex items-center gap-4 p-4 border border-gray-200 rounded-lg">
              <Shield className="w-8 h-8 text-[#1A237E]" />
              <div className="flex-1">
                <p className="text-gray-900">{member.name}</p>
                <p className="text-sm text-gray-600">{member.department}</p>
              </div>
              <div className="flex items-center gap-2">
                <Label htmlFor={`expiry-${member.id}`} className="text-sm whitespace-nowrap">
                  Expiry Date:
                </Label>
                <Input
                  id={`expiry-${member.id}`}
                  type="date"
                  className="w-40"
                  defaultValue={member.permissions.expiryDate}
                />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Permission Templates</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 border-2 border-gray-200 rounded-lg hover:border-[#1A237E] cursor-pointer transition-colors">
              <h3 className="text-gray-900 mb-2">Reviewer</h3>
              <p className="text-sm text-gray-600 mb-3">View and recommend only</p>
              <div className="space-y-1 text-sm">
                <div className="flex items-center gap-2">
                  <Checkbox checked disabled />
                  <span className="text-gray-700">View</span>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox checked disabled />
                  <span className="text-gray-700">Recommend</span>
                </div>
              </div>
            </div>

            <div className="p-4 border-2 border-gray-200 rounded-lg hover:border-[#1A237E] cursor-pointer transition-colors">
              <h3 className="text-gray-900 mb-2">Senior Reviewer</h3>
              <p className="text-sm text-gray-600 mb-3">Full review capabilities</p>
              <div className="space-y-1 text-sm">
                <div className="flex items-center gap-2">
                  <Checkbox checked disabled />
                  <span className="text-gray-700">View, Edit, Recommend</span>
                </div>
              </div>
            </div>

            <div className="p-4 border-2 border-gray-200 rounded-lg hover:border-[#1A237E] cursor-pointer transition-colors">
              <h3 className="text-gray-900 mb-2">Administrator</h3>
              <p className="text-sm text-gray-600 mb-3">All permissions</p>
              <div className="space-y-1 text-sm">
                <div className="flex items-center gap-2">
                  <Checkbox checked disabled />
                  <span className="text-gray-700">Full Access</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
