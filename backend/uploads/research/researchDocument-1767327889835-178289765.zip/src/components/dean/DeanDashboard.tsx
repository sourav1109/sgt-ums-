import { Card, CardContent } from '../ui/card';
import { FileText, CheckCircle, Award, TrendingUp } from 'lucide-react';
import { Submission, DepartmentStats } from '../../types';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface DeanDashboardProps {
  submissions: Submission[];
  departmentStats: DepartmentStats[];
}

export function DeanDashboard({ submissions, departmentStats }: DeanDashboardProps) {
  const totalSubmissions = submissions.length;
  const activePatents = submissions.filter(s => 
    s.status === 'dean-approved' || s.status === 'drd-recommended'
  ).length;
  const approvedIPRs = submissions.filter(s => s.status === 'ipr-filed').length;
  const pendingApprovals = submissions.filter(s => s.status === 'dean-review').length;

  const stats = [
    {
      title: 'Total Submissions',
      value: totalSubmissions,
      icon: FileText,
      color: 'bg-blue-500',
      change: '+12%',
    },
    {
      title: 'Active Patents',
      value: activePatents,
      icon: CheckCircle,
      color: 'bg-green-500',
      change: '+8%',
    },
    {
      title: 'Approved IPRs',
      value: approvedIPRs,
      icon: Award,
      color: 'bg-purple-500',
      change: '+15%',
    },
    {
      title: 'Pending Approvals',
      value: pendingApprovals,
      icon: TrendingUp,
      color: 'bg-yellow-500',
      change: '-5%',
    },
  ];

  // Mock monthly trend data
  const monthlyData = [
    { month: 'Jan', submissions: 12, approved: 8, iprFiled: 3 },
    { month: 'Feb', submissions: 15, approved: 11, iprFiled: 5 },
    { month: 'Mar', submissions: 18, approved: 13, iprFiled: 6 },
    { month: 'Apr', submissions: 14, approved: 10, iprFiled: 4 },
    { month: 'May', submissions: 20, approved: 15, iprFiled: 7 },
    { month: 'Jun', submissions: 22, approved: 17, iprFiled: 8 },
  ];

  const COLORS = ['#1A237E', '#3F51B5', '#5C6BC0', '#7986CB', '#9FA8DA'];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 mb-2">Dean Dashboard</h1>
        <p className="text-gray-600">University-wide Patent & IPR Management Overview</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`${stat.color} w-12 h-12 rounded-lg flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <span className={`text-sm ${
                    stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {stat.change}
                  </span>
                </div>
                <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                <p className="text-gray-900">{stat.value}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-6">
            <h2 className="text-gray-900 mb-6">Monthly Trends</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="submissions" stroke="#1A237E" strokeWidth={2} name="Submissions" />
                <Line type="monotone" dataKey="approved" stroke="#4CAF50" strokeWidth={2} name="Approved" />
                <Line type="monotone" dataKey="iprFiled" stroke="#9C27B0" strokeWidth={2} name="IPR Filed" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-gray-900 mb-6">Department Performance</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={departmentStats}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ department, submissions }) => `${department.split(' ')[0]}: ${submissions}`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="submissions"
                >
                  {departmentStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-6">
          <h2 className="text-gray-900 mb-6">Department Innovation Statistics</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={departmentStats}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="department" angle={-45} textAnchor="end" height={100} />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="submissions" fill="#1A237E" name="Submissions" />
              <Bar dataKey="approved" fill="#4CAF50" name="Approved" />
              <Bar dataKey="iprFiled" fill="#9C27B0" name="IPR Filed" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <h2 className="text-gray-900 mb-4">Patent-to-IPR Conversion Ratio</h2>
          <div className="space-y-4">
            {departmentStats.map((dept) => {
              const conversionRate = dept.submissions > 0 
                ? ((dept.iprFiled / dept.submissions) * 100).toFixed(1)
                : '0.0';
              return (
                <div key={dept.department}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-700">{dept.department}</span>
                    <span className="text-sm text-gray-900">{conversionRate}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-[#1A237E] h-2 rounded-full"
                      style={{ width: `${conversionRate}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
