import { useState } from 'react';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { Search, Filter, X, ChevronDown } from 'lucide-react';
import { Badge } from './ui/badge';

interface FilterOptions {
  searchQuery: string;
  status: string;
  type: string;
  department: string;
  dateFrom: string;
  dateTo: string;
}

interface AdvancedFiltersProps {
  filters: FilterOptions;
  onFilterChange: (filters: FilterOptions) => void;
  showTypeFilter?: boolean;
  showDepartmentFilter?: boolean;
  showDateFilter?: boolean;
}

export function AdvancedFilters({
  filters,
  onFilterChange,
  showTypeFilter = true,
  showDepartmentFilter = true,
  showDateFilter = true,
}: AdvancedFiltersProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleChange = (key: keyof FilterOptions, value: string) => {
    onFilterChange({ ...filters, [key]: value });
  };

  const handleClearFilters = () => {
    onFilterChange({
      searchQuery: '',
      status: '',
      type: '',
      department: '',
      dateFrom: '',
      dateTo: '',
    });
  };

  const activeFilterCount = Object.values(filters).filter(v => v !== '').length;

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search submissions..."
            className="pl-10"
            value={filters.searchQuery}
            onChange={(e) => handleChange('searchQuery', e.target.value)}
          />
        </div>
        
        <Collapsible open={isOpen} onOpenChange={setIsOpen}>
          <CollapsibleTrigger asChild>
            <Button variant="outline" className="flex items-center gap-2">
              <Filter className="w-4 h-4" />
              <span>Advanced Filters</span>
              {activeFilterCount > 0 && (
                <Badge variant="default" className="ml-1 bg-[#1A237E]">
                  {activeFilterCount}
                </Badge>
              )}
              <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </Button>
          </CollapsibleTrigger>
          
          <CollapsibleContent className="absolute right-0 z-10 mt-2 w-full sm:w-[500px]">
            <Card className="shadow-lg">
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-gray-900">Filter Options</h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleClearFilters}
                    disabled={activeFilterCount === 0}
                  >
                    <X className="w-4 h-4 mr-1" />
                    Clear All
                  </Button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="status">Status</Label>
                    <Select value={filters.status} onValueChange={(value) => handleChange('status', value)}>
                      <SelectTrigger id="status">
                        <SelectValue placeholder="All statuses" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All statuses</SelectItem>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="pending-mentor">Pending Mentor</SelectItem>
                        <SelectItem value="mentor-approved">Mentor Approved</SelectItem>
                        <SelectItem value="drd-review">DRD Review</SelectItem>
                        <SelectItem value="drd-recommended">DRD Recommended</SelectItem>
                        <SelectItem value="dean-review">Dean Review</SelectItem>
                        <SelectItem value="dean-approved">Dean Approved</SelectItem>
                        <SelectItem value="ipr-filed">IPR Filed</SelectItem>
                        <SelectItem value="published">Published</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {showTypeFilter && (
                    <div className="space-y-2">
                      <Label htmlFor="type">Type</Label>
                      <Select value={filters.type} onValueChange={(value) => handleChange('type', value)}>
                        <SelectTrigger id="type">
                          <SelectValue placeholder="All types" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">All types</SelectItem>
                          <SelectItem value="patent">Patent</SelectItem>
                          <SelectItem value="research-paper">Research Paper</SelectItem>
                          <SelectItem value="copyright">Copyright</SelectItem>
                          <SelectItem value="book">Book</SelectItem>
                          <SelectItem value="ipr">IPR</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {showDepartmentFilter && (
                    <div className="space-y-2">
                      <Label htmlFor="department">Department</Label>
                      <Select value={filters.department} onValueChange={(value) => handleChange('department', value)}>
                        <SelectTrigger id="department">
                          <SelectValue placeholder="All departments" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">All departments</SelectItem>
                          <SelectItem value="Computer Science">Computer Science</SelectItem>
                          <SelectItem value="Electrical Engineering">Electrical Engineering</SelectItem>
                          <SelectItem value="Chemical Engineering">Chemical Engineering</SelectItem>
                          <SelectItem value="Mechanical Engineering">Mechanical Engineering</SelectItem>
                          <SelectItem value="Biotechnology">Biotechnology</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {showDateFilter && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="dateFrom">From Date</Label>
                        <Input
                          id="dateFrom"
                          type="date"
                          value={filters.dateFrom}
                          onChange={(e) => handleChange('dateFrom', e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="dateTo">To Date</Label>
                        <Input
                          id="dateTo"
                          type="date"
                          value={filters.dateTo}
                          onChange={(e) => handleChange('dateTo', e.target.value)}
                        />
                      </div>
                    </>
                  )}
                </div>

                <div className="pt-2 border-t">
                  <p className="text-sm text-gray-600">
                    {activeFilterCount} filter{activeFilterCount !== 1 ? 's' : ''} active
                  </p>
                </div>
              </CardContent>
            </Card>
          </CollapsibleContent>
        </Collapsible>
      </div>
    </div>
  );
}
