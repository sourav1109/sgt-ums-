import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Badge } from '../ui/badge';
import { Plus, FileText } from 'lucide-react';
import { IPRRequest, Submission } from '../../types';
import { toast } from 'sonner@2.0.3';

interface IPRRequestsProps {
  iprRequests: IPRRequest[];
  submissions: Submission[];
}

export function IPRRequests({ iprRequests, submissions }: IPRRequestsProps) {
  const [showNewRequest, setShowNewRequest] = useState(false);
  const [formData, setFormData] = useState({
    submissionId: '',
    iprType: 'patent',
    jurisdiction: '',
    budgetEstimate: '',
    legalAdvisor: '',
    priorArtReferences: '',
  });

  const eligibleSubmissions = submissions.filter(
    s => s.status === 'dean-approved' || s.status === 'drd-recommended'
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('IPR filing request submitted successfully!');
    setShowNewRequest(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-gray-900 mb-2">IPR Filing Requests</h1>
          <p className="text-gray-600">Manage your intellectual property rights filing requests</p>
        </div>
        <Button
          onClick={() => setShowNewRequest(true)}
          className="bg-[#1A237E] hover:bg-[#0D47A1]"
        >
          <Plus className="w-4 h-4 mr-2" />
          New IPR Request
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {iprRequests.map((request) => (
          <Card key={request.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <FileText className="w-8 h-8 text-[#1A237E]" />
                <Badge className={
                  request.status === 'filed' ? 'bg-purple-500' :
                  request.status === 'in-progress' ? 'bg-blue-500' :
                  request.status === 'rejected' ? 'bg-red-500' :
                  'bg-yellow-500'
                }>
                  {request.status}
                </Badge>
              </div>
              <CardTitle className="mt-4">{request.iprType.toUpperCase()}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-sm text-gray-600">Submission</p>
                <p className="text-gray-900">{request.submissionTitle}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Jurisdiction</p>
                <p className="text-gray-900">{request.jurisdiction}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Budget Estimate</p>
                <p className="text-gray-900">{request.budgetEstimate}</p>
              </div>
              {request.applicationNumber && (
                <div>
                  <p className="text-sm text-gray-600">Application Number</p>
                  <p className="text-gray-900">{request.applicationNumber}</p>
                </div>
              )}
              <Button variant="outline" className="w-full mt-4">
                View Details
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {iprRequests.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-4">No IPR requests yet</p>
            <Button
              onClick={() => setShowNewRequest(true)}
              className="bg-[#1A237E] hover:bg-[#0D47A1]"
            >
              Create Your First IPR Request
            </Button>
          </CardContent>
        </Card>
      )}

      <Dialog open={showNewRequest} onOpenChange={setShowNewRequest}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>New IPR Filing Request</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="submission">Select Approved Submission</Label>
              <Select
                value={formData.submissionId}
                onValueChange={(value) => setFormData({ ...formData, submissionId: value })}
              >
                <SelectTrigger id="submission">
                  <SelectValue placeholder="Choose a submission" />
                </SelectTrigger>
                <SelectContent>
                  {eligibleSubmissions.map((submission) => (
                    <SelectItem key={submission.id} value={submission.id}>
                      {submission.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="iprType">Type of IPR</Label>
                <Select
                  value={formData.iprType}
                  onValueChange={(value) => setFormData({ ...formData, iprType: value })}
                >
                  <SelectTrigger id="iprType">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="patent">Patent</SelectItem>
                    <SelectItem value="trademark">Trademark</SelectItem>
                    <SelectItem value="copyright">Copyright</SelectItem>
                    <SelectItem value="design">Design</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="jurisdiction">Jurisdiction</Label>
                <Select
                  value={formData.jurisdiction}
                  onValueChange={(value) => setFormData({ ...formData, jurisdiction: value })}
                >
                  <SelectTrigger id="jurisdiction">
                    <SelectValue placeholder="Select jurisdiction" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="India (IN)">India (IN)</SelectItem>
                    <SelectItem value="United States (US)">United States (US)</SelectItem>
                    <SelectItem value="European Union (EU)">European Union (EU)</SelectItem>
                    <SelectItem value="PCT (International)">PCT (International)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="budgetEstimate">Budget Estimate</Label>
              <Input
                id="budgetEstimate"
                placeholder="e.g., ₹2,50,000"
                value={formData.budgetEstimate}
                onChange={(e) => setFormData({ ...formData, budgetEstimate: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="legalAdvisor">Legal Advisor Details</Label>
              <Input
                id="legalAdvisor"
                placeholder="Law firm or advisor name"
                value={formData.legalAdvisor}
                onChange={(e) => setFormData({ ...formData, legalAdvisor: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="priorArt">Prior Art References</Label>
              <Textarea
                id="priorArt"
                placeholder="List relevant patents or publications (one per line)"
                rows={4}
                value={formData.priorArtReferences}
                onChange={(e) => setFormData({ ...formData, priorArtReferences: e.target.value })}
              />
            </div>

            <div className="flex gap-4">
              <Button type="submit" className="bg-[#1A237E] hover:bg-[#0D47A1]">
                Submit IPR Request
              </Button>
              <Button type="button" variant="outline" onClick={() => setShowNewRequest(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
