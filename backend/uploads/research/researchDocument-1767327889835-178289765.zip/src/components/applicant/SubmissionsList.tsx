import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Eye } from 'lucide-react';
import { Submission } from '../../types';
import { StatusBadge } from '../StatusBadge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { SubmissionTimeline } from '../SubmissionTimeline';
import { AdvancedFilters } from '../AdvancedFilters';
import { IncentiveCalculator } from '../IncentiveCalculator';

interface SubmissionsListProps {
  submissions: Submission[];
}

export function SubmissionsList({ submissions }: SubmissionsListProps) {
  const [filters, setFilters] = useState({
    searchQuery: '',
    status: '',
    type: '',
    department: '',
    dateFrom: '',
    dateTo: '',
  });
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null);

  const filteredSubmissions = submissions.filter(submission => {
    const matchesSearch = !filters.searchQuery || 
      submission.title.toLowerCase().includes(filters.searchQuery.toLowerCase()) ||
      submission.abstract.toLowerCase().includes(filters.searchQuery.toLowerCase()) ||
      submission.department.toLowerCase().includes(filters.searchQuery.toLowerCase());
    
    const matchesStatus = !filters.status || submission.status === filters.status;
    const matchesType = !filters.type || submission.type === filters.type;
    const matchesDepartment = !filters.department || submission.department === filters.department;
    
    const matchesDate = (!filters.dateFrom || new Date(submission.createdAt) >= new Date(filters.dateFrom)) &&
                        (!filters.dateTo || new Date(submission.createdAt) <= new Date(filters.dateTo));
    
    return matchesSearch && matchesStatus && matchesType && matchesDepartment && matchesDate;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 mb-2">My Submissions</h1>
        <p className="text-gray-600">Track and manage your patent and IPR submissions</p>
      </div>

      <Card>
        <CardHeader>
          <AdvancedFilters
            filters={filters}
            onFilterChange={setFilters}
            showTypeFilter={true}
            showDepartmentFilter={true}
            showDateFilter={true}
          />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredSubmissions.map((submission) => (
              <div
                key={submission.id}
                className="border border-gray-200 rounded-lg p-4 hover:border-[#1A237E] transition-colors"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="text-gray-900 mb-1">{submission.title}</h3>
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {submission.abstract}
                    </p>
                  </div>
                  <StatusBadge status={submission.status} />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 text-sm text-gray-600 flex-wrap">
                    <span>{submission.department}</span>
                    <span>•</span>
                    <Badge variant="outline" className="capitalize">
                      {submission.type.replace('-', ' ')}
                    </Badge>
                    <span>•</span>
                    <span>Updated {new Date(submission.updatedAt).toLocaleDateString()}</span>
                    {submission.incentives && (
                      <>
                        <span>•</span>
                        <span className="text-amber-600">Incentives: {submission.incentives.monetaryIncentive}</span>
                      </>
                    )}
                  </div>
                  
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setSelectedSubmission(submission)}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    View Details
                  </Button>
                </div>

                {submission.mentorName && (
                  <div className="mt-3 pt-3 border-t border-gray-100">
                    <p className="text-sm text-gray-600">
                      Mentor: <span className="text-gray-900">{submission.mentorName}</span>
                      {submission.mentorStatus && (
                        <span className={`ml-2 ${
                          submission.mentorStatus === 'approved' ? 'text-green-600' :
                          submission.mentorStatus === 'rejected' ? 'text-red-600' :
                          'text-yellow-600'
                        }`}>
                          ({submission.mentorStatus})
                        </span>
                      )}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Dialog open={!!selectedSubmission} onOpenChange={() => setSelectedSubmission(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedSubmission?.title}</DialogTitle>
          </DialogHeader>
          {selectedSubmission && (
            <div className="space-y-6">
              <div>
                <h3 className="text-gray-900 mb-2">Abstract</h3>
                <p className="text-gray-600">{selectedSubmission.abstract}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Department</p>
                  <p className="text-gray-900">{selectedSubmission.department}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Type</p>
                  <Badge variant="outline" className="capitalize">
                    {selectedSubmission.type.replace('-', ' ')}
                  </Badge>
                </div>
                {selectedSubmission.type !== 'research-paper' && (
                  <>
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Field of Invention</p>
                      <p className="text-gray-900">{selectedSubmission.fieldOfInvention}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Prototype Status</p>
                      <p className="text-gray-900">{selectedSubmission.prototypeStatus}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Commercial Viability</p>
                      <p className="text-gray-900">{selectedSubmission.commercialViability}</p>
                    </div>
                  </>
                )}
                {selectedSubmission.type === 'research-paper' && selectedSubmission.researchPaperData && (
                  <>
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Journal Name</p>
                      <p className="text-gray-900">{selectedSubmission.researchPaperData.journalName}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Impact Factor</p>
                      <p className="text-gray-900">{selectedSubmission.researchPaperData.impactFactor || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-1">SJR Ranking</p>
                      <p className="text-gray-900">{selectedSubmission.researchPaperData.sjrRanking || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Author Type</p>
                      <p className="text-gray-900">{selectedSubmission.researchPaperData.authorType}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Publication Phase</p>
                      <Badge>{selectedSubmission.researchPaperData.publicationPhase}</Badge>
                    </div>
                    {selectedSubmission.researchPaperData.doi && (
                      <div>
                        <p className="text-sm text-gray-600 mb-1">DOI</p>
                        <p className="text-gray-900 text-sm">{selectedSubmission.researchPaperData.doi}</p>
                      </div>
                    )}
                  </>
                )}
              </div>

              {selectedSubmission.incentives && (
                <IncentiveCalculator
                  incentives={selectedSubmission.incentives}
                  submissionType={selectedSubmission.type}
                  compact={false}
                />
              )}

              <div>
                <h3 className="text-gray-900 mb-3">Documents</h3>
                <div className="space-y-2">
                  {selectedSubmission.documents.map((doc) => (
                    <div
                      key={doc.id}
                      className="flex items-center justify-between p-3 border border-gray-200 rounded-lg"
                    >
                      <div>
                        <p className="text-gray-900">{doc.name}</p>
                        <p className="text-sm text-gray-600">{doc.type} • {doc.size}</p>
                      </div>
                      <Button size="sm" variant="outline">Download</Button>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-gray-900 mb-3">Submission Timeline</h3>
                <SubmissionTimeline timeline={selectedSubmission.timeline} />
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
