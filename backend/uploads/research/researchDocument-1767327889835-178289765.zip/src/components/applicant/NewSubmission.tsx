import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { toast } from 'sonner@2.0.3';
import { FileUp, Save, AlertCircle } from 'lucide-react';
import { mockMentors } from '../../lib/mock-data';
import { MentorSelector } from '../MentorSelector';
import { DynamicFormFields } from '../DynamicFormFields';
import { Alert, AlertDescription } from '../ui/alert';
import { SubmissionType } from '../../types';

export function NewSubmission() {
  const [formData, setFormData] = useState<any>({
    type: 'patent' as SubmissionType,
    department: '',
    coAuthors: '',
    mentorId: '',
  });

  const [isAutoSaving, setIsAutoSaving] = useState(false);

  const handleFieldChange = (field: string, value: any) => {
    setFormData({ ...formData, [field]: value });
    
    // Auto-save draft simulation
    if (!isAutoSaving) {
      setIsAutoSaving(true);
      setTimeout(() => {
        setIsAutoSaving(false);
      }, 1000);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Submission created successfully!', {
      description: 'Your submission has been sent to the selected mentor for review.'
    });
  };

  const handleSaveDraft = () => {
    toast.success('Draft saved successfully!');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-gray-900 mb-2">New Submission Request</h1>
          <p className="text-gray-600">Submit a new patent, research paper, or IPR filing request</p>
        </div>
        {isAutoSaving && (
          <span className="text-sm text-gray-500 animate-pulse">Auto-saving...</span>
        )}
      </div>

      <Alert className="bg-blue-50 border-blue-200">
        <AlertCircle className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-900">
          All fields marked with <span className="text-red-500">*</span> are mandatory. Your progress is automatically saved as a draft.
        </AlertDescription>
      </Alert>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Submission Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="type">Submission Type <span className="text-red-500">*</span></Label>
                <Select
                  value={formData.type}
                  onValueChange={(value) => {
                    setFormData({ 
                      type: value as SubmissionType, 
                      department: formData.department,
                      coAuthors: formData.coAuthors,
                      mentorId: formData.mentorId,
                    });
                  }}
                >
                  <SelectTrigger id="type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="patent">Patent</SelectItem>
                    <SelectItem value="research-paper">Research Paper</SelectItem>
                    <SelectItem value="copyright">Copyright</SelectItem>
                    <SelectItem value="book">Published Book</SelectItem>
                    <SelectItem value="ipr">IPR Filing</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="department">Department <span className="text-red-500">*</span></Label>
                <Select
                  value={formData.department}
                  onValueChange={(value) => handleFieldChange('department', value)}
                >
                  <SelectTrigger id="department">
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Computer Science">Computer Science</SelectItem>
                    <SelectItem value="Electrical Engineering">Electrical Engineering</SelectItem>
                    <SelectItem value="Chemical Engineering">Chemical Engineering</SelectItem>
                    <SelectItem value="Mechanical Engineering">Mechanical Engineering</SelectItem>
                    <SelectItem value="Biotechnology">Biotechnology</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <DynamicFormFields
              type={formData.type}
              formData={formData}
              onChange={handleFieldChange}
            />

            <div className="space-y-2">
              <Label htmlFor="coAuthors">Co-Authors (comma separated)</Label>
              <Input
                id="coAuthors"
                placeholder="e.g., Dr. John Doe, Jane Smith"
                value={formData.coAuthors}
                onChange={(e) => handleFieldChange('coAuthors', e.target.value)}
              />
            </div>

            <MentorSelector
              mentors={mockMentors.map(m => ({
                ...m,
                email: `${m.name.toLowerCase().replace(/\s+/g, '.')}@university.edu`,
                expertise: ['Innovation', 'Research'],
                totalGuidance: Math.floor(Math.random() * 50) + 10,
                successRate: Math.floor(Math.random() * 30) + 70,
              }))}
              value={formData.mentorId}
              onChange={(value) => handleFieldChange('mentorId', value)}
              filterByDepartment={formData.department}
            />

            <div className="space-y-2">
              <Label>Document Upload</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-[#1A237E] transition-colors cursor-pointer">
                <FileUp className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600 mb-1">
                  Click to upload or drag and drop
                </p>
                <p className="text-xs text-gray-500">
                  PDF, DOC (max. 10MB) - Draft, Drawings, Originality Proof
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <Button type="submit" className="bg-[#1A237E] hover:bg-[#0D47A1]">
                Submit for Review
              </Button>
              <Button type="button" variant="outline" onClick={handleSaveDraft}>
                <Save className="w-4 h-4 mr-2" />
                Save Draft
              </Button>
            </div>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}
