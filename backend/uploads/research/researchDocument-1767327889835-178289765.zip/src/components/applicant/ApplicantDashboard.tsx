import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { FileText, Clock, CheckCircle, Award } from 'lucide-react';
import { Submission } from '../../types';
import { StatusBadge } from '../StatusBadge';

interface ApplicantDashboardProps {
  submissions: Submission[];
}

export function ApplicantDashboard({ submissions }: ApplicantDashboardProps) {
  const totalSubmissions = submissions.length;
  const pendingMentor = submissions.filter(s => 
    s.status === 'pending-mentor' || s.status === 'mentor-review'
  ).length;
  const approved = submissions.filter(s => 
    s.status === 'dean-approved' || s.status === 'mentor-approved'
  ).length;
  const iprFiled = submissions.filter(s => s.status === 'ipr-filed').length;

  const stats = [
    {
      title: 'Total Submissions',
      value: totalSubmissions,
      icon: FileText,
      color: 'bg-blue-500',
    },
    {
      title: 'Pending Mentor Review',
      value: pendingMentor,
      icon: Clock,
      color: 'bg-yellow-500',
    },
    {
      title: 'Approved',
      value: approved,
      icon: CheckCircle,
      color: 'bg-green-500',
    },
    {
      title: 'IPR Filed',
      value: iprFiled,
      icon: Award,
      color: 'bg-purple-500',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 mb-2">Dashboard</h1>
        <p className="text-gray-600">Overview of your patent and IPR submissions</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                    <p className="text-gray-900">{stat.value}</p>
                  </div>
                  <div className={`${stat.color} w-12 h-12 rounded-lg flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Submissions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {submissions.slice(0, 5).map((submission) => (
              <div
                key={submission.id}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-[#1A237E] transition-colors cursor-pointer"
              >
                <div className="flex-1">
                  <h3 className="text-gray-900 mb-1">{submission.title}</h3>
                  <p className="text-sm text-gray-600">
                    {submission.department} • {submission.type}
                  </p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-gray-500">
                    {new Date(submission.updatedAt).toLocaleDateString()}
                  </span>
                  <StatusBadge status={submission.status} />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
