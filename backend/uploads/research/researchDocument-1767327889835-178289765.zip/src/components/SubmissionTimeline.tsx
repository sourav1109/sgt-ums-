import { CheckCircle, Clock, XCircle } from 'lucide-react';
import { TimelineEvent } from '../types';

interface SubmissionTimelineProps {
  timeline: TimelineEvent[];
}

export function SubmissionTimeline({ timeline }: SubmissionTimelineProps) {
  return (
    <div className="relative">
      <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200" />
      
      <div className="space-y-6">
        {timeline.map((event, index) => {
          const isLast = index === timeline.length - 1;
          const Icon = event.status.includes('rejected') ? XCircle :
                      event.status.includes('approved') || event.status.includes('recommended') ? CheckCircle :
                      Clock;
          const iconColor = event.status.includes('rejected') ? 'text-red-500' :
                           event.status.includes('approved') || event.status.includes('recommended') ? 'text-green-500' :
                           'text-blue-500';
          
          return (
            <div key={event.id} className="relative pl-12">
              <div className={`absolute left-0 w-8 h-8 rounded-full flex items-center justify-center ${
                isLast ? 'bg-[#1A237E]' : 'bg-white border-2 border-gray-200'
              }`}>
                <Icon className={`w-5 h-5 ${isLast ? 'text-white' : iconColor}`} />
              </div>
              
              <div>
                <p className="text-gray-900">{event.action}</p>
                <p className="text-sm text-gray-600 mt-1">
                  {event.actor} • {event.timestamp}
                </p>
                {event.remarks && (
                  <p className="text-sm text-gray-700 mt-2 p-3 bg-gray-50 rounded-lg">
                    {event.remarks}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
