import { Card, CardContent } from '../ui/card';
import { Clock, Users, CheckCircle, FileText } from 'lucide-react';
import { Submission } from '../../types';

interface MentorDashboardProps {
  submissions: Submission[];
}

export function MentorDashboard({ submissions }: MentorDashboardProps) {
  const pendingReviews = submissions.filter(s => 
    s.status === 'pending-mentor' || s.status === 'mentor-review'
  ).length;
  
  const activeMentees = new Set(submissions.map(s => s.applicantId)).size;
  const approvedSubmissions = submissions.filter(s => s.mentorStatus === 'approved').length;
  const totalSubmissions = submissions.length;

  const stats = [
    {
      title: 'Pending Reviews',
      value: pendingReviews,
      icon: Clock,
      color: 'bg-yellow-500',
    },
    {
      title: 'Active Mentees',
      value: activeMentees,
      icon: Users,
      color: 'bg-blue-500',
    },
    {
      title: 'Approved',
      value: approvedSubmissions,
      icon: CheckCircle,
      color: 'bg-green-500',
    },
    {
      title: 'Total Submissions',
      value: totalSubmissions,
      icon: FileText,
      color: 'bg-purple-500',
    },
  ];

  const recentSubmissions = submissions
    .filter(s => s.status === 'pending-mentor' || s.status === 'mentor-review')
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 mb-2">Mentor Dashboard</h1>
        <p className="text-gray-600">Review and guide your mentees' research submissions</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                    <p className="text-gray-900">{stat.value}</p>
                  </div>
                  <div className={`${stat.color} w-12 h-12 rounded-lg flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardContent className="p-6">
          <h2 className="text-gray-900 mb-4">Submissions Awaiting Your Review</h2>
          {recentSubmissions.length > 0 ? (
            <div className="space-y-4">
              {recentSubmissions.map((submission) => (
                <div
                  key={submission.id}
                  className="p-4 border border-gray-200 rounded-lg hover:border-[#1A237E] transition-colors cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <h3 className="text-gray-900 mb-1">{submission.title}</h3>
                      <p className="text-sm text-gray-600">
                        By {submission.applicantName} • {submission.department}
                      </p>
                    </div>
                    <span className="text-sm text-gray-500 whitespace-nowrap ml-4">
                      {new Date(submission.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 line-clamp-2 mb-3">
                    {submission.abstract}
                  </p>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded">
                      {submission.type}
                    </span>
                    <span className="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded">
                      {submission.fieldOfInvention}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Clock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-600">No pending reviews at the moment</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
