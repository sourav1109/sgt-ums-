import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Textarea } from '../ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Label } from '../ui/label';
import { CheckCircle, XCircle, FileText } from 'lucide-react';
import { Submission } from '../../types';
import { StatusBadge } from '../StatusBadge';
import { toast } from 'sonner@2.0.3';

interface PendingReviewsProps {
  submissions: Submission[];
}

export function PendingReviews({ submissions }: PendingReviewsProps) {
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null);
  const [comments, setComments] = useState('');
  const [internalNotes, setInternalNotes] = useState('');

  const pendingSubmissions = submissions.filter(
    s => s.status === 'pending-mentor' || s.status === 'mentor-review'
  );

  const handleApprove = () => {
    toast.success('Submission approved and forwarded to DRD');
    setSelectedSubmission(null);
    setComments('');
    setInternalNotes('');
  };

  const handleReject = () => {
    toast.error('Submission rejected. Applicant will be notified.');
    setSelectedSubmission(null);
    setComments('');
    setInternalNotes('');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 mb-2">Pending Reviews</h1>
        <p className="text-gray-600">Review submissions from your mentees</p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {pendingSubmissions.map((submission) => (
          <Card key={submission.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle>{submission.title}</CardTitle>
                  <p className="text-sm text-gray-600 mt-2">
                    Submitted by {submission.applicantName}
                  </p>
                </div>
                <StatusBadge status={submission.status} />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-gray-600 mb-1">Abstract</p>
                <p className="text-gray-900">{submission.abstract}</p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Department</p>
                  <p className="text-gray-900">{submission.department}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Type</p>
                  <p className="text-gray-900">{submission.type}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Field</p>
                  <p className="text-gray-900">{submission.fieldOfInvention}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Stage</p>
                  <p className="text-gray-900">{submission.stage || 'N/A'}</p>
                </div>
              </div>

              {submission.documents && submission.documents.length > 0 && (
                <div>
                  <p className="text-sm text-gray-600 mb-2">Attached Documents</p>
                  <div className="space-y-2">
                    {submission.documents.map((doc) => (
                      <div
                        key={doc.id}
                        className="flex items-center justify-between p-2 border border-gray-200 rounded"
                      >
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-gray-400" />
                          <span className="text-sm">{doc.name}</span>
                        </div>
                        <Button size="sm" variant="outline">View</Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-2 pt-4 border-t">
                <Button
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={() => setSelectedSubmission(submission)}
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Review & Approve
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 text-red-600 border-red-600 hover:bg-red-50"
                  onClick={() => setSelectedSubmission(submission)}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Request Revision
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {pendingSubmissions.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <CheckCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600">No pending reviews</p>
          </CardContent>
        </Card>
      )}

      <Dialog open={!!selectedSubmission} onOpenChange={() => setSelectedSubmission(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Review Submission</DialogTitle>
          </DialogHeader>
          {selectedSubmission && (
            <div className="space-y-6">
              <div>
                <h3 className="text-gray-900 mb-2">{selectedSubmission.title}</h3>
                <p className="text-gray-600">{selectedSubmission.applicantName}</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="comments">Comments for Applicant</Label>
                <Textarea
                  id="comments"
                  placeholder="Provide feedback for the applicant..."
                  rows={4}
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="internalNotes">Internal Notes (Visible to DRD Only)</Label>
                <Textarea
                  id="internalNotes"
                  placeholder="Add notes for DRD review..."
                  rows={3}
                  value={internalNotes}
                  onChange={(e) => setInternalNotes(e.target.value)}
                />
              </div>

              <div className="flex gap-4">
                <Button
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={handleApprove}
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Approve & Forward to DRD
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 text-red-600 border-red-600 hover:bg-red-50"
                  onClick={handleReject}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Request Revision
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
