import { useState } from 'react';
import { Login } from './components/Login';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Notifications } from './components/Notifications';

// Applicant Components
import { ApplicantDashboard } from './components/applicant/ApplicantDashboard';
import { NewSubmission } from './components/applicant/NewSubmission';
import { SubmissionsList } from './components/applicant/SubmissionsList';
import { IPRRequests } from './components/applicant/IPRRequests';

// Mentor Components
import { MentorDashboard } from './components/mentor/MentorDashboard';
import { PendingReviews } from './components/mentor/PendingReviews';

// DRD Components
import { DRDDashboard } from './components/drd/DRDDashboard';
import { ReviewQueue } from './components/drd/ReviewQueue';

// Dean Components
import { DeanDashboard } from './components/dean/DeanDashboard';
import { PermissionManagement } from './components/dean/PermissionManagement';
import { AuditLogs } from './components/dean/AuditLogs';

// Mock Data
import {
  mockUsers,
  mockSubmissions,
  mockIPRRequests,
  mockDRDMembers,
  mockNotifications,
  mockAuditLogs,
  mockDepartmentStats,
} from './lib/mock-data';

import { UserRole } from './types';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentRole, setCurrentRole] = useState<UserRole>('applicant');
  const [activeView, setActiveView] = useState('dashboard');

  const handleLogin = (role: UserRole) => {
    setCurrentRole(role);
    setIsLoggedIn(true);
    setActiveView('dashboard');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentRole('applicant');
    setActiveView('dashboard');
  };

  const getCurrentUser = () => {
    return mockUsers.find(u => u.role === currentRole) || mockUsers[0];
  };

  const renderContent = () => {
    if (activeView === 'notifications') {
      return <Notifications notifications={mockNotifications} />;
    }

    switch (currentRole) {
      case 'applicant':
        switch (activeView) {
          case 'dashboard':
            return <ApplicantDashboard submissions={mockSubmissions} />;
          case 'submissions':
            return <SubmissionsList submissions={mockSubmissions} />;
          case 'new-submission':
            return <NewSubmission />;
          case 'ipr-requests':
            return <IPRRequests iprRequests={mockIPRRequests} submissions={mockSubmissions} />;
          default:
            return <ApplicantDashboard submissions={mockSubmissions} />;
        }

      case 'mentor':
        switch (activeView) {
          case 'dashboard':
            return <MentorDashboard submissions={mockSubmissions} />;
          case 'pending-reviews':
            return <PendingReviews submissions={mockSubmissions} />;
          case 'mentees':
            return (
              <div className="space-y-6">
                <div>
                  <h1 className="text-gray-900 mb-2">My Mentees</h1>
                  <p className="text-gray-600">Track your mentees' progress and submissions</p>
                </div>
                <SubmissionsList submissions={mockSubmissions} />
              </div>
            );
          default:
            return <MentorDashboard submissions={mockSubmissions} />;
        }

      case 'drd':
        switch (activeView) {
          case 'dashboard':
            return <DRDDashboard submissions={mockSubmissions} departmentStats={mockDepartmentStats} />;
          case 'review-queue':
            return <ReviewQueue submissions={mockSubmissions} />;
          case 'recommended':
            return (
              <div className="space-y-6">
                <div>
                  <h1 className="text-gray-900 mb-2">Recommended Submissions</h1>
                  <p className="text-gray-600">Submissions recommended for patent filing</p>
                </div>
                <SubmissionsList 
                  submissions={mockSubmissions.filter(s => 
                    s.status === 'drd-recommended' || s.status === 'dean-review'
                  )} 
                />
              </div>
            );
          case 'analytics':
            return <DRDDashboard submissions={mockSubmissions} departmentStats={mockDepartmentStats} />;
          default:
            return <DRDDashboard submissions={mockSubmissions} departmentStats={mockDepartmentStats} />;
        }

      case 'dean':
        switch (activeView) {
          case 'dashboard':
            return <DeanDashboard submissions={mockSubmissions} departmentStats={mockDepartmentStats} />;
          case 'approvals':
            return (
              <div className="space-y-6">
                <div>
                  <h1 className="text-gray-900 mb-2">Pending Approvals</h1>
                  <p className="text-gray-600">Review and approve DRD-recommended submissions</p>
                </div>
                <ReviewQueue 
                  submissions={mockSubmissions.filter(s => s.status === 'dean-review')} 
                />
              </div>
            );
          case 'permissions':
            return <PermissionManagement drdMembers={mockDRDMembers} />;
          case 'analytics':
            return <DeanDashboard submissions={mockSubmissions} departmentStats={mockDepartmentStats} />;
          case 'audit-logs':
            return <AuditLogs logs={mockAuditLogs} />;
          default:
            return <DeanDashboard submissions={mockSubmissions} departmentStats={mockDepartmentStats} />;
        }

      default:
        return <div>Invalid role</div>;
    }
  };

  if (!isLoggedIn) {
    return (
      <>
        <Login onLogin={handleLogin} />
        <Toaster />
      </>
    );
  }

  const currentUser = getCurrentUser();
  const unreadNotifications = mockNotifications.filter(n => !n.read).length;

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar
        role={currentRole}
        activeView={activeView}
        onViewChange={setActiveView}
        onLogout={handleLogout}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header
          userName={currentUser.name}
          notificationCount={unreadNotifications}
          onNotificationClick={() => setActiveView('notifications')}
        />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>

      <Toaster />
    </div>
  );
}
