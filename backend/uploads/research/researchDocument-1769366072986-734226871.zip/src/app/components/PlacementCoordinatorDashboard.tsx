import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import { FlexibleConfiguration } from '@/app/components/placement/FlexibleConfiguration';
import { StudentEligibilityReview } from '@/app/components/placement/StudentEligibilityReview';
import { AlternativePathSuggestions } from '@/app/components/placement/AlternativePathSuggestions';
import { PlacementAnalytics } from '@/app/components/placement/PlacementAnalytics';
import { ManualDataEntry } from '@/app/components/placement/ManualDataEntry';
import { Settings, Users, GitBranch, BarChart3, Upload } from 'lucide-react';

export function PlacementCoordinatorDashboard() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Placement Coordinator Dashboard</h2>
        <p className="text-gray-600">Configure evaluation parameters and manage student eligibility</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            <span className="hidden sm:inline">Analytics</span>
          </TabsTrigger>
          <TabsTrigger value="configuration" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            <span className="hidden sm:inline">Configuration</span>
          </TabsTrigger>
          <TabsTrigger value="data-entry" className="flex items-center gap-2">
            <Upload className="w-4 h-4" />
            <span className="hidden sm:inline">Data Entry</span>
          </TabsTrigger>
          <TabsTrigger value="eligibility" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            <span className="hidden sm:inline">Eligibility</span>
          </TabsTrigger>
          <TabsTrigger value="alternatives" className="flex items-center gap-2">
            <GitBranch className="w-4 h-4" />
            <span className="hidden sm:inline">Alternatives</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <PlacementAnalytics />
        </TabsContent>

        <TabsContent value="configuration" className="space-y-6">
          <FlexibleConfiguration />
        </TabsContent>

        <TabsContent value="data-entry" className="space-y-6">
          <ManualDataEntry />
        </TabsContent>

        <TabsContent value="eligibility" className="space-y-6">
          <StudentEligibilityReview />
        </TabsContent>

        <TabsContent value="alternatives" className="space-y-6">
          <AlternativePathSuggestions />
        </TabsContent>
      </Tabs>
    </div>
  );
}