import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { StudentOverview } from '@/app/components/student/StudentOverview';
import { CareerTrackCreation } from '@/app/components/student/CareerTrackCreation';
import { CVUploadComparison } from '@/app/components/student/CVUploadComparison';
import { ImprovedRoadmap } from '@/app/components/student/ImprovedRoadmap';
import { ImprovedPerformanceSpeedometer } from '@/app/components/student/ImprovedPerformanceSpeedometer';
import { QuickActions } from '@/app/components/student/QuickActions';
import { Home, Plus, FileText, Map, Gauge } from 'lucide-react';
import { motion } from 'motion/react';

export function StudentDashboard() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <>
      <QuickActions />
      <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <TabsList className="grid w-full grid-cols-5 lg:w-auto lg:inline-grid bg-white shadow-lg border-2 border-purple-100">
            <TabsTrigger 
              value="overview" 
              className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all"
            >
              <Home className="w-4 h-4" />
              <span className="hidden sm:inline">Overview</span>
            </TabsTrigger>
            <TabsTrigger 
              value="create" 
              className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Create Track</span>
            </TabsTrigger>
            <TabsTrigger 
              value="cv" 
              className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all"
            >
              <FileText className="w-4 h-4" />
              <span className="hidden sm:inline">My CV</span>
            </TabsTrigger>
            <TabsTrigger 
              value="roadmap" 
              className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all"
            >
              <Map className="w-4 h-4" />
              <span className="hidden sm:inline">Full Roadmap</span>
            </TabsTrigger>
            <TabsTrigger 
              value="performance" 
              className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all"
            >
              <Gauge className="w-4 h-4" />
              <span className="hidden sm:inline">Analytics</span>
            </TabsTrigger>
          </TabsList>
        </motion.div>

        <TabsContent value="overview" className="space-y-6">
          <StudentOverview onCreateNew={() => setActiveTab('create')} />
        </TabsContent>

        <TabsContent value="create" className="space-y-6">
          <CareerTrackCreation onComplete={() => {
            setActiveTab('cv');
          }} />
        </TabsContent>

        <TabsContent value="cv" className="space-y-6">
          <CVUploadComparison />
        </TabsContent>

        <TabsContent value="roadmap" className="space-y-6">
          <ImprovedRoadmap />
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <ImprovedPerformanceSpeedometer />
        </TabsContent>
      </Tabs>
    </div>
    </>
  );
}