import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { Building2, Users, UserCheck, GraduationCap, TrendingUp, Activity, CheckCircle2, Clock } from 'lucide-react';

export function SuperAdminDashboard() {
  const systemStats = {
    totalStudents: 450,
    totalMentors: 12,
    totalCoordinators: 3,
    activeCareerTracks: 892,
    companiesTargeted: 25,
    avgPlacementReadiness: 72,
  };

  const programmes = [
    { name: 'B.Tech CSE', students: 180, avgScore: 74, color: 'bg-blue-600' },
    { name: 'B.Tech ECE', students: 120, avgScore: 70, color: 'bg-green-600' },
    { name: 'MCA', students: 90, avgScore: 68, color: 'bg-purple-600' },
    { name: 'M.Tech', students: 60, avgScore: 76, color: 'bg-orange-600' },
  ];

  const recentActivity = [
    { type: 'approval', message: 'Dr. Priya Sharma approved 5 eligibility requests', time: '2 hours ago' },
    { type: 'config', message: 'New semester configuration locked for B.Tech CSE Semester 4', time: '5 hours ago' },
    { type: 'alert', message: '12 students flagged for mentor intervention', time: '1 day ago' },
    { type: 'success', message: 'Batch performance improved by 8% this month', time: '2 days ago' },
  ];

  const placementReadiness = [
    { category: 'Highly Ready (80%+)', count: 85, percentage: 19, color: 'bg-green-600' },
    { category: 'Ready (65-80%)', count: 165, percentage: 37, color: 'bg-blue-600' },
    { category: 'Preparing (50-65%)', count: 145, percentage: 32, color: 'bg-yellow-600' },
    { category: 'Needs Support (<50%)', count: 55, percentage: 12, color: 'bg-red-600' },
  ];

  const systemHealth = [
    { metric: 'AI System Uptime', value: '99.8%', status: 'excellent' },
    { metric: 'Roadmap Generation Success', value: '98.2%', status: 'excellent' },
    { metric: 'CV Processing Accuracy', value: '96.5%', status: 'good' },
    { metric: 'Student Engagement Rate', value: '87.3%', status: 'good' },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg shadow-lg p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">Super Admin Dashboard</h2>
        <p className="text-blue-100">System-wide overview and management</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card className="border-2 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-blue-500 to-blue-600 p-3 rounded-lg">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold">{systemStats.totalStudents}</p>
                <p className="text-xs text-gray-600">Total Students</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-green-200">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-green-500 to-green-600 p-3 rounded-lg">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold">{systemStats.totalMentors}</p>
                <p className="text-xs text-gray-600">Active Mentors</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-purple-200">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-purple-500 to-purple-600 p-3 rounded-lg">
                <UserCheck className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold">{systemStats.totalCoordinators}</p>
                <p className="text-xs text-gray-600">Placement Coordinators</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-orange-200">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-orange-500 to-orange-600 p-3 rounded-lg">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold">{systemStats.activeCareerTracks}</p>
                <p className="text-xs text-gray-600">Active Career Tracks</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-pink-200">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-pink-500 to-pink-600 p-3 rounded-lg">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold">{systemStats.companiesTargeted}</p>
                <p className="text-xs text-gray-600">Target Companies</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-cyan-200">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-cyan-500 to-cyan-600 p-3 rounded-lg">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold">{systemStats.avgPlacementReadiness}%</p>
                <p className="text-xs text-gray-600">Avg Readiness</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Programme Performance */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle>Programme-wise Performance</CardTitle>
            <CardDescription>Student distribution and average scores by programme</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {programmes.map((prog, idx) => (
              <div key={idx} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{prog.name}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-gray-600">{prog.students} students</span>
                    <Badge variant="outline">{prog.avgScore}%</Badge>
                  </div>
                </div>
                <Progress value={(prog.students / 450) * 100} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Placement Readiness */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle>Placement Readiness Distribution</CardTitle>
            <CardDescription>Students categorized by readiness level</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {placementReadiness.map((level, idx) => (
              <Card key={idx} className={`border-2`}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-sm">{level.category}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-600">{level.count} students</span>
                      <Badge className={`${level.color} text-white`}>
                        {level.percentage}%
                      </Badge>
                    </div>
                  </div>
                  <Progress value={level.percentage} className="h-2" />
                </CardContent>
              </Card>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* System Health */}
      <Card className="border-2 border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-green-600" />
            System Health & Performance
          </CardTitle>
          <CardDescription>AI system and platform metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {systemHealth.map((metric, idx) => (
              <Card key={idx} className={`${
                metric.status === 'excellent' ? 'bg-green-50 border-green-200' : 'bg-blue-50 border-blue-200'
              }`}>
                <CardContent className="pt-6 text-center">
                  {metric.status === 'excellent' ? (
                    <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  ) : (
                    <Clock className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  )}
                  <div className="text-2xl font-bold text-gray-900 mb-1">{metric.value}</div>
                  <div className="text-xs text-gray-600">{metric.metric}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card className="border-2">
        <CardHeader>
          <CardTitle>Recent System Activity</CardTitle>
          <CardDescription>Latest events and updates across the platform</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {recentActivity.map((activity, idx) => {
            const getIcon = () => {
              switch (activity.type) {
                case 'approval': return <CheckCircle2 className="w-5 h-5 text-green-600" />;
                case 'config': return <Activity className="w-5 h-5 text-blue-600" />;
                case 'alert': return <Clock className="w-5 h-5 text-orange-600" />;
                case 'success': return <TrendingUp className="w-5 h-5 text-purple-600" />;
                default: return <Activity className="w-5 h-5 text-gray-600" />;
              }
            };

            return (
              <Card key={idx} className="bg-gray-50">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    {getIcon()}
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">{activity.message}</p>
                      <p className="text-xs text-gray-600 mt-1">{activity.time}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </CardContent>
      </Card>

      {/* AI Integration Status */}
      <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-purple-600" />
            AI System Integration
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="bg-white p-4 rounded-lg border">
              <p className="font-semibold text-gray-900 mb-2">Gemini API Status</p>
              <Badge className="bg-green-600">Active & Operational</Badge>
              <p className="text-xs text-gray-600 mt-2">Last sync: 5 minutes ago</p>
            </div>
            <div className="bg-white p-4 rounded-lg border">
              <p className="font-semibold text-gray-900 mb-2">Roadmaps Generated</p>
              <p className="text-2xl font-bold text-blue-600">892</p>
              <p className="text-xs text-gray-600 mt-2">This month</p>
            </div>
            <div className="bg-white p-4 rounded-lg border">
              <p className="font-semibold text-gray-900 mb-2">CV Analysis Completed</p>
              <p className="text-2xl font-bold text-purple-600">1,247</p>
              <p className="text-xs text-gray-600 mt-2">This month</p>
            </div>
          </div>
          <Card className="mt-4 bg-blue-50 border-blue-200">
            <CardContent className="pt-6">
              <p className="text-sm text-gray-700">
                <strong>Note:</strong> All AI operations are read-only. System administrators retain full control 
                over eligibility decisions, parameter configurations, and student data.
              </p>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
}
