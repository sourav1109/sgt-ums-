import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { GraduationCap, Users, UserCheck, Shield } from 'lucide-react';
import { UserRole } from '@/app/App';

interface LoginScreenProps {
  onLogin: (role: UserRole, name: string) => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const roles = [
    {
      role: 'student' as UserRole,
      name: 'Raj Kumar',
      title: 'Student',
      description: 'Access your career guidance roadmap',
      icon: GraduationCap,
      color: 'from-blue-500 to-blue-600',
    },
    {
      role: 'placement-coordinator' as UserRole,
      name: 'Dr. Priya Sharma',
      title: 'Placement Coordinator',
      description: 'Configure parameters and approve plans',
      icon: UserCheck,
      color: 'from-purple-500 to-purple-600',
    },
    {
      role: 'mentor' as UserRole,
      name: 'Prof. Amit Patel',
      title: 'Mentor',
      description: 'Monitor and guide student performance',
      icon: Users,
      color: 'from-green-500 to-green-600',
    },
    {
      role: 'super-admin' as UserRole,
      name: 'Admin',
      title: 'Super Admin',
      description: 'Manage system and oversee all activities',
      icon: Shield,
      color: 'from-orange-500 to-orange-600',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="bg-gradient-to-br from-blue-600 to-purple-600 p-3 rounded-xl">
              <GraduationCap className="w-10 h-10 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Career Guidance System</h1>
          <p className="text-gray-600">AI-Powered Career Planning & Placement Management</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {roles.map((roleData) => {
            const Icon = roleData.icon;
            return (
              <Card 
                key={roleData.role} 
                className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-blue-300"
                onClick={() => onLogin(roleData.role, roleData.name)}
              >
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 mx-auto mb-4 bg-gradient-to-br ${roleData.color} rounded-full flex items-center justify-center`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-lg">{roleData.title}</CardTitle>
                  <CardDescription className="text-sm">{roleData.description}</CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-xs text-gray-500 mb-3">Demo as: {roleData.name}</p>
                  <Button className={`w-full bg-gradient-to-r ${roleData.color} text-white`}>
                    Login as {roleData.title}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-8 text-center">
          <p className="text-sm text-gray-600">
            🎯 This is a demo interface showcasing the Career Guidance System
          </p>
        </div>
      </div>
    </div>
  );
}
