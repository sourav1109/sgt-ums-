import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Input } from '@/app/components/ui/input';
import { Textarea } from '@/app/components/ui/textarea';
import { CheckCircle2, XCircle, AlertCircle, TrendingUp, FileText } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/app/components/ui/dialog';

export function StudentEligibilityReview() {
  const [selectedStudent, setSelectedStudent] = useState<any>(null);

  const students = [
    {
      id: 1,
      name: 'Raj Kumar',
      programme: 'B.Tech CSE',
      semester: 3,
      company: 'Google',
      role: 'Software Engineer',
      package: '25-30 LPA',
      academicScore: 82,
      diagnosticScore: 75,
      mentorRating: 4.2,
      eligibilityScore: 78,
      status: 'pending',
      submittedDate: '2026-01-15',
    },
    {
      id: 2,
      name: 'Priya Sharma',
      programme: 'B.Tech CSE',
      semester: 3,
      company: 'Microsoft',
      role: 'Full Stack Developer',
      package: '22-28 LPA',
      academicScore: 88,
      diagnosticScore: 82,
      mentorRating: 4.5,
      eligibilityScore: 85,
      status: 'pending',
      submittedDate: '2026-01-16',
    },
    {
      id: 3,
      name: 'Amit Patel',
      programme: 'B.Tech CSE',
      semester: 3,
      company: 'Amazon',
      role: 'SDE I',
      package: '20-25 LPA',
      academicScore: 76,
      diagnosticScore: 68,
      mentorRating: 3.8,
      eligibilityScore: 72,
      status: 'pending',
      submittedDate: '2026-01-17',
    },
  ];

  const getEligibilityStatus = (score: number) => {
    if (score >= 80) return { label: 'Highly Eligible', color: 'bg-green-600', icon: CheckCircle2 };
    if (score >= 65) return { label: 'Eligible', color: 'bg-blue-600', icon: CheckCircle2 };
    if (score >= 50) return { label: 'Conditional', color: 'bg-yellow-600', icon: AlertCircle };
    return { label: 'Not Eligible', color: 'bg-red-600', icon: XCircle };
  };

  const StudentDetailDialog = ({ student }: any) => {
    const [remarks, setRemarks] = useState('');
    const [decision, setDecision] = useState<'approve' | 'reject' | null>(null);

    return (
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">Eligibility Review - {student.name}</DialogTitle>
          <DialogDescription>
            Review student's profile and make eligibility decision
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Student Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Career Track Details</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-600">Company</p>
                <p className="font-semibold">{student.company}</p>
              </div>
              <div>
                <p className="text-gray-600">Role</p>
                <p className="font-semibold">{student.role}</p>
              </div>
              <div>
                <p className="text-gray-600">Package</p>
                <p className="font-semibold">{student.package}</p>
              </div>
              <div>
                <p className="text-gray-600">Programme</p>
                <p className="font-semibold">{student.programme} - Sem {student.semester}</p>
              </div>
            </CardContent>
          </Card>

          {/* Performance Scores */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Performance Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <span className="text-sm font-medium">Academic Score (10th, 12th, Current CGPA)</span>
                <span className="text-lg font-bold text-blue-600">{student.academicScore}%</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                <span className="text-sm font-medium">Diagnostic Test Score</span>
                <span className="text-lg font-bold text-purple-600">{student.diagnosticScore}%</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                <span className="text-sm font-medium">Mentor Rating (Attitude & Discipline)</span>
                <span className="text-lg font-bold text-green-600">{student.mentorRating}/5.0</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-gradient-to-r from-orange-50 to-red-50 rounded-lg border-2 border-orange-200">
                <span className="text-sm font-semibold">Overall Eligibility Confidence</span>
                <span className="text-2xl font-bold text-orange-600">{student.eligibilityScore}%</span>
              </div>
            </CardContent>
          </Card>

          {/* AI Explanation */}
          <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                AI-Generated Eligibility Explanation
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-gray-700 space-y-2">
              <p>
                <strong>Academic Performance:</strong> Student has strong academic foundation with 82% aggregate score.
                This meets the baseline requirement for {student.company}.
              </p>
              <p>
                <strong>Technical Assessment:</strong> Diagnostic test score of {student.diagnosticScore}% indicates solid 
                understanding of core concepts. Recommended to strengthen DSA skills for better interview performance.
              </p>
              <p>
                <strong>Behavioral Assessment:</strong> Mentor rating of {student.mentorRating}/5.0 shows good attitude 
                and consistent learning discipline.
              </p>
              <p className="pt-2 border-t">
                <strong>Recommendation:</strong> Student is eligible for this track. With focused preparation on advanced 
                algorithms and system design, the student has strong potential for success.
              </p>
            </CardContent>
          </Card>

          {/* Decision Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Placement Coordinator Decision</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Remarks / Feedback</label>
                <Textarea
                  placeholder="Enter your remarks, suggestions, or conditions for approval..."
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  rows={4}
                />
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={() => setDecision('approve')}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Approve Eligibility
                </Button>
                <Button
                  onClick={() => setDecision('reject')}
                  className="flex-1 bg-red-600 hover:bg-red-700"
                  variant="destructive"
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Reject / Suggest Alternative
                </Button>
              </div>

              {decision && (
                <Card className={decision === 'approve' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}>
                  <CardContent className="pt-6">
                    <p className="text-sm font-medium">
                      {decision === 'approve' 
                        ? '✅ Student will be notified of approval. Customized roadmap will be generated.'
                        : '❌ Student will be notified. You can suggest alternative roles/companies.'}
                    </p>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    );
  };

  return (
    <div className="space-y-6">
      <Card className="border-2">
        <CardHeader>
          <CardTitle>Student Eligibility Review</CardTitle>
          <CardDescription>
            Review and approve student eligibility for their chosen career tracks
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {students.map((student) => {
              const status = getEligibilityStatus(student.eligibilityScore);
              const Icon = status.icon;

              return (
                <Card key={student.id} className="border-2 hover:border-blue-300 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 flex-1">
                        <div className={`w-12 h-12 rounded-full ${status.color} flex items-center justify-center`}>
                          <span className="text-white font-bold text-lg">
                            {student.eligibilityScore}
                          </span>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold text-base">{student.name}</h3>
                            <Badge variant="outline" className="text-xs">
                              {student.programme} - Sem {student.semester}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-gray-600">
                            <span>{student.company} - {student.role}</span>
                            <span>•</span>
                            <span>{student.package}</span>
                            <span>•</span>
                            <span>Submitted: {student.submittedDate}</span>
                          </div>
                          <div className="flex items-center gap-3 mt-2">
                            <div className="text-xs">
                              <span className="text-gray-600">Academic:</span>
                              <span className="font-semibold ml-1">{student.academicScore}%</span>
                            </div>
                            <div className="text-xs">
                              <span className="text-gray-600">Diagnostic:</span>
                              <span className="font-semibold ml-1">{student.diagnosticScore}%</span>
                            </div>
                            <div className="text-xs">
                              <span className="text-gray-600">Mentor:</span>
                              <span className="font-semibold ml-1">{student.mentorRating}/5</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge className={`${status.color} text-white`}>
                          {status.label}
                        </Badge>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="sm" onClick={() => setSelectedStudent(student)}>
                              <FileText className="w-4 h-4 mr-2" />
                              Review
                            </Button>
                          </DialogTrigger>
                          <StudentDetailDialog student={student} />
                        </Dialog>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
