import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { Textarea } from '@/app/components/ui/textarea';
import { Badge } from '@/app/components/ui/badge';
import { Upload, Search, Save, X } from 'lucide-react';
import { Slider } from '@/app/components/ui/slider';

export function ManualDataEntry() {
  const [selectedStudent, setSelectedStudent] = useState('');
  const [academicScore, setAcademicScore] = useState(0);
  const [technicalScore, setTechnicalScore] = useState(0);
  const [aptitudeScore, setAptitudeScore] = useState(0);
  const [communicationScore, setCommunicationScore] = useState(0);
  const [remarks, setRemarks] = useState('');

  const students = [
    { id: '1', name: 'Raj Kumar', rollNo: 'CSE2023001', semester: 3 },
    { id: '2', name: 'Priya Sharma', rollNo: 'CSE2023002', semester: 3 },
    { id: '3', name: 'Amit Patel', rollNo: 'CSE2023003', semester: 3 },
  ];

  const handleSave = () => {
    // Simulate saving data
    alert('Student data saved successfully!');
    // Reset form
    setSelectedStudent('');
    setAcademicScore(0);
    setTechnicalScore(0);
    setAptitudeScore(0);
    setCommunicationScore(0);
    setRemarks('');
  };

  return (
    <div className="space-y-6">
      <Card className="border-2 border-blue-200">
        <CardHeader>
          <CardTitle>Manual Student Data Entry</CardTitle>
          <CardDescription>
            Upload student performance data manually for eligibility evaluation
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Student Selection */}
          <div className="space-y-2">
            <Label>Select Student *</Label>
            <Select value={selectedStudent} onValueChange={setSelectedStudent}>
              <SelectTrigger>
                <SelectValue placeholder="Search and select student" />
              </SelectTrigger>
              <SelectContent>
                {students.map(student => (
                  <SelectItem key={student.id} value={student.id}>
                    {student.name} ({student.rollNo}) - Semester {student.semester}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedStudent && (
            <>
              {/* Student Info Card */}
              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="pt-6">
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Student Name</p>
                      <p className="font-semibold">
                        {students.find(s => s.id === selectedStudent)?.name}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">Roll Number</p>
                      <p className="font-semibold">
                        {students.find(s => s.id === selectedStudent)?.rollNo}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">Current Semester</p>
                      <p className="font-semibold">
                        Semester {students.find(s => s.id === selectedStudent)?.semester}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Performance Scores */}
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-4">Performance Scores (0-100)</h3>
                  
                  {/* Academic Score */}
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center justify-between">
                      <Label>Academic Performance (10th, 12th, Current CGPA)</Label>
                      <Badge variant="outline" className="text-base">{academicScore}%</Badge>
                    </div>
                    <Slider
                      value={[academicScore]}
                      onValueChange={([val]) => setAcademicScore(val)}
                      min={0}
                      max={100}
                      step={1}
                      className="w-full"
                    />
                    <p className="text-xs text-gray-600">
                      Combined score based on 10th, 12th marks and current CGPA
                    </p>
                  </div>

                  {/* Technical Score */}
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center justify-between">
                      <Label>Technical Skills Assessment (DSA, Coding, Problem Solving)</Label>
                      <Badge variant="outline" className="text-base">{technicalScore}%</Badge>
                    </div>
                    <Slider
                      value={[technicalScore]}
                      onValueChange={([val]) => setTechnicalScore(val)}
                      min={0}
                      max={100}
                      step={1}
                      className="w-full"
                    />
                    <p className="text-xs text-gray-600">
                      Based on practical test, coding challenges, project evaluation
                    </p>
                  </div>

                  {/* Aptitude Score */}
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center justify-between">
                      <Label>Aptitude & Logical Reasoning</Label>
                      <Badge variant="outline" className="text-base">{aptitudeScore}%</Badge>
                    </div>
                    <Slider
                      value={[aptitudeScore]}
                      onValueChange={([val]) => setAptitudeScore(val)}
                      min={0}
                      max={100}
                      step={1}
                      className="w-full"
                    />
                    <p className="text-xs text-gray-600">
                      Quantitative aptitude, logical reasoning, analytical thinking
                    </p>
                  </div>

                  {/* Communication Score */}
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center justify-between">
                      <Label>Communication & Soft Skills</Label>
                      <Badge variant="outline" className="text-base">{communicationScore}%</Badge>
                    </div>
                    <Slider
                      value={[communicationScore]}
                      onValueChange={([val]) => setCommunicationScore(val)}
                      min={0}
                      max={100}
                      step={1}
                      className="w-full"
                    />
                    <p className="text-xs text-gray-600">
                      Verbal, written communication, presentation, team collaboration
                    </p>
                  </div>
                </div>

                {/* Overall Score Preview */}
                <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <p className="text-sm text-gray-600 mb-2">Overall Assessment Score</p>
                      <div className="text-4xl font-bold text-purple-600 mb-2">
                        {Math.round((academicScore + technicalScore + aptitudeScore + communicationScore) / 4)}%
                      </div>
                      <p className="text-xs text-gray-600">Average of all assessment criteria</p>
                    </div>
                  </CardContent>
                </Card>

                {/* Remarks */}
                <div className="space-y-2">
                  <Label>Additional Remarks / Observations</Label>
                  <Textarea
                    placeholder="Enter any additional observations, strengths, weaknesses, or recommendations..."
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    rows={4}
                  />
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button 
                    onClick={handleSave}
                    className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Save Student Data
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setSelectedStudent('');
                      setAcademicScore(0);
                      setTechnicalScore(0);
                      setAptitudeScore(0);
                      setCommunicationScore(0);
                      setRemarks('');
                    }}
                  >
                    <X className="w-4 h-4 mr-2" />
                    Cancel
                  </Button>
                </div>
              </div>
            </>
          )}

          {!selectedStudent && (
            <Card className="bg-gray-50 border-dashed border-2">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Search className="w-12 h-12 text-gray-400 mb-4" />
                <p className="text-gray-600 text-center">
                  Select a student to enter their performance data
                </p>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>

      {/* Bulk Upload Option */}
      <Card className="border-2 border-green-200">
        <CardHeader>
          <CardTitle className="text-lg">Bulk Data Upload (Optional)</CardTitle>
          <CardDescription>
            Upload multiple student records via CSV/Excel file
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="border-2 border-dashed border-green-300 rounded-lg p-6 text-center">
              <Upload className="w-8 h-8 text-green-600 mx-auto mb-3" />
              <p className="text-sm text-gray-700 mb-2">
                Upload CSV or Excel file with student performance data
              </p>
              <p className="text-xs text-gray-600 mb-4">
                File should contain: Roll No, Academic Score, Technical Score, Aptitude Score, Communication Score
              </p>
              <Button variant="outline" className="border-green-600 text-green-600">
                <Upload className="w-4 h-4 mr-2" />
                Choose File
              </Button>
            </div>
            <Button variant="link" className="text-blue-600">
              Download Sample Template
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
