import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { Users, Building2, TrendingUp, Target, CheckCircle2, Clock } from 'lucide-react';

export function PlacementAnalytics() {
  const stats = {
    totalStudents: 450,
    activeCareerTracks: 892,
    eligibilityApproved: 324,
    pendingReview: 125,
    alternativesNeeded: 28,
  };

  const companyDistribution = [
    { company: 'Google', students: 45, avgScore: 78, color: 'bg-blue-600' },
    { company: 'Microsoft', students: 52, avgScore: 75, color: 'bg-green-600' },
    { company: 'Amazon', students: 38, avgScore: 72, color: 'bg-orange-600' },
    { company: 'TCS', students: 85, avgScore: 68, color: 'bg-purple-600' },
    { company: 'Infosys', students: 72, avgScore: 70, color: 'bg-pink-600' },
  ];

  const semesterPerformance = [
    { semester: 'Semester 1', students: 150, avgProgress: 92, status: 'completed' },
    { semester: 'Semester 2', students: 150, avgProgress: 88, status: 'completed' },
    { semester: 'Semester 3', students: 150, avgProgress: 65, status: 'in-progress' },
    { semester: 'Semester 4', students: 0, avgProgress: 0, status: 'pending' },
  ];

  const topPerformers = [
    { name: 'Priya Sharma', company: 'Microsoft', score: 95, semester: 3 },
    { name: 'Arjun Mehta', company: 'Google', score: 92, semester: 3 },
    { name: 'Sneha Patel', company: 'Amazon', score: 90, semester: 3 },
    { name: 'Rahul Kumar', company: 'Google', score: 88, semester: 3 },
    { name: 'Ananya Singh', company: 'Microsoft', score: 87, semester: 3 },
  ];

  return (
    <div className="space-y-6">
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalStudents}</p>
                <p className="text-xs text-gray-600">Total Students</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-purple-100 p-3 rounded-lg">
                <Target className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.activeCareerTracks}</p>
                <p className="text-xs text-gray-600">Active Tracks</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-green-100 p-3 rounded-lg">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.eligibilityApproved}</p>
                <p className="text-xs text-gray-600">Approved</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-yellow-100 p-3 rounded-lg">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.pendingReview}</p>
                <p className="text-xs text-gray-600">Pending Review</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-orange-100 p-3 rounded-lg">
                <TrendingUp className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.alternativesNeeded}</p>
                <p className="text-xs text-gray-600">Need Support</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Company Distribution */}
      <Card className="border-2">
        <CardHeader>
          <CardTitle>Company-wise Student Distribution</CardTitle>
          <CardDescription>Number of students targeting each company and their average scores</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {companyDistribution.map((company, idx) => (
            <div key={idx} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Building2 className="w-5 h-5 text-gray-600" />
                  <span className="font-medium">{company.company}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-gray-600">{company.students} students</span>
                  <Badge variant="outline">Avg: {company.avgScore}%</Badge>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Progress value={(company.students / 100) * 100} className="flex-1 h-2" />
                <span className="text-sm font-medium w-12 text-right">{company.students}</span>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Semester Performance */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle>Semester-wise Progress</CardTitle>
            <CardDescription>Average completion across semesters</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {semesterPerformance.map((sem, idx) => (
              <Card key={idx} className={
                sem.status === 'completed' ? 'bg-green-50' :
                sem.status === 'in-progress' ? 'bg-blue-50' : 'bg-gray-50'
              }>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">{sem.semester}</span>
                    <div className="flex items-center gap-2">
                      <Badge variant={
                        sem.status === 'completed' ? 'default' :
                        sem.status === 'in-progress' ? 'secondary' : 'outline'
                      } className={sem.status === 'completed' ? 'bg-green-600' : sem.status === 'in-progress' ? 'bg-blue-600' : ''}>
                        {sem.status}
                      </Badge>
                      <span className="font-bold">{sem.avgProgress}%</span>
                    </div>
                  </div>
                  <Progress value={sem.avgProgress} className="h-2" />
                  <p className="text-xs text-gray-600 mt-2">{sem.students} students enrolled</p>
                </CardContent>
              </Card>
            ))}
          </CardContent>
        </Card>

        {/* Top Performers */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-600" />
              Top Performers
            </CardTitle>
            <CardDescription>Students with highest eligibility scores</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {topPerformers.map((student, idx) => (
              <Card key={idx} className="bg-gradient-to-r from-green-50 to-blue-50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${
                        idx === 0 ? 'bg-yellow-500' :
                        idx === 1 ? 'bg-gray-400' :
                        idx === 2 ? 'bg-orange-600' : 'bg-blue-600'
                      }`}>
                        #{idx + 1}
                      </div>
                      <div>
                        <p className="font-semibold">{student.name}</p>
                        <p className="text-xs text-gray-600">{student.company} • Sem {student.semester}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-green-600">{student.score}%</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
