import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { Badge } from '@/app/components/ui/badge';
import { Plus, Trash2, Lock, CheckCircle2, AlertCircle } from 'lucide-react';

export function FlexibleConfiguration() {
  const [selectedProgramme, setSelectedProgramme] = useState('');
  const [selectedSemester, setSelectedSemester] = useState('');
  const [numberOfFields, setNumberOfFields] = useState<number>(0);
  const [fields, setFields] = useState<any[]>([]);
  const [isLocked, setIsLocked] = useState(false);

  const programmes = [
    { id: 'btech-cse', name: 'B.Tech - Computer Science' },
    { id: 'btech-ece', name: 'B.Tech - Electronics' },
    { id: 'mca', name: 'MCA' },
  ];

  const semesters = Array.from({ length: 8 }, (_, i) => `Semester ${i + 1}`);

  // Available field categories (coordinator chooses from dropdown)
  const availableCategories = [
    'Academic Competency',
    'Technical Skill Competency',
    'Soft Skills & Communication',
    'Aptitude & Logical Reasoning',
    'Professional Attitude & Discipline',
    'Project Work',
    'Certifications',
    'Competitive Programming',
    'Industry Exposure',
    'Research & Innovation',
  ];

  // Sub-categories for each main category
  const subCategoryOptions: Record<string, string[]> = {
    'Academic Competency': [
      'Mathematics',
      'Programming Fundamentals',
      'Core CS Subjects',
      'Engineering Physics',
      'Database Systems',
      'Operating Systems',
      'Computer Networks',
      'Theory of Computation',
    ],
    'Technical Skill Competency': [
      'Data Structures',
      'Algorithms',
      'System Design',
      'Web Development',
      'Mobile Development',
      'Cloud Computing',
      'DevOps',
      'Machine Learning',
      'Cybersecurity',
    ],
    'Soft Skills & Communication': [
      'Verbal Communication',
      'Written Communication',
      'Presentation Skills',
      'Team Collaboration',
      'Leadership',
      'Time Management',
    ],
    'Aptitude & Logical Reasoning': [
      'Quantitative Aptitude',
      'Logical Reasoning',
      'Verbal Reasoning',
      'Analytical Thinking',
    ],
    'Professional Attitude & Discipline': [
      'Attendance Consistency',
      'Assignment Timeliness',
      'Learning Discipline',
      'Professional Ethics',
      'Work Ethic',
    ],
    'Project Work': [
      'Mini Projects',
      'Major Project',
      'Capstone Project',
      'Industry Project',
    ],
    'Certifications': [
      'Technical Certifications',
      'Platform Certifications',
      'Industry Certifications',
    ],
    'Competitive Programming': [
      'LeetCode Practice',
      'Codeforces Rating',
      'CodeChef Rating',
      'HackerRank Score',
      'Contest Participation',
    ],
    'Industry Exposure': [
      'Internships',
      'Workshops Attended',
      'Guest Lectures',
      'Industry Visits',
    ],
    'Research & Innovation': [
      'Research Papers',
      'Patent Applications',
      'Innovation Projects',
      'Hackathons',
    ],
  };

  const handleSetFields = () => {
    if (numberOfFields > 0 && numberOfFields <= 10) {
      const newFields = Array.from({ length: numberOfFields }, (_, i) => ({
        id: i,
        category: '',
        weight: 0,
        subFields: [],
      }));
      setFields(newFields);
    }
  };

  const updateField = (fieldId: number, key: string, value: any) => {
    setFields(fields.map(f => 
      f.id === fieldId ? { ...f, [key]: value, subFields: key === 'category' ? [] : f.subFields } : f
    ));
  };

  const addSubField = (fieldId: number) => {
    setFields(fields.map(f => 
      f.id === fieldId 
        ? { ...f, subFields: [...f.subFields, { id: Date.now(), name: '', weight: 0 }] }
        : f
    ));
  };

  const removeSubField = (fieldId: number, subFieldId: number) => {
    setFields(fields.map(f => 
      f.id === fieldId 
        ? { ...f, subFields: f.subFields.filter((sf: any) => sf.id !== subFieldId) }
        : f
    ));
  };

  const updateSubField = (fieldId: number, subFieldId: number, key: string, value: any) => {
    setFields(fields.map(f => 
      f.id === fieldId 
        ? {
            ...f,
            subFields: f.subFields.map((sf: any) => 
              sf.id === subFieldId ? { ...sf, [key]: value } : sf
            )
          }
        : f
    ));
  };

  const calculateTotalWeight = () => {
    return fields.reduce((sum, field) => sum + (field.weight || 0), 0);
  };

  const validateConfiguration = () => {
    const totalWeight = calculateTotalWeight();
    if (totalWeight !== 100) return false;
    
    for (const field of fields) {
      if (!field.category) return false;
      if (field.subFields.length === 0) return false;
      
      const subTotal = field.subFields.reduce((sum: number, sub: any) => sum + (sub.weight || 0), 0);
      if (subTotal !== field.weight) return false;
      
      for (const sub of field.subFields) {
        if (!sub.name) return false;
      }
    }
    
    return true;
  };

  const handleLock = () => {
    if (validateConfiguration()) {
      setIsLocked(true);
    }
  };

  const totalWeight = calculateTotalWeight();
  const isValid = validateConfiguration();

  return (
    <div className="space-y-6">
      <Card className="border-2 border-purple-200">
        <CardHeader>
          <CardTitle className="text-xl">Flexible Evaluation Configuration</CardTitle>
          <CardDescription>
            Configure programme-specific evaluation parameters with complete flexibility
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Step 1: Programme & Semester Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Select Programme *</Label>
              <Select value={selectedProgramme} onValueChange={setSelectedProgramme} disabled={isLocked}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose programme" />
                </SelectTrigger>
                <SelectContent>
                  {programmes.map(prog => (
                    <SelectItem key={prog.id} value={prog.id}>{prog.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Select Semester *</Label>
              <Select value={selectedSemester} onValueChange={setSelectedSemester} disabled={isLocked}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose semester" />
                </SelectTrigger>
                <SelectContent>
                  {semesters.map(sem => (
                    <SelectItem key={sem} value={sem}>{sem}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {selectedProgramme && selectedSemester && !isLocked && fields.length === 0 && (
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div>
                    <Label>How many evaluation fields do you need? (1-10) *</Label>
                    <div className="flex gap-3 mt-2">
                      <Input
                        type="number"
                        min="1"
                        max="10"
                        value={numberOfFields || ''}
                        onChange={(e) => setNumberOfFields(parseInt(e.target.value) || 0)}
                        placeholder="Enter number of fields"
                        className="flex-1"
                      />
                      <Button 
                        onClick={handleSetFields}
                        disabled={numberOfFields < 1 || numberOfFields > 10}
                        className="bg-gradient-to-r from-blue-600 to-purple-600"
                      >
                        Create Fields
                      </Button>
                    </div>
                    <p className="text-xs text-gray-600 mt-2">
                      Recommended: 5-7 fields for balanced evaluation
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Validation Status */}
          {fields.length > 0 && (
            <Card className={`${isValid ? 'bg-green-50 border-green-200' : 'bg-yellow-50 border-yellow-200'}`}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {isValid ? (
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-yellow-600" />
                    )}
                    <div>
                      <p className="font-semibold text-sm">
                        {isValid ? 'Configuration Valid' : 'Configuration Incomplete'}
                      </p>
                      <p className="text-xs text-gray-600">
                        Total Weightage: {totalWeight}% / 100%
                      </p>
                    </div>
                  </div>
                  {isLocked && <Badge className="bg-blue-600">Locked - Version 1.0</Badge>}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Field Configuration */}
          {fields.length > 0 && (
            <div className="space-y-4">
              {fields.map((field, idx) => (
                <Card key={field.id} className="border-2">
                  <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">Field {idx + 1}</CardTitle>
                      <Badge variant="outline">
                        Weight: {field.weight}%
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-4 space-y-4">
                    {/* Field Category Selection */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Select Category *</Label>
                        <Select 
                          value={field.category} 
                          onValueChange={(val) => updateField(field.id, 'category', val)}
                          disabled={isLocked}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Choose category" />
                          </SelectTrigger>
                          <SelectContent>
                            {availableCategories.map(cat => (
                              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Field Weightage (%) *</Label>
                        <Input
                          type="number"
                          min="0"
                          max="100"
                          value={field.weight || ''}
                          onChange={(e) => updateField(field.id, 'weight', parseInt(e.target.value) || 0)}
                          disabled={isLocked}
                        />
                      </div>
                    </div>

                    {/* Sub-fields */}
                    {field.category && (
                      <div className="space-y-3 pl-4 border-l-2 border-purple-300">
                        <div className="flex items-center justify-between">
                          <Label className="text-sm font-medium">Sub-Parameters</Label>
                          {!isLocked && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => addSubField(field.id)}
                            >
                              <Plus className="w-3 h-3 mr-1" />
                              Add Sub-Parameter
                            </Button>
                          )}
                        </div>

                        {field.subFields.map((sub: any) => (
                          <div key={sub.id} className="flex items-center gap-2 p-3 bg-white rounded-lg border">
                            <div className="flex-1 grid grid-cols-2 gap-2">
                              <Select
                                value={sub.name}
                                onValueChange={(val) => updateSubField(field.id, sub.id, 'name', val)}
                                disabled={isLocked}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="Select sub-parameter" />
                                </SelectTrigger>
                                <SelectContent>
                                  {(subCategoryOptions[field.category] || []).map(opt => (
                                    <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <div className="flex items-center gap-2">
                                <Input
                                  type="number"
                                  placeholder="Weight %"
                                  value={sub.weight || ''}
                                  onChange={(e) => updateSubField(field.id, sub.id, 'weight', parseInt(e.target.value) || 0)}
                                  disabled={isLocked}
                                />
                                <span className="text-sm text-gray-600">%</span>
                              </div>
                            </div>
                            {!isLocked && (
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => removeSubField(field.id, sub.id)}
                                className="text-red-600"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                        ))}

                        {/* Sub-field validation */}
                        {field.subFields.length > 0 && (
                          <div className="flex items-center justify-between pt-2 border-t text-sm">
                            <span className="font-medium">Sub-Parameters Total:</span>
                            <span className={`font-bold ${
                              field.subFields.reduce((sum: number, s: any) => sum + (s.weight || 0), 0) === field.weight
                                ? 'text-green-600'
                                : 'text-red-600'
                            }`}>
                              {field.subFields.reduce((sum: number, s: any) => sum + (s.weight || 0), 0)}% / {field.weight}%
                            </span>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Action Buttons */}
          {fields.length > 0 && !isLocked && (
            <div className="flex gap-3">
              <Button
                onClick={handleLock}
                disabled={!isValid}
                className="bg-gradient-to-r from-blue-600 to-purple-600"
              >
                <Lock className="w-4 h-4 mr-2" />
                Lock Configuration
              </Button>
              <Button variant="outline" onClick={() => setFields([])}>
                Reset & Start Over
              </Button>
            </div>
          )}

          {isLocked && (
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <Lock className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="font-semibold text-sm text-gray-900">Configuration Locked Successfully</p>
                    <p className="text-xs text-gray-600">
                      This configuration is now active for all students in {selectedProgramme} - {selectedSemester}. 
                      The AI system will use these parameters for roadmap generation and performance evaluation.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
