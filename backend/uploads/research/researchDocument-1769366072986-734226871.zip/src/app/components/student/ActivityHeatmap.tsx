import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/app/components/ui/tooltip';
import { Flame } from 'lucide-react';

export function ActivityHeatmap() {
  // Generate last 90 days of activity data
  const generateActivityData = () => {
    const data = [];
    const today = new Date();
    for (let i = 89; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const activity = Math.floor(Math.random() * 6); // 0-5 activity level
      data.push({
        date: date.toISOString().split('T')[0],
        activity,
        count: activity * 3,
      });
    }
    return data;
  };

  const activityData = generateActivityData();
  const currentStreak = 7;
  const longestStreak = 15;

  const getActivityColor = (level: number) => {
    if (level === 0) return 'bg-gray-100';
    if (level === 1) return 'bg-green-200';
    if (level === 2) return 'bg-green-300';
    if (level === 3) return 'bg-green-400';
    if (level === 4) return 'bg-green-500';
    return 'bg-green-600';
  };

  const getActivityLabel = (level: number) => {
    if (level === 0) return 'No activity';
    if (level === 1) return 'Light activity';
    if (level === 2) return 'Moderate activity';
    if (level === 3) return 'Good activity';
    if (level === 4) return 'High activity';
    return 'Intense activity';
  };

  // Group by weeks
  const weeks = [];
  for (let i = 0; i < activityData.length; i += 7) {
    weeks.push(activityData.slice(i, i + 7));
  }

  return (
    <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-white">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-orange-600" />
              Activity & Streak
            </CardTitle>
            <CardDescription>Your consistency over the last 90 days</CardDescription>
          </div>
          <div className="flex gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 flex items-center gap-1">
                {currentStreak}
                <Flame className="w-6 h-6 animate-pulse" />
              </div>
              <div className="text-xs text-gray-600">Day Streak</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">{longestStreak}</div>
              <div className="text-xs text-gray-600">Best Streak</div>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <TooltipProvider>
            <div className="flex gap-1 overflow-x-auto pb-2">
              {weeks.map((week, weekIdx) => (
                <div key={weekIdx} className="flex flex-col gap-1">
                  {week.map((day, dayIdx) => (
                    <Tooltip key={dayIdx}>
                      <TooltipTrigger asChild>
                        <div
                          className={`w-3 h-3 rounded-sm ${getActivityColor(day.activity)} hover:ring-2 hover:ring-green-400 transition-all cursor-pointer`}
                        />
                      </TooltipTrigger>
                      <TooltipContent>
                        <div className="text-xs">
                          <p className="font-semibold">{day.date}</p>
                          <p>{getActivityLabel(day.activity)}</p>
                          <p>{day.count} tasks completed</p>
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  ))}
                </div>
              ))}
            </div>
          </TooltipProvider>
          
          <div className="flex items-center gap-2 text-xs">
            <span className="text-gray-600">Less</span>
            {[0, 1, 2, 3, 4, 5].map((level) => (
              <div
                key={level}
                className={`w-3 h-3 rounded-sm ${getActivityColor(level)}`}
              />
            ))}
            <span className="text-gray-600">More</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
