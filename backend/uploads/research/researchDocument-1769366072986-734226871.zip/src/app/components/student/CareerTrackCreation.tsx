import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Label } from '@/app/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/app/components/ui/radio-group';
import { Badge } from '@/app/components/ui/badge';
import { Building2, Briefcase, IndianRupee, CheckCircle2 } from 'lucide-react';

interface CareerTrackCreationProps {
  onComplete: () => void;
}

export function CareerTrackCreation({ onComplete }: CareerTrackCreationProps) {
  const [step, setStep] = useState(1);
  const [companyType, setCompanyType] = useState<'product' | 'service' | ''>('');
  const [selectedCompany, setSelectedCompany] = useState('');
  const [selectedRole, setSelectedRole] = useState('');
  const [selectedPackage, setSelectedPackage] = useState('');

  const productCompanies = ['Google', 'Microsoft', 'Amazon', 'Meta', 'Apple', 'Netflix'];
  const serviceCompanies = ['TCS', 'Infosys', 'Wipro', 'Cognizant', 'Accenture', 'HCL'];

  const roles = {
    'Google': ['Software Engineer', 'Frontend Developer', 'Backend Developer', 'Full Stack Developer', 'Data Engineer'],
    'Microsoft': ['Software Developer', 'Cloud Engineer', 'Full Stack Developer', 'DevOps Engineer'],
    'Amazon': ['SDE I', 'Frontend Engineer', 'Backend Engineer', 'Solutions Architect'],
    'TCS': ['Software Developer', 'System Engineer', 'Business Analyst', 'QA Engineer'],
    'Infosys': ['Software Engineer', 'Technology Analyst', 'Digital Specialist'],
  };

  const packageRanges = [
    '3-6 LPA',
    '6-10 LPA',
    '10-15 LPA',
    '15-20 LPA',
    '20-25 LPA',
    '25-30 LPA',
    '30+ LPA',
  ];

  const handleSubmit = () => {
    // Simulate submission
    setTimeout(() => {
      onComplete();
    }, 1000);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="text-2xl">Create Career Track</CardTitle>
          <CardDescription>
            Define your dream company, role, and package to get a personalized roadmap
          </CardDescription>
          <div className="flex items-center gap-2 mt-4">
            {[1, 2, 3, 4].map((s) => (
              <div key={s} className="flex items-center flex-1">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                  step >= s ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  {step > s ? <CheckCircle2 className="w-5 h-5" /> : s}
                </div>
                {s < 4 && <div className={`flex-1 h-1 ${step > s ? 'bg-blue-600' : 'bg-gray-200'}`} />}
              </div>
            ))}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <Label className="text-base font-semibold mb-3 block">Select Company Type</Label>
                <RadioGroup value={companyType} onValueChange={(val) => setCompanyType(val as any)}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card className={`cursor-pointer border-2 ${companyType === 'product' ? 'border-blue-600 bg-blue-50' : ''}`}>
                      <CardContent className="flex items-center gap-4 p-4">
                        <RadioGroupItem value="product" id="product" />
                        <Label htmlFor="product" className="cursor-pointer flex-1">
                          <div className="font-semibold">Product Based</div>
                          <div className="text-sm text-gray-600">Google, Microsoft, Amazon, etc.</div>
                        </Label>
                      </CardContent>
                    </Card>
                    <Card className={`cursor-pointer border-2 ${companyType === 'service' ? 'border-blue-600 bg-blue-50' : ''}`}>
                      <CardContent className="flex items-center gap-4 p-4">
                        <RadioGroupItem value="service" id="service" />
                        <Label htmlFor="service" className="cursor-pointer flex-1">
                          <div className="font-semibold">Service Based</div>
                          <div className="text-sm text-gray-600">TCS, Infosys, Wipro, etc.</div>
                        </Label>
                      </CardContent>
                    </Card>
                  </div>
                </RadioGroup>
              </div>
              <div className="flex justify-end">
                <Button 
                  onClick={() => setStep(2)} 
                  disabled={!companyType}
                  className="bg-gradient-to-r from-blue-600 to-purple-600"
                >
                  Next
                </Button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <Label className="text-base font-semibold mb-3 block">Select Your Dream Company</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {(companyType === 'product' ? productCompanies : serviceCompanies).map((company) => (
                    <Card
                      key={company}
                      className={`cursor-pointer border-2 hover:border-blue-400 transition-colors ${
                        selectedCompany === company ? 'border-blue-600 bg-blue-50' : ''
                      }`}
                      onClick={() => setSelectedCompany(company)}
                    >
                      <CardContent className="flex flex-col items-center justify-center p-4 text-center">
                        <Building2 className={`w-8 h-8 mb-2 ${selectedCompany === company ? 'text-blue-600' : 'text-gray-400'}`} />
                        <p className="font-semibold">{company}</p>
                        <Badge variant="outline" className="mt-2 text-xs">
                          {companyType === 'product' ? 'Product' : 'Service'}
                        </Badge>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(1)}>
                  Back
                </Button>
                <Button 
                  onClick={() => setStep(3)} 
                  disabled={!selectedCompany}
                  className="bg-gradient-to-r from-blue-600 to-purple-600"
                >
                  Next
                </Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div>
                <Label className="text-base font-semibold mb-3 block">Select Your Target Role</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {(roles[selectedCompany as keyof typeof roles] || roles['Google']).map((role) => (
                    <Card
                      key={role}
                      className={`cursor-pointer border-2 hover:border-blue-400 transition-colors ${
                        selectedRole === role ? 'border-blue-600 bg-blue-50' : ''
                      }`}
                      onClick={() => setSelectedRole(role)}
                    >
                      <CardContent className="flex items-center gap-3 p-4">
                        <Briefcase className={`w-6 h-6 ${selectedRole === role ? 'text-blue-600' : 'text-gray-400'}`} />
                        <p className="font-semibold">{role}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(2)}>
                  Back
                </Button>
                <Button 
                  onClick={() => setStep(4)} 
                  disabled={!selectedRole}
                  className="bg-gradient-to-r from-blue-600 to-purple-600"
                >
                  Next
                </Button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <div>
                <Label className="text-base font-semibold mb-3 block">Select Expected Package Range</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {packageRanges.map((pkg) => (
                    <Card
                      key={pkg}
                      className={`cursor-pointer border-2 hover:border-blue-400 transition-colors ${
                        selectedPackage === pkg ? 'border-blue-600 bg-blue-50' : ''
                      }`}
                      onClick={() => setSelectedPackage(pkg)}
                    >
                      <CardContent className="flex items-center gap-3 p-4">
                        <IndianRupee className={`w-6 h-6 ${selectedPackage === pkg ? 'text-blue-600' : 'text-gray-400'}`} />
                        <p className="font-semibold">{pkg}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                  <CardTitle className="text-lg">Selected Career Track</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Company:</span>
                    <span className="font-semibold">{selectedCompany}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Role:</span>
                    <span className="font-semibold">{selectedRole}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Package:</span>
                    <span className="font-semibold">{selectedPackage}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Company Type:</span>
                    <span className="font-semibold capitalize">{companyType} Based</span>
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(3)}>
                  Back
                </Button>
                <Button 
                  onClick={handleSubmit} 
                  disabled={!selectedPackage}
                  className="bg-gradient-to-r from-blue-600 to-purple-600"
                >
                  Create Career Track
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
