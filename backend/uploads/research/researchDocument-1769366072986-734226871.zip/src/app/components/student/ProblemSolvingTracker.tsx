import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { Code2, CheckCircle2, Circle, Clock } from 'lucide-react';
import { motion } from 'motion/react';

export function ProblemSolvingTracker() {
  const problemStats = {
    total: 500,
    solved: 234,
    easy: { solved: 120, total: 200 },
    medium: { solved: 95, total: 250 },
    hard: { solved: 19, total: 50 },
  };

  const recentSubmissions = [
    { 
      problem: 'Two Sum', 
      difficulty: 'Easy', 
      status: 'accepted', 
      time: '2 hours ago',
      language: 'Python'
    },
    { 
      problem: 'Binary Tree Level Order', 
      difficulty: 'Medium', 
      status: 'accepted', 
      time: '5 hours ago',
      language: 'JavaScript'
    },
    { 
      problem: 'Merge K Sorted Lists', 
      difficulty: 'Hard', 
      status: 'accepted', 
      time: '1 day ago',
      language: 'Python'
    },
    { 
      problem: 'Valid Parentheses', 
      difficulty: 'Easy', 
      status: 'accepted', 
      time: '2 days ago',
      language: 'C++'
    },
  ];

  const getDifficultyColor = (difficulty: string) => {
    if (difficulty === 'Easy') return 'text-green-600 bg-green-50 border-green-200';
    if (difficulty === 'Medium') return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    return 'text-red-600 bg-red-50 border-red-200';
  };

  const getLanguageColor = (language: string) => {
    const colors: Record<string, string> = {
      'Python': 'bg-blue-100 text-blue-700',
      'JavaScript': 'bg-yellow-100 text-yellow-700',
      'C++': 'bg-purple-100 text-purple-700',
      'Java': 'bg-orange-100 text-orange-700',
    };
    return colors[language] || 'bg-gray-100 text-gray-700';
  };

  return (
    <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 to-white">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Code2 className="w-5 h-5 text-indigo-600" />
              Problem Solving Progress
            </CardTitle>
            <CardDescription>Track your coding practice journey</CardDescription>
          </div>
          <Badge className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-base px-4 py-2">
            {problemStats.solved}/{problemStats.total}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Overall Progress Circle */}
        <div className="flex items-center justify-center">
          <div className="relative w-40 h-40">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
              {/* Background circle */}
              <circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke="#e5e7eb"
                strokeWidth="8"
              />
              {/* Progress circle */}
              <motion.circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke="url(#progress-gradient)"
                strokeWidth="8"
                strokeDasharray={`${(problemStats.solved / problemStats.total) * 283} 283`}
                strokeLinecap="round"
                initial={{ strokeDasharray: "0 283" }}
                animate={{ strokeDasharray: `${(problemStats.solved / problemStats.total) * 283} 283` }}
                transition={{ duration: 1.5, delay: 0.3 }}
              />
              <defs>
                <linearGradient id="progress-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#4f46e5" />
                  <stop offset="100%" stopColor="#9333ea" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <motion.div
                className="text-3xl font-bold text-indigo-600"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", delay: 0.5 }}
              >
                {Math.round((problemStats.solved / problemStats.total) * 100)}%
              </motion.div>
              <div className="text-xs text-gray-600">Completed</div>
            </div>
          </div>
        </div>

        {/* Difficulty Breakdown */}
        <div className="space-y-4">
          <h4 className="font-semibold text-sm">By Difficulty</h4>
          
          <motion.div
            className="space-y-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="font-medium">Easy</span>
              </div>
              <span className="font-bold text-green-600">
                {problemStats.easy.solved}/{problemStats.easy.total}
              </span>
            </div>
            <Progress value={(problemStats.easy.solved / problemStats.easy.total) * 100} className="h-2" />
          </motion.div>

          <motion.div
            className="space-y-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
          >
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <span className="font-medium">Medium</span>
              </div>
              <span className="font-bold text-yellow-600">
                {problemStats.medium.solved}/{problemStats.medium.total}
              </span>
            </div>
            <Progress value={(problemStats.medium.solved / problemStats.medium.total) * 100} className="h-2" />
          </motion.div>

          <motion.div
            className="space-y-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
          >
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <span className="font-medium">Hard</span>
              </div>
              <span className="font-bold text-red-600">
                {problemStats.hard.solved}/{problemStats.hard.total}
              </span>
            </div>
            <Progress value={(problemStats.hard.solved / problemStats.hard.total) * 100} className="h-2" />
          </motion.div>
        </div>

        {/* Recent Submissions */}
        <div className="space-y-3">
          <h4 className="font-semibold text-sm">Recent Submissions</h4>
          {recentSubmissions.map((submission, idx) => (
            <motion.div
              key={idx}
              className="flex items-center gap-3 p-3 bg-white rounded-lg border border-gray-200 hover:border-indigo-300 transition-all cursor-pointer hover:shadow-md"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 + idx * 0.1 }}
            >
              <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-sm truncate">{submission.problem}</span>
                  <Badge variant="outline" className={`text-xs ${getDifficultyColor(submission.difficulty)}`}>
                    {submission.difficulty}
                  </Badge>
                  <Badge variant="outline" className={`text-xs ${getLanguageColor(submission.language)}`}>
                    {submission.language}
                  </Badge>
                </div>
                <div className="flex items-center gap-1 text-xs text-gray-600 mt-1">
                  <Clock className="w-3 h-3" />
                  {submission.time}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
