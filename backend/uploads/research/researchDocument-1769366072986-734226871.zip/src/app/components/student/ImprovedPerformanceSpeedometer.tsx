import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { Button } from '@/app/components/ui/button';
import { TrendingUp, Target, Zap, ArrowUp, ArrowDown, ChevronRight, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

export function ImprovedPerformanceSpeedometer() {
  const [selectedTrack, setSelectedTrack] = useState('google-sde');
  const [animatedScore, setAnimatedScore] = useState(0);
  
  const careerTracks = {
    'google-sde': {
      company: 'Google',
      role: 'Software Engineer',
      currentScore: 73,
      lastWeekScore: 68,
      targetScore: 85,
    },
    'microsoft-fs': {
      company: 'Microsoft',
      role: 'Full Stack Developer',
      currentScore: 65,
      lastWeekScore: 62,
      targetScore: 80,
    },
  };

  const currentTrack = careerTracks[selectedTrack as keyof typeof careerTracks];
  const currentScore = currentTrack.currentScore;
  const scoreChange = currentScore - currentTrack.lastWeekScore;
  
  // Animate score on mount and when it changes
  useEffect(() => {
    let start = 0;
    const end = currentScore;
    const duration = 1500;
    const increment = end / (duration / 16);
    
    const timer = setInterval(() => {
      start += increment;
      if (start >= end) {
        setAnimatedScore(end);
        clearInterval(timer);
      } else {
        setAnimatedScore(Math.floor(start));
      }
    }, 16);
    
    return () => clearInterval(timer);
  }, [currentScore]);
  
  const getSpeedometerColor = (score: number) => {
    if (score >= 85) return { 
      color: '#3b82f6', 
      label: 'Excellent', 
      gradient: 'from-blue-400 to-blue-600',
      glow: 'shadow-blue-400/50'
    };
    if (score >= 70) return { 
      color: '#22c55e', 
      label: 'Good', 
      gradient: 'from-green-400 to-green-600',
      glow: 'shadow-green-400/50'
    };
    if (score >= 40) return { 
      color: '#eab308', 
      label: 'Average', 
      gradient: 'from-yellow-400 to-yellow-600',
      glow: 'shadow-yellow-400/50'
    };
    return { 
      color: '#ef4444', 
      label: 'Needs Improvement', 
      gradient: 'from-red-400 to-red-600',
      glow: 'shadow-red-400/50'
    };
  };

  const scoreInfo = getSpeedometerColor(currentScore);

  const performanceMetrics = [
    {
      category: 'Academic Performance',
      current: 82,
      target: 85,
      trend: 'up',
      change: +3,
      weightage: 30,
      icon: '📚',
    },
    {
      category: 'Technical Skills',
      current: 68,
      target: 80,
      trend: 'up',
      change: +5,
      weightage: 35,
      icon: '💻',
    },
    {
      category: 'Soft Skills',
      current: 75,
      target: 80,
      trend: 'stable',
      change: 0,
      weightage: 15,
      icon: '🤝',
    },
    {
      category: 'Aptitude & Logic',
      current: 70,
      target: 85,
      trend: 'up',
      change: +2,
      weightage: 10,
      icon: '🧠',
    },
    {
      category: 'Discipline & Attitude',
      current: 88,
      target: 90,
      trend: 'down',
      change: -2,
      weightage: 10,
      icon: '⭐',
    },
  ];

  const weeklyProgress = [
    { week: 'Week 1', score: 65, date: 'Jan 1' },
    { week: 'Week 2', score: 68, date: 'Jan 8' },
    { week: 'Week 3', score: 70, date: 'Jan 15' },
    { week: 'Week 4', score: 73, date: 'Jan 22' },
  ];

  return (
    <div className="space-y-6">
      {/* Main Performance Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 via-blue-50 to-white overflow-hidden relative">
          {/* Animated background pattern */}
          <div className="absolute inset-0 opacity-5">
            <div className="absolute inset-0" style={{
              backgroundImage: `radial-gradient(circle at 2px 2px, rgb(99, 102, 241) 1px, transparent 0)`,
              backgroundSize: '40px 40px',
            }} />
          </div>
          
          <CardHeader className="relative z-10">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <CardTitle className="text-3xl flex items-center gap-2">
                  Performance Dashboard
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  >
                    <Zap className="w-7 h-7 text-purple-600" />
                  </motion.div>
                </CardTitle>
                <CardDescription className="text-base mt-2">
                  Real-time tracking for {currentTrack.company} - {currentTrack.role}
                </CardDescription>
              </div>
              <Badge className={`bg-gradient-to-r ${scoreInfo.gradient} text-white text-lg px-6 py-3 shadow-lg ${scoreInfo.glow}`}>
                {scoreInfo.label}
              </Badge>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-8 relative z-10">
            {/* Speedometer and Stats Row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Modern Circular Speedometer */}
              <div className="lg:col-span-2">
                <div className="flex justify-center items-center">
                  <div className="relative">
                    {/* Outer glow effect */}
                    <motion.div
                      className={`absolute inset-0 rounded-full blur-2xl opacity-30 bg-gradient-to-r ${scoreInfo.gradient}`}
                      animate={{
                        scale: [1, 1.1, 1],
                        opacity: [0.3, 0.5, 0.3],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut",
                      }}
                    />
                    
                    {/* Main speedometer */}
                    <svg className="w-80 h-80" viewBox="0 0 200 200">
                      {/* Background circles */}
                      <circle
                        cx="100"
                        cy="100"
                        r="90"
                        fill="none"
                        stroke="#f3f4f6"
                        strokeWidth="4"
                      />
                      
                      {/* Colored zones */}
                      <motion.circle
                        cx="100"
                        cy="100"
                        r="85"
                        fill="none"
                        stroke="url(#gradient-red)"
                        strokeWidth="20"
                        strokeDasharray={`${(40 / 100) * 534} 534`}
                        strokeLinecap="round"
                        transform="rotate(-90 100 100)"
                        initial={{ strokeDasharray: "0 534" }}
                        animate={{ strokeDasharray: `${(40 / 100) * 534} 534` }}
                        transition={{ duration: 1, delay: 0.2 }}
                      />
                      
                      <motion.circle
                        cx="100"
                        cy="100"
                        r="85"
                        fill="none"
                        stroke="url(#gradient-yellow)"
                        strokeWidth="20"
                        strokeDasharray={`${(30 / 100) * 534} 534`}
                        strokeDashoffset={-((40 / 100) * 534)}
                        strokeLinecap="round"
                        transform="rotate(-90 100 100)"
                        initial={{ strokeDasharray: "0 534" }}
                        animate={{ strokeDasharray: `${(30 / 100) * 534} 534` }}
                        transition={{ duration: 1, delay: 0.4 }}
                      />
                      
                      <motion.circle
                        cx="100"
                        cy="100"
                        r="85"
                        fill="none"
                        stroke="url(#gradient-green)"
                        strokeWidth="20"
                        strokeDasharray={`${(15 / 100) * 534} 534`}
                        strokeDashoffset={-((70 / 100) * 534)}
                        strokeLinecap="round"
                        transform="rotate(-90 100 100)"
                        initial={{ strokeDasharray: "0 534" }}
                        animate={{ strokeDasharray: `${(15 / 100) * 534} 534` }}
                        transition={{ duration: 1, delay: 0.6 }}
                      />
                      
                      <motion.circle
                        cx="100"
                        cy="100"
                        r="85"
                        fill="none"
                        stroke="url(#gradient-blue)"
                        strokeWidth="20"
                        strokeDasharray={`${(15 / 100) * 534} 534`}
                        strokeDashoffset={-((85 / 100) * 534)}
                        strokeLinecap="round"
                        transform="rotate(-90 100 100)"
                        initial={{ strokeDasharray: "0 534" }}
                        animate={{ strokeDasharray: `${(15 / 100) * 534} 534` }}
                        transition={{ duration: 1, delay: 0.8 }}
                      />
                      
                      {/* Progress indicator */}
                      <motion.circle
                        cx="100"
                        cy="100"
                        r="70"
                        fill="none"
                        stroke={scoreInfo.color}
                        strokeWidth="12"
                        strokeDasharray={`${(currentScore / 100) * 440} 440`}
                        strokeLinecap="round"
                        transform="rotate(-90 100 100)"
                        initial={{ strokeDasharray: "0 440" }}
                        animate={{ strokeDasharray: `${(currentScore / 100) * 440} 440` }}
                        transition={{ duration: 1.5, delay: 0.5 }}
                      />
                      
                      {/* Gradients */}
                      <defs>
                        <linearGradient id="gradient-red" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#ef4444" />
                          <stop offset="100%" stopColor="#dc2626" />
                        </linearGradient>
                        <linearGradient id="gradient-yellow" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#eab308" />
                          <stop offset="100%" stopColor="#ca8a04" />
                        </linearGradient>
                        <linearGradient id="gradient-green" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#22c55e" />
                          <stop offset="100%" stopColor="#16a34a" />
                        </linearGradient>
                        <linearGradient id="gradient-blue" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#3b82f6" />
                          <stop offset="100%" stopColor="#2563eb" />
                        </linearGradient>
                      </defs>
                    </svg>
                    
                    {/* Center content */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <motion.div
                        className="text-7xl font-bold mb-2"
                        style={{ color: scoreInfo.color }}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: "spring", stiffness: 200, damping: 10, delay: 0.5 }}
                      >
                        {animatedScore}
                      </motion.div>
                      <div className="text-sm text-gray-600 mb-3 font-medium">Performance Score</div>
                      <motion.div
                        className="flex items-center gap-2 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 1 }}
                      >
                        {scoreChange > 0 ? (
                          <ArrowUp className="w-5 h-5 text-green-600" />
                        ) : scoreChange < 0 ? (
                          <ArrowDown className="w-5 h-5 text-red-600" />
                        ) : null}
                        <span className={`text-sm font-bold ${
                          scoreChange > 0 ? 'text-green-600' :
                          scoreChange < 0 ? 'text-red-600' : 'text-gray-600'
                        }`}>
                          {scoreChange > 0 ? '+' : ''}{scoreChange}% this week
                        </span>
                      </motion.div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats Cards */}
              <div className="space-y-4">
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0 hover:shadow-xl transition-shadow">
                    <CardContent className="pt-6 pb-6">
                      <div className="flex items-center justify-between mb-2">
                        <Target className="w-8 h-8" />
                        <motion.div
                          className="text-4xl font-bold"
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ type: "spring", delay: 0.5 }}
                        >
                          {currentTrack.targetScore}
                        </motion.div>
                      </div>
                      <div className="text-sm opacity-90">Target Score</div>
                      <div className="mt-2 text-xs bg-white/20 rounded-full px-3 py-1 inline-block">
                        Required for {currentTrack.company}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-0 hover:shadow-xl transition-shadow">
                    <CardContent className="pt-6 pb-6">
                      <div className="flex items-center justify-between mb-2">
                        <Zap className="w-8 h-8" />
                        <motion.div
                          className="text-4xl font-bold"
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ type: "spring", delay: 0.6 }}
                        >
                          {currentTrack.targetScore - currentScore}
                        </motion.div>
                      </div>
                      <div className="text-sm opacity-90">Points to Target</div>
                      <div className="mt-2">
                        <Progress 
                          value={(currentScore / currentTrack.targetScore) * 100} 
                          className="h-2 bg-white/20" 
                        />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white border-0 hover:shadow-xl transition-shadow">
                    <CardContent className="pt-6 pb-6">
                      <div className="flex items-center justify-between mb-2">
                        <TrendingUp className="w-8 h-8" />
                        <motion.div
                          className="text-4xl font-bold"
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ type: "spring", delay: 0.7 }}
                        >
                          +{scoreChange}
                        </motion.div>
                      </div>
                      <div className="text-sm opacity-90">Weekly Growth</div>
                      <div className="mt-2 text-xs bg-white/20 rounded-full px-3 py-1 inline-block">
                        Keep it up! 🚀
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </div>

            {/* Performance Breakdown */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
            >
              <Card className="border-2 border-gray-200">
                <CardHeader>
                  <CardTitle className="text-xl">Detailed Performance Breakdown</CardTitle>
                  <CardDescription>Track your progress across all domains</CardDescription>
                </CardHeader>
                <CardContent className="space-y-5">
                  {performanceMetrics.map((metric, idx) => (
                    <motion.div
                      key={idx}
                      className="space-y-3 p-4 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.7 + idx * 0.1 }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{metric.icon}</span>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-semibold">{metric.category}</span>
                              <Badge variant="outline" className="text-xs bg-white">
                                {metric.weightage}% weight
                              </Badge>
                            </div>
                            <div className="text-xs text-gray-600 mt-1">
                              Target: {metric.target}% • Gap: {metric.target - metric.current}%
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          {metric.change !== 0 && (
                            <motion.div
                              className={`flex items-center gap-1 px-3 py-1 rounded-full ${
                                metric.change > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                              }`}
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ delay: 0.8 + idx * 0.1 }}
                            >
                              {metric.change > 0 ? (
                                <ArrowUp className="w-4 h-4" />
                              ) : (
                                <ArrowDown className="w-4 h-4" />
                              )}
                              <span className="text-sm font-bold">{Math.abs(metric.change)}%</span>
                            </motion.div>
                          )}
                          <div className="text-right">
                            <div className={`text-2xl font-bold ${
                              metric.current >= metric.target ? 'text-green-600' : 
                              metric.current >= metric.target * 0.8 ? 'text-yellow-600' : 'text-red-600'
                            }`}>
                              {metric.current}%
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="relative">
                        <Progress value={metric.current} className="h-3" />
                        {/* Target line */}
                        <div 
                          className="absolute top-0 h-3 w-0.5 bg-gray-800 z-10"
                          style={{ left: `${metric.target}%` }}
                        >
                          <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-xs font-semibold text-gray-800 whitespace-nowrap">
                            Target
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </CardContent>
              </Card>
            </motion.div>

            {/* Weekly Trend Chart */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
            >
              <Card className="border-2 border-gray-200">
                <CardHeader>
                  <CardTitle className="text-xl">Weekly Performance Trend</CardTitle>
                  <CardDescription>Your progress over the last 4 weeks</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="h-64 flex items-end justify-between gap-4">
                      {weeklyProgress.map((week, idx) => {
                        const height = (week.score / 100) * 100;
                        const color = getSpeedometerColor(week.score);
                        const isLatest = idx === weeklyProgress.length - 1;
                        return (
                          <motion.div
                            key={idx}
                            className="flex-1 flex flex-col items-center gap-3"
                            initial={{ opacity: 0, y: 50 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.9 + idx * 0.1 }}
                          >
                            <div className="w-full relative" style={{ height: '200px' }}>
                              <motion.div 
                                className={`absolute bottom-0 w-full rounded-t-xl bg-gradient-to-t ${color.gradient} ${
                                  isLatest ? 'ring-4 ring-purple-400 shadow-xl' : 'shadow-md'
                                } cursor-pointer hover:scale-105 transition-transform`}
                                initial={{ height: 0 }}
                                animate={{ height: `${height}%` }}
                                transition={{ duration: 0.8, delay: 1 + idx * 0.1 }}
                              >
                                <div className="absolute -top-10 left-1/2 -translate-x-1/2">
                                  <div className={`text-lg font-bold px-3 py-1 rounded-lg bg-white shadow-lg ${
                                    isLatest ? 'ring-2 ring-purple-400' : ''
                                  }`}>
                                    {week.score}%
                                  </div>
                                </div>
                                {isLatest && (
                                  <div className="absolute top-2 left-1/2 -translate-x-1/2">
                                    <Badge className="bg-white text-purple-600 shadow-lg">Latest</Badge>
                                  </div>
                                )}
                              </motion.div>
                            </div>
                            <div className="text-center">
                              <div className="text-sm font-semibold">{week.week}</div>
                              <div className="text-xs text-gray-600">{week.date}</div>
                            </div>
                          </motion.div>
                        );
                      })}
                    </div>
                    
                    <div className="flex items-center justify-center gap-3 pt-6 border-t">
                      <div className="flex items-center gap-2 px-4 py-2 bg-green-50 rounded-lg">
                        <TrendingUp className="w-5 h-5 text-green-600" />
                        <span className="text-sm font-semibold text-green-600">
                          +{scoreChange}% improvement this week
                        </span>
                      </div>
                      <Button className="bg-gradient-to-r from-purple-600 to-blue-600">
                        View Full History
                        <ChevronRight className="w-4 h-4 ml-2" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Action Recommendations */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1 }}
            >
              <Card className="border-2 border-orange-200 bg-gradient-to-br from-orange-50 to-white">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-orange-100 p-3 rounded-lg">
                      <AlertCircle className="w-6 h-6 text-orange-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg mb-2">Recommended Actions to Reach Target</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="flex items-start gap-2 bg-white p-3 rounded-lg border border-orange-100">
                          <div className="text-xl">💻</div>
                          <div className="flex-1">
                            <div className="font-semibold text-sm">Focus on Technical Skills</div>
                            <div className="text-xs text-gray-600 mt-1">
                              +12% improvement needed • Complete System Design module
                            </div>
                          </div>
                        </div>
                        <div className="flex items-start gap-2 bg-white p-3 rounded-lg border border-orange-100">
                          <div className="text-xl">🧠</div>
                          <div className="flex-1">
                            <div className="font-semibold text-sm">Boost Aptitude Score</div>
                            <div className="text-xs text-gray-600 mt-1">
                              +15% improvement needed • Practice 50 more problems
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
