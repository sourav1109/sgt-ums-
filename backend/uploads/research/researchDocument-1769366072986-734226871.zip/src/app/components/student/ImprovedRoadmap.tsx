import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import { CheckCircle2, Circle, Clock, Calendar, BookOpen, Code, Trophy, Target, ChevronRight, Play, Sparkles } from 'lucide-react';

export function ImprovedRoadmap() {
  const [selectedView, setSelectedView] = useState<'semester' | 'monthly' | 'daily'>('semester');

  const semesterRoadmap = [
    {
      semester: 'Semester 1',
      status: 'completed',
      progress: 100,
      grade: 'A',
      milestones: [
        { name: 'Programming Fundamentals', progress: 100, status: 'completed' },
        { name: 'Basic DSA', progress: 100, status: 'completed' },
        { name: 'Web Development Basics', progress: 100, status: 'completed' },
      ],
    },
    {
      semester: 'Semester 2',
      status: 'completed',
      progress: 100,
      grade: 'A',
      milestones: [
        { name: 'Advanced Programming', progress: 100, status: 'completed' },
        { name: 'Database Management', progress: 100, status: 'completed' },
        { name: 'OOP Concepts', progress: 100, status: 'completed' },
      ],
    },
    {
      semester: 'Semester 3',
      status: 'in-progress',
      progress: 65,
      grade: 'In Progress',
      milestones: [
        { name: 'Advanced DSA', progress: 80, status: 'in-progress' },
        { name: 'System Design Intro', progress: 40, status: 'in-progress' },
        { name: 'Full Stack Project', progress: 50, status: 'in-progress' },
        { name: 'Competitive Programming', progress: 70, status: 'in-progress' },
      ],
    },
    {
      semester: 'Semester 4',
      status: 'locked',
      progress: 0,
      grade: 'Locked',
      milestones: [
        { name: 'Advanced System Design', progress: 0, status: 'locked' },
        { name: 'Cloud Computing', progress: 0, status: 'locked' },
        { name: 'Major Project', progress: 0, status: 'locked' },
      ],
    },
  ];

  const monthlyMilestones = [
    {
      month: 'January 2026',
      weeks: [
        {
          week: 'Week 3',
          status: 'completed',
          tasks: [
            { name: 'LeetCode - 20 Medium Problems', status: 'completed', category: 'DSA' },
            { name: 'Complete React Component Module', status: 'completed', category: 'Project' },
            { name: 'System Design Study - Load Balancing', status: 'completed', category: 'Theory' },
          ],
        },
        {
          week: 'Week 4 (Current)',
          status: 'in-progress',
          tasks: [
            { name: 'LeetCode - 25 Medium Problems', status: 'in-progress', category: 'DSA', progress: 60 },
            { name: 'Build REST API for Project', status: 'in-progress', category: 'Project', progress: 40 },
            { name: 'System Design - Caching Strategies', status: 'pending', category: 'Theory', progress: 0 },
          ],
        },
      ],
    },
    {
      month: 'February 2026',
      weeks: [
        {
          week: 'Week 1',
          status: 'upcoming',
          tasks: [
            { name: 'LeetCode - 30 Hard Problems', status: 'pending', category: 'DSA' },
            { name: 'Complete Database Integration', status: 'pending', category: 'Project' },
            { name: 'Mock Interview Practice', status: 'pending', category: 'Interview' },
          ],
        },
      ],
    },
  ];

  const dailySchedule = {
    today: 'Monday, January 19, 2026',
    tasks: [
      { time: '06:00 AM - 07:00 AM', activity: 'DSA Practice - Tree Problems', completed: true, category: 'DSA' },
      { time: '09:00 AM - 11:00 AM', activity: 'Class - Data Structures', completed: true, category: 'Academic' },
      { time: '11:00 AM - 01:00 PM', activity: 'Class - Database Management', completed: true, category: 'Academic' },
      { time: '02:00 PM - 04:00 PM', activity: 'Project Work - Backend API Development', completed: false, category: 'Project' },
      { time: '04:00 PM - 05:00 PM', activity: 'LeetCode Practice (5 problems)', completed: false, category: 'DSA' },
      { time: '07:00 PM - 09:00 PM', activity: 'System Design Study - Microservices', completed: false, category: 'Theory' },
      { time: '09:00 PM - 10:00 PM', activity: 'Revision & Documentation', completed: false, category: 'Study' },
    ],
    completedCount: 3,
    totalCount: 7,
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'DSA': 'bg-blue-100 text-blue-700 border-blue-300',
      'Project': 'bg-purple-100 text-purple-700 border-purple-300',
      'Theory': 'bg-green-100 text-green-700 border-green-300',
      'Academic': 'bg-orange-100 text-orange-700 border-orange-300',
      'Interview': 'bg-pink-100 text-pink-700 border-pink-300',
      'Study': 'bg-gray-100 text-gray-700 border-gray-300',
    };
    return colors[category] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="space-y-6">
      <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 via-white to-blue-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Target className="w-6 h-6 text-purple-600" />
                Your Learning Roadmap
              </CardTitle>
              <CardDescription className="mt-2">
                AI-powered personalized path to Google - Software Engineer
              </CardDescription>
            </div>
            <Badge className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-4 py-2 text-base">
              <Sparkles className="w-4 h-4 mr-2" />
              AI Optimized
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedView} onValueChange={(v) => setSelectedView(v as any)} className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 bg-white">
              <TabsTrigger value="semester" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white">
                <Calendar className="w-4 h-4 mr-2" />
                Semester View
              </TabsTrigger>
              <TabsTrigger value="monthly" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white">
                <BookOpen className="w-4 h-4 mr-2" />
                Monthly Goals
              </TabsTrigger>
              <TabsTrigger value="daily" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white">
                <Clock className="w-4 h-4 mr-2" />
                Daily Schedule
              </TabsTrigger>
            </TabsList>

            {/* Semester View */}
            <TabsContent value="semester" className="space-y-6">
              <div className="relative">
                {/* Timeline connector */}
                <div className="absolute left-8 top-0 bottom-0 w-1 bg-gradient-to-b from-green-400 via-blue-400 to-gray-300"></div>
                
                {semesterRoadmap.map((sem, idx) => (
                  <div key={idx} className="relative pl-20 pb-8">
                    {/* Timeline node */}
                    <div className={`absolute left-4 top-4 w-8 h-8 rounded-full border-4 ${
                      sem.status === 'completed' ? 'bg-green-500 border-green-200' :
                      sem.status === 'in-progress' ? 'bg-blue-500 border-blue-200 animate-pulse' :
                      'bg-gray-300 border-gray-100'
                    } flex items-center justify-center`}>
                      {sem.status === 'completed' && <CheckCircle2 className="w-4 h-4 text-white" />}
                      {sem.status === 'in-progress' && <Play className="w-4 h-4 text-white" />}
                      {sem.status === 'locked' && <Circle className="w-4 h-4 text-gray-500" />}
                    </div>

                    <Card className={`border-2 transition-all hover:shadow-lg ${
                      sem.status === 'completed' ? 'border-green-200 bg-gradient-to-br from-green-50 to-white' :
                      sem.status === 'in-progress' ? 'border-blue-300 bg-gradient-to-br from-blue-50 to-white shadow-md' :
                      'border-gray-200 bg-gray-50 opacity-60'
                    }`}>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="text-xl">{sem.semester}</CardTitle>
                            <CardDescription className="mt-1">
                              {sem.status === 'completed' && `Completed with Grade ${sem.grade}`}
                              {sem.status === 'in-progress' && 'Currently in progress'}
                              {sem.status === 'locked' && 'Unlocks after Semester 3'}
                            </CardDescription>
                          </div>
                          <div className="text-right">
                            <div className={`text-3xl font-bold ${
                              sem.status === 'completed' ? 'text-green-600' :
                              sem.status === 'in-progress' ? 'text-blue-600' :
                              'text-gray-400'
                            }`}>
                              {sem.progress}%
                            </div>
                            <div className="text-xs text-gray-600 mt-1">Progress</div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <Progress value={sem.progress} className="h-2" />
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {sem.milestones.map((milestone, midx) => (
                            <Card key={midx} className={`${
                              milestone.status === 'completed' ? 'bg-green-50 border-green-200' :
                              milestone.status === 'in-progress' ? 'bg-blue-50 border-blue-200' :
                              'bg-gray-50 border-gray-200'
                            }`}>
                              <CardContent className="p-4">
                                <div className="flex items-start gap-2 mb-2">
                                  {milestone.status === 'completed' && <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />}
                                  {milestone.status === 'in-progress' && <Play className="w-5 h-5 text-blue-600 mt-0.5" />}
                                  {milestone.status === 'locked' && <Circle className="w-5 h-5 text-gray-400 mt-0.5" />}
                                  <div className="flex-1">
                                    <p className="font-medium text-sm">{milestone.name}</p>
                                    {milestone.status !== 'locked' && (
                                      <div className="flex items-center gap-2 mt-2">
                                        <Progress value={milestone.progress} className="h-1 flex-1" />
                                        <span className="text-xs font-medium">{milestone.progress}%</span>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>

                        {sem.status === 'in-progress' && (
                          <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600">
                            <ChevronRight className="w-4 h-4 mr-2" />
                            Continue Learning
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Monthly View */}
            <TabsContent value="monthly" className="space-y-6">
              {monthlyMilestones.map((month, idx) => (
                <Card key={idx} className="border-2">
                  <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
                    <CardTitle>{month.month}</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6 space-y-4">
                    {month.weeks.map((week, widx) => (
                      <Card key={widx} className={`border-2 ${
                        week.status === 'completed' ? 'border-green-200 bg-green-50' :
                        week.status === 'in-progress' ? 'border-blue-200 bg-blue-50' :
                        'border-gray-200'
                      }`}>
                        <CardHeader>
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-base">{week.week}</CardTitle>
                            <Badge variant={week.status === 'completed' ? 'default' : 'outline'} className={
                              week.status === 'completed' ? 'bg-green-600' :
                              week.status === 'in-progress' ? 'bg-blue-600 text-white' : ''
                            }>
                              {week.status === 'completed' && 'Completed'}
                              {week.status === 'in-progress' && 'Current Week'}
                              {week.status === 'upcoming' && 'Upcoming'}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-2">
                          {week.tasks.map((task, tidx) => (
                            <div key={tidx} className="flex items-center gap-3 p-3 bg-white rounded-lg border">
                              {task.status === 'completed' && <CheckCircle2 className="w-5 h-5 text-green-600" />}
                              {task.status === 'in-progress' && <Play className="w-5 h-5 text-blue-600" />}
                              {task.status === 'pending' && <Circle className="w-5 h-5 text-gray-400" />}
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <p className="font-medium text-sm">{task.name}</p>
                                  <Badge variant="outline" className={`text-xs ${getCategoryColor(task.category)}`}>
                                    {task.category}
                                  </Badge>
                                </div>
                                {task.status === 'in-progress' && task.progress !== undefined && (
                                  <div className="flex items-center gap-2">
                                    <Progress value={task.progress} className="h-1 flex-1" />
                                    <span className="text-xs">{task.progress}%</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </CardContent>
                      </Card>
                    ))}
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            {/* Daily Schedule */}
            <TabsContent value="daily" className="space-y-6">
              <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-white">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{dailySchedule.today}</CardTitle>
                      <CardDescription className="mt-1">
                        Your personalized daily schedule
                      </CardDescription>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">
                        {dailySchedule.completedCount}/{dailySchedule.totalCount}
                      </div>
                      <div className="text-xs text-gray-600">Tasks Done</div>
                    </div>
                  </div>
                  <Progress 
                    value={(dailySchedule.completedCount / dailySchedule.totalCount) * 100} 
                    className="h-2 mt-4"
                  />
                </CardHeader>
                <CardContent className="space-y-3">
                  {dailySchedule.tasks.map((task, idx) => (
                    <Card key={idx} className={`border-2 transition-all ${
                      task.completed 
                        ? 'border-green-200 bg-green-50' 
                        : 'border-gray-200 hover:border-blue-300 cursor-pointer'
                    }`}>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            task.completed ? 'bg-green-500' : 'bg-gray-200'
                          }`}>
                            {task.completed ? (
                              <CheckCircle2 className="w-6 h-6 text-white" />
                            ) : (
                              <Clock className="w-6 h-6 text-gray-500" />
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <p className="text-xs font-medium text-gray-600">{task.time}</p>
                              <Badge variant="outline" className={`text-xs ${getCategoryColor(task.category)}`}>
                                {task.category}
                              </Badge>
                            </div>
                            <p className={`font-medium ${task.completed ? 'line-through text-gray-600' : 'text-gray-900'}`}>
                              {task.activity}
                            </p>
                          </div>
                          {!task.completed && (
                            <Button size="sm" variant="outline">Mark Done</Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </CardContent>
              </Card>

              {/* AI Suggestion */}
              <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <div className="bg-gradient-to-br from-purple-600 to-blue-600 p-2 rounded-lg">
                      <Sparkles className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 mb-1">AI Recommendation</h4>
                      <p className="text-sm text-gray-700">
                        Great progress today! You're 43% done with your daily tasks. 
                        Focus on completing the LeetCode practice session before 5 PM to maintain your 
                        technical skills momentum. Consider taking a 10-minute break before starting.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
