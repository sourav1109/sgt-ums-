import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { Button } from '@/app/components/ui/button';
import { Target, CheckCircle2, Circle, Flame, Star, Trophy } from 'lucide-react';
import { motion } from 'motion/react';

export function DailyGoals() {
  const [goals, setGoals] = useState([
    { 
      id: 1, 
      title: 'Solve 3 LeetCode Problems', 
      completed: 2, 
      total: 3, 
      icon: '🧠',
      points: 30,
      done: false
    },
    { 
      id: 2, 
      title: 'Study System Design for 1 hour', 
      completed: 1, 
      total: 1, 
      icon: '📚',
      points: 20,
      done: true
    },
    { 
      id: 3, 
      title: 'Work on Project for 2 hours', 
      completed: 0, 
      total: 2, 
      icon: '💻',
      points: 40,
      done: false
    },
    { 
      id: 4, 
      title: 'Review Data Structures', 
      completed: 1, 
      total: 1, 
      icon: '🔍',
      points: 15,
      done: true
    },
  ]);

  const completedGoals = goals.filter(g => g.done).length;
  const totalPoints = goals.reduce((sum, g) => sum + (g.done ? g.points : 0), 0);
  const maxPoints = goals.reduce((sum, g) => sum + g.points, 0);

  return (
    <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-white">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5 text-green-600" />
              Today's Goals
            </CardTitle>
            <CardDescription>Complete your daily tasks to maintain your streak</CardDescription>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-center">
              <div className="flex items-center gap-1 text-2xl font-bold text-orange-600">
                <Flame className="w-6 h-6 animate-pulse" />
                7
              </div>
              <div className="text-xs text-gray-600">Day Streak</div>
            </div>
            <div className="text-center">
              <div className="flex items-center gap-1 text-2xl font-bold text-yellow-600">
                <Star className="w-6 h-6" />
                {totalPoints}
              </div>
              <div className="text-xs text-gray-600">XP Today</div>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Overall Progress */}
        <div className="bg-white p-4 rounded-lg border-2 border-green-200">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold">Daily Progress</span>
            <Badge className="bg-gradient-to-r from-green-600 to-emerald-600 text-white">
              {completedGoals}/{goals.length} Complete
            </Badge>
          </div>
          <Progress value={(completedGoals / goals.length) * 100} className="h-3" />
          <div className="flex items-center justify-between mt-2 text-xs text-gray-600">
            <span>{Math.round((completedGoals / goals.length) * 100)}% Complete</span>
            <span>{totalPoints}/{maxPoints} XP</span>
          </div>
        </div>

        {/* Individual Goals */}
        <div className="space-y-3">
          {goals.map((goal, idx) => (
            <motion.div
              key={goal.id}
              className={`p-4 rounded-lg border-2 transition-all cursor-pointer ${
                goal.done 
                  ? 'bg-green-50 border-green-200' 
                  : 'bg-white border-gray-200 hover:border-green-300 hover:shadow-md'
              }`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 * idx }}
              whileHover={{ scale: goal.done ? 1 : 1.02 }}
            >
              <div className="flex items-start gap-3">
                <div className={`text-3xl ${goal.done && 'opacity-50'}`}>
                  {goal.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {goal.done ? (
                        <CheckCircle2 className="w-5 h-5 text-green-600" />
                      ) : (
                        <Circle className="w-5 h-5 text-gray-400" />
                      )}
                      <span className={`font-semibold ${goal.done && 'line-through text-gray-500'}`}>
                        {goal.title}
                      </span>
                    </div>
                    <Badge variant="outline" className={`${
                      goal.done 
                        ? 'bg-green-100 text-green-700 border-green-300' 
                        : 'bg-yellow-100 text-yellow-700 border-yellow-300'
                    }`}>
                      +{goal.points} XP
                    </Badge>
                  </div>
                  
                  {!goal.done && (
                    <div className="space-y-2">
                      <Progress value={(goal.completed / goal.total) * 100} className="h-2" />
                      <div className="text-xs text-gray-600">
                        {goal.completed}/{goal.total} completed
                      </div>
                    </div>
                  )}
                  
                  {goal.done && (
                    <div className="flex items-center gap-2 text-sm text-green-600">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Completed! Great job! 🎉</span>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Motivational Message */}
        {completedGoals === goals.length ? (
          <motion.div
            className="bg-gradient-to-r from-green-500 to-emerald-500 text-white p-6 rounded-lg text-center"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200 }}
          >
            <Trophy className="w-12 h-12 mx-auto mb-3" />
            <h3 className="text-xl font-bold mb-2">All Goals Completed! 🎉</h3>
            <p className="text-sm opacity-90 mb-4">
              Amazing work today! You've earned {maxPoints} XP and maintained your {7}-day streak!
            </p>
            <Badge className="bg-white text-green-600 text-base px-4 py-2">
              Keep up the momentum! 🚀
            </Badge>
          </motion.div>
        ) : (
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg border border-blue-200">
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 p-2 rounded-lg">
                <Flame className="w-5 h-5 text-orange-600" />
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-sm mb-1">Keep Going! 💪</h4>
                <p className="text-xs text-gray-600">
                  Complete {goals.length - completedGoals} more {goals.length - completedGoals === 1 ? 'goal' : 'goals'} to maintain your streak and earn {maxPoints - totalPoints} more XP!
                </p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
