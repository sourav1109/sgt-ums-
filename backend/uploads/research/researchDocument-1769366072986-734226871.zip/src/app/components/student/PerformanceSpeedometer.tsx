import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle2, Target, Zap, ArrowUp, ArrowDown } from 'lucide-react';

export function PerformanceSpeedometer() {
  const [selectedTrack, setSelectedTrack] = useState('google-sde');
  
  // Dummy data for different career tracks
  const careerTracks = {
    'google-sde': {
      company: 'Google',
      role: 'Software Engineer',
      currentScore: 73,
      lastWeekScore: 68,
      targetScore: 85,
    },
    'microsoft-fs': {
      company: 'Microsoft',
      role: 'Full Stack Developer',
      currentScore: 65,
      lastWeekScore: 62,
      targetScore: 80,
    },
  };

  const currentTrack = careerTracks[selectedTrack as keyof typeof careerTracks];
  const currentScore = currentTrack.currentScore;
  const scoreChange = currentScore - currentTrack.lastWeekScore;
  
  const getSpeedometerColor = (score: number) => {
    if (score >= 85) return { color: '#3b82f6', label: 'Excellent', gradient: 'from-blue-400 to-blue-600' };
    if (score >= 70) return { color: '#22c55e', label: 'Good', gradient: 'from-green-400 to-green-600' };
    if (score >= 40) return { color: '#eab308', label: 'Average', gradient: 'from-yellow-400 to-yellow-600' };
    return { color: '#ef4444', label: 'Needs Improvement', gradient: 'from-red-400 to-red-600' };
  };

  const scoreInfo = getSpeedometerColor(currentScore);
  const rotation = (currentScore / 100) * 180 - 90; // -90 to 90 degrees

  const performanceMetrics = [
    {
      category: 'Academic Performance',
      current: 82,
      target: 85,
      trend: 'up',
      change: +3,
      weightage: 30,
    },
    {
      category: 'Technical Skills',
      current: 68,
      target: 80,
      trend: 'up',
      change: +5,
      weightage: 35,
    },
    {
      category: 'Soft Skills',
      current: 75,
      target: 80,
      trend: 'stable',
      change: 0,
      weightage: 15,
    },
    {
      category: 'Aptitude & Logic',
      current: 70,
      target: 85,
      trend: 'up',
      change: +2,
      weightage: 10,
    },
    {
      category: 'Discipline & Attitude',
      current: 88,
      target: 90,
      trend: 'down',
      change: -2,
      weightage: 10,
    },
  ];

  const weeklyProgress = [
    { week: 'Week 1', score: 65, date: 'Jan 1' },
    { week: 'Week 2', score: 68, date: 'Jan 8' },
    { week: 'Week 3', score: 70, date: 'Jan 15' },
    { week: 'Week 4', score: 73, date: 'Jan 22' },
  ];

  return (
    <div className="space-y-6">
      <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-white">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl">Performance Speedometer</CardTitle>
              <CardDescription>
                Real-time performance tracking for {currentTrack.company} - {currentTrack.role}
              </CardDescription>
            </div>
            <Badge className={`bg-gradient-to-r ${scoreInfo.gradient} text-white text-base px-4 py-2`}>
              {scoreInfo.label}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Speedometer Visualization */}
          <div className="flex flex-col lg:flex-row gap-6 items-center">
            {/* Speedometer Gauge */}
            <div className="flex-1 flex justify-center">
              <div className="relative w-80 h-80">
                {/* Outer Circle */}
                <svg className="w-full h-full -rotate-90" viewBox="0 0 200 200">
                  {/* Background track */}
                  <circle
                    cx="100"
                    cy="100"
                    r="85"
                    fill="none"
                    stroke="#e5e7eb"
                    strokeWidth="20"
                  />
                  
                  {/* Red Zone (0-40) */}
                  <circle
                    cx="100"
                    cy="100"
                    r="85"
                    fill="none"
                    stroke="#ef4444"
                    strokeWidth="20"
                    strokeDasharray={`${(40 / 100) * 534} 534`}
                    strokeLinecap="round"
                  />
                  
                  {/* Yellow Zone (40-70) */}
                  <circle
                    cx="100"
                    cy="100"
                    r="85"
                    fill="none"
                    stroke="#eab308"
                    strokeWidth="20"
                    strokeDasharray={`${(30 / 100) * 534} 534`}
                    strokeDashoffset={-((40 / 100) * 534)}
                    strokeLinecap="round"
                  />
                  
                  {/* Green Zone (70-85) */}
                  <circle
                    cx="100"
                    cy="100"
                    r="85"
                    fill="none"
                    stroke="#22c55e"
                    strokeWidth="20"
                    strokeDasharray={`${(15 / 100) * 534} 534`}
                    strokeDashoffset={-((70 / 100) * 534)}
                    strokeLinecap="round"
                  />
                  
                  {/* Blue Zone (85-100) */}
                  <circle
                    cx="100"
                    cy="100"
                    r="85"
                    fill="none"
                    stroke="#3b82f6"
                    strokeWidth="20"
                    strokeDasharray={`${(15 / 100) * 534} 534`}
                    strokeDashoffset={-((85 / 100) * 534)}
                    strokeLinecap="round"
                  />
                  
                  {/* Progress indicator */}
                  <circle
                    cx="100"
                    cy="100"
                    r="75"
                    fill="none"
                    stroke={scoreInfo.color}
                    strokeWidth="8"
                    strokeDasharray={`${(currentScore / 100) * 471} 471`}
                    strokeLinecap="round"
                    className="transition-all duration-500"
                  />
                </svg>
                
                {/* Center content */}
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="text-center">
                    <div className="text-6xl font-bold mb-2" style={{ color: scoreInfo.color }}>
                      {currentScore}
                    </div>
                    <div className="text-sm text-gray-600 mb-3">Current Score</div>
                    <div className="flex items-center justify-center gap-2">
                      {scoreChange > 0 ? (
                        <ArrowUp className="w-5 h-5 text-green-600" />
                      ) : scoreChange < 0 ? (
                        <ArrowDown className="w-5 h-5 text-red-600" />
                      ) : null}
                      <span className={`text-sm font-semibold ${
                        scoreChange > 0 ? 'text-green-600' :
                        scoreChange < 0 ? 'text-red-600' : 'text-gray-600'
                      }`}>
                        {scoreChange > 0 ? '+' : ''}{scoreChange} this week
                      </span>
                    </div>
                  </div>
                </div>

                {/* Needle */}
                <div 
                  className="absolute top-1/2 left-1/2 w-1 h-32 bg-gray-800 origin-bottom transition-transform duration-700"
                  style={{ 
                    transform: `translate(-50%, -100%) rotate(${rotation}deg)`,
                  }}
                >
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-gray-800 rounded-full border-2 border-white"></div>
                </div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 bg-gray-800 rounded-full border-4 border-white"></div>
              </div>
            </div>

            {/* Stats Panel */}
            <div className="flex-1 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                  <CardContent className="pt-6 text-center">
                    <Target className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                    <div className="text-3xl font-bold text-blue-600">{currentTrack.targetScore}</div>
                    <div className="text-xs text-gray-600 mt-1">Target Score</div>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                  <CardContent className="pt-6 text-center">
                    <Zap className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                    <div className="text-3xl font-bold text-purple-600">
                      {currentTrack.targetScore - currentScore}
                    </div>
                    <div className="text-xs text-gray-600 mt-1">Gap to Target</div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-white">
                <CardContent className="pt-6">
                  <h4 className="font-semibold mb-4">Score Zones</h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 bg-red-500 rounded"></div>
                        <span>Critical</span>
                      </div>
                      <span className="text-gray-600">0-40%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 bg-yellow-500 rounded"></div>
                        <span>Average</span>
                      </div>
                      <span className="text-gray-600">40-70%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 bg-green-500 rounded"></div>
                        <span>Good</span>
                      </div>
                      <span className="text-gray-600">70-85%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 bg-blue-500 rounded"></div>
                        <span>Excellent</span>
                      </div>
                      <span className="text-gray-600">85-100%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Performance Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Performance Breakdown by Domain</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {performanceMetrics.map((metric, idx) => (
                <div key={idx} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{metric.category}</span>
                      <Badge variant="outline" className="text-xs">{metric.weightage}%</Badge>
                    </div>
                    <div className="flex items-center gap-3">
                      {metric.change !== 0 && (
                        <div className={`flex items-center gap-1 text-sm ${
                          metric.change > 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {metric.change > 0 ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />}
                          <span>{Math.abs(metric.change)}%</span>
                        </div>
                      )}
                      <span className={`text-sm font-bold ${
                        metric.current >= metric.target ? 'text-green-600' : 'text-yellow-600'
                      }`}>
                        {metric.current}%
                      </span>
                      <span className="text-xs text-gray-500">/ {metric.target}%</span>
                    </div>
                  </div>
                  <div className="relative">
                    <Progress value={metric.current} className="h-2" />
                    <div 
                      className="absolute top-0 h-2 w-0.5 bg-gray-800"
                      style={{ left: `${metric.target}%` }}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Weekly Trend Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Weekly Performance Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-end justify-between gap-2">
                {weeklyProgress.map((week, idx) => {
                  const height = (week.score / 100) * 100;
                  const color = getSpeedometerColor(week.score);
                  const isLatest = idx === weeklyProgress.length - 1;
                  return (
                    <div key={idx} className="flex-1 flex flex-col items-center gap-2">
                      <div className="w-full relative" style={{ height: '200px' }}>
                        <div 
                          className={`absolute bottom-0 w-full rounded-t-lg bg-gradient-to-t ${color.gradient} transition-all duration-500 ${
                            isLatest ? 'ring-4 ring-purple-300' : ''
                          }`}
                          style={{ height: `${height}%` }}
                        >
                          <div className="absolute -top-8 left-1/2 -translate-x-1/2 text-sm font-bold whitespace-nowrap">
                            {week.score}%
                          </div>
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-xs font-medium">{week.week}</div>
                        <div className="text-xs text-gray-600">{week.date}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="flex items-center justify-center gap-2 mt-6 pt-4 border-t">
                <TrendingUp className="w-5 h-5 text-green-600" />
                <span className="text-sm font-medium text-green-600">
                  +{scoreChange}% improvement this week
                </span>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
}