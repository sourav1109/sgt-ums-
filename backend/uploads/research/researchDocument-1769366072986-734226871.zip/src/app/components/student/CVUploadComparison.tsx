import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { Upload, Download, FileText, CheckCircle2, AlertCircle, Circle, Mail, Phone, MapPin, Linkedin, Github, Award, Briefcase, GraduationCap, Code } from 'lucide-react';

export function CVUploadComparison() {
  const [uploadedCV, setUploadedCV] = useState(true); // Simulating uploaded CV

  // Student's Current CV (uploaded)
  const currentCV = {
    name: 'Raj Kumar',
    email: 'raj.kumar@university.edu',
    phone: '+91 98765 43210',
    location: 'Mumbai, Maharashtra',
    linkedin: 'linkedin.com/in/rajkumar',
    github: 'github.com/rajkumar',
    
    education: [
      {
        degree: 'B.Tech in Computer Science',
        institution: 'XYZ University',
        year: '2023-2027',
        cgpa: '8.2',
        status: 'completed',
      },
      {
        degree: '12th (Science)',
        institution: 'ABC School',
        year: '2023',
        percentage: '85%',
        status: 'completed',
      },
    ],
    
    skills: [
      { name: 'Java', level: 'Intermediate', status: 'completed' },
      { name: 'Python', level: 'Basic', status: 'completed' },
      { name: 'Data Structures', level: 'Learning', status: 'in-progress' },
      { name: 'HTML/CSS', level: 'Intermediate', status: 'completed' },
    ],
    
    projects: [
      {
        name: 'E-commerce Website',
        description: 'Built a full-stack e-commerce platform',
        tech: 'HTML, CSS, JavaScript, PHP',
        status: 'completed',
      },
      {
        name: 'Student Management System',
        description: 'Database-driven student portal',
        tech: 'Java, MySQL',
        status: 'in-progress',
      },
    ],
    
    certifications: [
      { name: 'Java Programming', platform: 'Coursera', status: 'completed' },
      { name: 'Web Development Bootcamp', platform: 'Udemy', status: 'completed' },
    ],
    
    achievements: [
      'College Hackathon - 2nd Place',
      'Technical Club Member',
    ],
  };

  // Standard CV for Google SDE (set by placement coordinator)
  const standardCV = {
    education: [
      { item: 'B.Tech in CS/IT - CGPA 8.5+', status: 'in-progress', required: true },
      { item: '12th - 85%+', status: 'completed', required: true },
    ],
    
    skills: [
      { name: 'Java', level: 'Advanced', status: 'in-progress', required: true },
      { name: 'Python', level: 'Advanced', status: 'pending', required: true },
      { name: 'Data Structures & Algorithms', level: 'Advanced', status: 'in-progress', required: true },
      { name: 'System Design', level: 'Intermediate', status: 'pending', required: true },
      { name: 'SQL/NoSQL', level: 'Intermediate', status: 'pending', required: false },
      { name: 'Cloud (AWS/GCP)', level: 'Basic', status: 'pending', required: false },
    ],
    
    projects: [
      { name: 'Full Stack Web Application', tech: 'React, Node.js, MongoDB', status: 'pending', required: true },
      { name: 'System Design Project', tech: 'Microservices, Docker', status: 'pending', required: true },
      { name: 'Machine Learning Project', tech: 'Python, TensorFlow', status: 'pending', required: false },
    ],
    
    certifications: [
      { name: 'Advanced DSA Course', platform: 'Any recognized platform', status: 'pending', required: true },
      { name: 'Cloud Certification', platform: 'AWS/GCP', status: 'pending', required: false },
    ],
    
    competitiveProgramming: [
      { item: 'LeetCode - 500+ problems solved', status: 'pending', required: true },
      { item: 'Codeforces/CodeChef rating 1500+', status: 'pending', required: false },
    ],
    
    achievements: [
      { item: 'Open Source Contributions', status: 'pending', required: true },
      { item: 'Technical Blogs/Articles', status: 'pending', required: false },
      { item: 'Hackathon Participation', status: 'completed', required: false },
    ],
  };

  const getStatusIcon = (status: string) => {
    if (status === 'completed') return <CheckCircle2 className="w-4 h-4 text-green-600" />;
    if (status === 'in-progress') return <AlertCircle className="w-4 h-4 text-yellow-600" />;
    return <Circle className="w-4 h-4 text-red-600" />;
  };

  const getStatusColor = (status: string) => {
    if (status === 'completed') return 'bg-green-50 border-green-200';
    if (status === 'in-progress') return 'bg-yellow-50 border-yellow-200';
    return 'bg-red-50 border-red-200';
  };

  const calculateGapAnalysis = () => {
    const totalRequired = Object.values(standardCV).flat().filter((item: any) => item.required).length;
    const completed = Object.values(standardCV).flat().filter((item: any) => item.required && item.status === 'completed').length;
    return Math.round((completed / totalRequired) * 100);
  };

  return (
    <div className="space-y-6">
      {/* Upload Section */}
      {!uploadedCV ? (
        <Card className="border-2 border-dashed border-blue-300 bg-blue-50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="bg-blue-100 p-4 rounded-full mb-4">
              <Upload className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Upload Your CV</h3>
            <p className="text-gray-600 text-center mb-4">
              Upload your current CV to compare with the standard CV for your target role
            </p>
            <Button className="bg-gradient-to-r from-blue-600 to-purple-600">
              <Upload className="w-4 h-4 mr-2" />
              Upload CV (PDF/DOCX)
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Gap Analysis Overview */}
          <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-white">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl">CV Gap Analysis</CardTitle>
                  <CardDescription>Compare your CV with Google - Software Engineer requirements</CardDescription>
                </div>
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600">
                  <Download className="w-4 h-4 mr-2" />
                  Download Both CVs
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <Card className="bg-green-50 border-green-200">
                  <CardContent className="pt-6 text-center">
                    <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-green-600">8</div>
                    <div className="text-xs text-gray-600">Completed</div>
                  </CardContent>
                </Card>
                <Card className="bg-yellow-50 border-yellow-200">
                  <CardContent className="pt-6 text-center">
                    <AlertCircle className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-yellow-600">5</div>
                    <div className="text-xs text-gray-600">In Progress</div>
                  </CardContent>
                </Card>
                <Card className="bg-red-50 border-red-200">
                  <CardContent className="pt-6 text-center">
                    <Circle className="w-8 h-8 text-red-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-red-600">12</div>
                    <div className="text-xs text-gray-600">Missing/Pending</div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Overall CV Completion</span>
                    <span className="text-lg font-bold text-purple-600">{calculateGapAnalysis()}%</span>
                  </div>
                  <Progress value={calculateGapAnalysis()} className="h-3" />
                  <p className="text-xs text-gray-600 mt-2">Based on required criteria for Google - Software Engineer</p>
                </CardContent>
              </Card>
            </CardContent>
          </Card>

          {/* CV Comparison - Side by Side */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Current CV */}
            <Card className="border-2 border-gray-300">
              <CardHeader className="bg-gray-50">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Your Current CV</CardTitle>
                  <Badge variant="outline">Uploaded</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                {/* Header */}
                <div className="text-center pb-4 border-b">
                  <h2 className="text-2xl font-bold text-gray-900">{currentCV.name}</h2>
                  <div className="flex flex-wrap items-center justify-center gap-3 mt-3 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <Mail className="w-4 h-4" />
                      {currentCV.email}
                    </div>
                    <div className="flex items-center gap-1">
                      <Phone className="w-4 h-4" />
                      {currentCV.phone}
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {currentCV.location}
                    </div>
                  </div>
                  <div className="flex items-center justify-center gap-3 mt-2 text-sm">
                    <div className="flex items-center gap-1 text-blue-600">
                      <Linkedin className="w-4 h-4" />
                      LinkedIn
                    </div>
                    <div className="flex items-center gap-1 text-gray-800">
                      <Github className="w-4 h-4" />
                      GitHub
                    </div>
                  </div>
                </div>

                {/* Education */}
                <div>
                  <h3 className="flex items-center gap-2 font-semibold text-gray-900 mb-3 pb-2 border-b">
                    <GraduationCap className="w-5 h-5" />
                    Education
                  </h3>
                  {currentCV.education.map((edu, idx) => (
                    <div key={idx} className="mb-3 pl-4 border-l-2 border-green-500">
                      <div className="font-semibold">{edu.degree}</div>
                      <div className="text-sm text-gray-600">{edu.institution}</div>
                      <div className="text-sm text-gray-600">{edu.year} • {edu.cgpa || edu.percentage}</div>
                    </div>
                  ))}
                </div>

                {/* Skills */}
                <div>
                  <h3 className="flex items-center gap-2 font-semibold text-gray-900 mb-3 pb-2 border-b">
                    <Code className="w-5 h-5" />
                    Technical Skills
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {currentCV.skills.map((skill, idx) => (
                      <Badge key={idx} variant="outline" className="border-blue-300">
                        {skill.name} ({skill.level})
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Projects */}
                <div>
                  <h3 className="flex items-center gap-2 font-semibold text-gray-900 mb-3 pb-2 border-b">
                    <Briefcase className="w-5 h-5" />
                    Projects
                  </h3>
                  {currentCV.projects.map((project, idx) => (
                    <div key={idx} className="mb-3 pl-4 border-l-2 border-blue-500">
                      <div className="font-semibold">{project.name}</div>
                      <div className="text-sm text-gray-600">{project.description}</div>
                      <div className="text-xs text-gray-500 mt-1">Tech: {project.tech}</div>
                    </div>
                  ))}
                </div>

                {/* Certifications */}
                <div>
                  <h3 className="flex items-center gap-2 font-semibold text-gray-900 mb-3 pb-2 border-b">
                    <Award className="w-5 h-5" />
                    Certifications
                  </h3>
                  {currentCV.certifications.map((cert, idx) => (
                    <div key={idx} className="mb-2">
                      <div className="font-semibold text-sm">{cert.name}</div>
                      <div className="text-xs text-gray-600">{cert.platform}</div>
                    </div>
                  ))}
                </div>

                {/* Achievements */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3 pb-2 border-b">Achievements</h3>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    {currentCV.achievements.map((achievement, idx) => (
                      <li key={idx}>{achievement}</li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Standard CV with Gap Analysis */}
            <Card className="border-2 border-purple-300">
              <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Standard CV - Google SDE</CardTitle>
                  <Badge className="bg-purple-600">Target Requirements</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                {/* Education Requirements */}
                <div>
                  <h3 className="flex items-center gap-2 font-semibold text-gray-900 mb-3 pb-2 border-b">
                    <GraduationCap className="w-5 h-5" />
                    Education Requirements
                  </h3>
                  {standardCV.education.map((edu, idx) => (
                    <div key={idx} className={`mb-2 p-3 rounded-lg border ${getStatusColor(edu.status)}`}>
                      <div className="flex items-start gap-2">
                        {getStatusIcon(edu.status)}
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">{edu.item}</span>
                            {edu.required && <Badge variant="destructive" className="text-xs">Required</Badge>}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Skills Requirements */}
                <div>
                  <h3 className="flex items-center gap-2 font-semibold text-gray-900 mb-3 pb-2 border-b">
                    <Code className="w-5 h-5" />
                    Technical Skills Required
                  </h3>
                  {standardCV.skills.map((skill, idx) => (
                    <div key={idx} className={`mb-2 p-3 rounded-lg border ${getStatusColor(skill.status)}`}>
                      <div className="flex items-start gap-2">
                        {getStatusIcon(skill.status)}
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-sm">{skill.name}</span>
                              {skill.required && <Badge variant="destructive" className="text-xs">Required</Badge>}
                            </div>
                            <span className="text-xs text-gray-600">{skill.level}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Projects Requirements */}
                <div>
                  <h3 className="flex items-center gap-2 font-semibold text-gray-900 mb-3 pb-2 border-b">
                    <Briefcase className="w-5 h-5" />
                    Projects Required
                  </h3>
                  {standardCV.projects.map((project, idx) => (
                    <div key={idx} className={`mb-2 p-3 rounded-lg border ${getStatusColor(project.status)}`}>
                      <div className="flex items-start gap-2">
                        {getStatusIcon(project.status)}
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-sm">{project.name}</span>
                            {project.required && <Badge variant="destructive" className="text-xs">Required</Badge>}
                          </div>
                          <div className="text-xs text-gray-600">Tech: {project.tech}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Competitive Programming */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3 pb-2 border-b">Competitive Programming</h3>
                  {standardCV.competitiveProgramming.map((item, idx) => (
                    <div key={idx} className={`mb-2 p-3 rounded-lg border ${getStatusColor(item.status)}`}>
                      <div className="flex items-start gap-2">
                        {getStatusIcon(item.status)}
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">{item.item}</span>
                            {item.required && <Badge variant="destructive" className="text-xs">Required</Badge>}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Certifications Requirements */}
                <div>
                  <h3 className="flex items-center gap-2 font-semibold text-gray-900 mb-3 pb-2 border-b">
                    <Award className="w-5 h-5" />
                    Certifications
                  </h3>
                  {standardCV.certifications.map((cert, idx) => (
                    <div key={idx} className={`mb-2 p-3 rounded-lg border ${getStatusColor(cert.status)}`}>
                      <div className="flex items-start gap-2">
                        {getStatusIcon(cert.status)}
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-sm">{cert.name}</span>
                            {cert.required && <Badge variant="destructive" className="text-xs">Required</Badge>}
                          </div>
                          <div className="text-xs text-gray-600">{cert.platform}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Achievements */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3 pb-2 border-b">Additional Achievements</h3>
                  {standardCV.achievements.map((achievement, idx) => (
                    <div key={idx} className={`mb-2 p-3 rounded-lg border ${getStatusColor(achievement.status)}`}>
                      <div className="flex items-start gap-2">
                        {getStatusIcon(achievement.status)}
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">{achievement.item}</span>
                            {achievement.required && <Badge variant="destructive" className="text-xs">Required</Badge>}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Action Items */}
          <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-2 border-orange-200">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-orange-600" />
                Priority Action Items
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <Circle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                  <span><strong>High Priority:</strong> Complete Advanced Data Structures & Algorithms course</span>
                </li>
                <li className="flex items-start gap-2">
                  <Circle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                  <span><strong>High Priority:</strong> Start Full Stack Web Application project using React & Node.js</span>
                </li>
                <li className="flex items-start gap-2">
                  <Circle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                  <span><strong>High Priority:</strong> Begin LeetCode practice - Target 500+ problems</span>
                </li>
                <li className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Medium Priority:</strong> Improve Python skills to Advanced level</span>
                </li>
                <li className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Medium Priority:</strong> Start learning System Design fundamentals</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
