import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { Trophy, Award, Star, Zap, Target, Medal, Crown, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

export function AchievementBadges() {
  const achievements = [
    {
      id: 1,
      name: 'First Steps',
      description: 'Complete your first task',
      icon: Star,
      unlocked: true,
      color: 'from-yellow-400 to-yellow-600',
      borderColor: 'border-yellow-400',
      bgColor: 'bg-yellow-50',
    },
    {
      id: 2,
      name: 'Week Warrior',
      description: 'Maintain a 7-day streak',
      icon: Flame,
      unlocked: true,
      color: 'from-orange-400 to-red-600',
      borderColor: 'border-orange-400',
      bgColor: 'bg-orange-50',
    },
    {
      id: 3,
      name: 'Problem Solver',
      description: 'Solve 50 LeetCode problems',
      icon: Zap,
      unlocked: true,
      color: 'from-blue-400 to-blue-600',
      borderColor: 'border-blue-400',
      bgColor: 'bg-blue-50',
    },
    {
      id: 4,
      name: 'Rising Star',
      description: 'Reach 70% performance score',
      icon: Trophy,
      unlocked: true,
      color: 'from-purple-400 to-purple-600',
      borderColor: 'border-purple-400',
      bgColor: 'bg-purple-50',
    },
    {
      id: 5,
      name: 'Elite Coder',
      description: 'Reach 85% performance score',
      icon: Crown,
      unlocked: false,
      progress: 73,
      target: 85,
      color: 'from-indigo-400 to-indigo-600',
      borderColor: 'border-gray-300',
      bgColor: 'bg-gray-50',
    },
    {
      id: 6,
      name: 'Month Master',
      description: 'Maintain a 30-day streak',
      icon: Medal,
      unlocked: false,
      progress: 7,
      target: 30,
      color: 'from-green-400 to-green-600',
      borderColor: 'border-gray-300',
      bgColor: 'bg-gray-50',
    },
  ];

  const unlockedCount = achievements.filter(a => a.unlocked).length;

  function Flame({ className }: { className?: string }) {
    return (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2C8 6 7 10 7 14c0 2.76 2.24 5 5 5s5-2.24 5-5c0-4-1-8-5-12zm0 16c-1.66 0-3-1.34-3-3 0-2 1-4 3-6 2 2 3 4 3 6 0 1.66-1.34 3-3 3z"/>
      </svg>
    );
  }

  return (
    <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-white">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5 text-purple-600" />
              Achievements
            </CardTitle>
            <CardDescription>
              {unlockedCount} of {achievements.length} unlocked
            </CardDescription>
          </div>
          <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white text-base px-4 py-2">
            {Math.round((unlockedCount / achievements.length) * 100)}%
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {achievements.map((achievement, idx) => {
            const Icon = achievement.icon;
            return (
              <motion.div
                key={achievement.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.1 }}
              >
                <Card 
                  className={`border-2 ${achievement.unlocked ? achievement.borderColor : 'border-gray-200'} ${achievement.bgColor} transition-all hover:scale-105 hover:shadow-lg cursor-pointer ${!achievement.unlocked && 'opacity-60'}`}
                >
                  <CardContent className="p-4 text-center">
                    <div className={`w-16 h-16 mx-auto mb-3 rounded-full flex items-center justify-center ${achievement.unlocked ? `bg-gradient-to-br ${achievement.color}` : 'bg-gray-200'} relative`}>
                      <Icon className={`w-8 h-8 ${achievement.unlocked ? 'text-white' : 'text-gray-400'}`} />
                      {achievement.unlocked && (
                        <motion.div
                          className="absolute inset-0 rounded-full"
                          initial={{ scale: 1, opacity: 0.5 }}
                          animate={{ scale: 1.2, opacity: 0 }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                        >
                          <div className={`w-full h-full rounded-full bg-gradient-to-br ${achievement.color}`} />
                        </motion.div>
                      )}
                    </div>
                    <h4 className="font-semibold text-sm mb-1">{achievement.name}</h4>
                    <p className="text-xs text-gray-600 mb-2">{achievement.description}</p>
                    {!achievement.unlocked && achievement.progress !== undefined && (
                      <div className="space-y-1">
                        <Progress value={(achievement.progress / achievement.target) * 100} className="h-1.5" />
                        <p className="text-xs text-gray-500">
                          {achievement.progress}/{achievement.target}
                        </p>
                      </div>
                    )}
                    {achievement.unlocked && (
                      <Badge variant="outline" className="text-xs bg-white">
                        <Sparkles className="w-3 h-3 mr-1" />
                        Unlocked
                      </Badge>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
