import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import { ActivityHeatmap } from '@/app/components/student/ActivityHeatmap';
import { AchievementBadges } from '@/app/components/student/AchievementBadges';
import { ProblemSolvingTracker } from '@/app/components/student/ProblemSolvingTracker';
import { DailyGoals } from '@/app/components/student/DailyGoals';
import { WeeklyComparison } from '@/app/components/student/WeeklyComparison';
import { RecentUpdates } from '@/app/components/student/RecentUpdates';
import { 
  Building2, 
  Briefcase, 
  IndianRupee, 
  TrendingUp, 
  Calendar,
  Target,
  Zap,
  CheckCircle2,
  Clock,
  Circle,
  Play,
  ArrowUp,
  ArrowDown,
  Sparkles,
  ChevronRight,
  BookOpen,
  Award
} from 'lucide-react';
import { motion } from 'motion/react';

interface StudentOverviewProps {
  onCreateNew: () => void;
}

export function StudentOverview({ onCreateNew }: StudentOverviewProps) {
  const [selectedRoadmapView, setSelectedRoadmapView] = useState<'semester' | 'weekly'>('semester');

  // Active Career Track
  const activeTrack = {
    company: 'Google',
    role: 'Software Engineer',
    package: '25-30 LPA',
    type: 'Product Based',
    status: 'Active',
    eligibility: 'Approved',
    currentScore: 73,
    targetScore: 85,
    lastWeekScore: 68,
  };

  const scoreChange = activeTrack.currentScore - activeTrack.lastWeekScore;

  // Performance Metrics
  const performanceMetrics = [
    { category: 'Academic', current: 82, target: 85, trend: 'up', change: 3 },
    { category: 'Technical Skills', current: 68, target: 80, trend: 'up', change: 5 },
    { category: 'Soft Skills', current: 75, target: 80, trend: 'stable', change: 0 },
    { category: 'Aptitude', current: 70, target: 85, trend: 'up', change: 2 },
    { category: 'Discipline', current: 88, target: 90, trend: 'down', change: -2 },
  ];

  // Semester Roadmap
  const semesterRoadmap = [
    {
      semester: 'Semester 1',
      status: 'completed',
      progress: 100,
      milestones: 3,
      completedMilestones: 3,
    },
    {
      semester: 'Semester 2',
      status: 'completed',
      progress: 100,
      milestones: 3,
      completedMilestones: 3,
    },
    {
      semester: 'Semester 3',
      status: 'in-progress',
      progress: 65,
      milestones: 4,
      completedMilestones: 2,
    },
    {
      semester: 'Semester 4',
      status: 'locked',
      progress: 0,
      milestones: 3,
      completedMilestones: 0,
    },
  ];

  // Weekly Tasks
  const weeklyTasks = [
    { name: 'LeetCode - 20 Medium Problems', status: 'completed', category: 'DSA', progress: 100 },
    { name: 'Complete React Module', status: 'completed', category: 'Project', progress: 100 },
    { name: 'System Design Study', status: 'completed', category: 'Theory', progress: 100 },
    { name: 'LeetCode - 25 Problems', status: 'in-progress', category: 'DSA', progress: 60 },
    { name: 'Build REST API', status: 'in-progress', category: 'Project', progress: 40 },
    { name: 'Caching Strategies', status: 'pending', category: 'Theory', progress: 0 },
  ];

  const completedTasks = weeklyTasks.filter(t => t.status === 'completed').length;

  const getSpeedometerColor = (score: number) => {
    if (score >= 85) return { color: '#3b82f6', label: 'Excellent' };
    if (score >= 70) return { color: '#22c55e', label: 'Good' };
    if (score >= 40) return { color: '#eab308', label: 'Average' };
    return { color: '#ef4444', label: 'Needs Improvement' };
  };

  const scoreInfo = getSpeedometerColor(activeTrack.currentScore);
  const rotation = (activeTrack.currentScore / 100) * 180 - 90;

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'DSA': 'bg-blue-100 text-blue-700',
      'Project': 'bg-purple-100 text-purple-700',
      'Theory': 'bg-green-100 text-green-700',
    };
    return colors[category] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="border-0 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white overflow-hidden relative">
        <div className="absolute inset-0 opacity-20" style={{ 
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='200' height='200' xmlns='http://www.w3.org/2000/svg'%3E%3Cdefs%3E%3Cpattern id='grid' width='40' height='40' patternUnits='userSpaceOnUse'%3E%3Cpath d='M 40 0 L 0 0 0 40' fill='none' stroke='white' stroke-opacity='0.1' stroke-width='1'/%3E%3C/pattern%3E%3C/defs%3E%3Crect width='100%25' height='100%25' fill='url(%23grid)'/%3E%3C/svg%3E")` 
        }}></div>
        <CardContent className="relative pt-8 pb-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="flex-1">
              <h2 className="text-3xl font-bold mb-2">Welcome back, Raj! 👋</h2>
              <p className="text-blue-100 mb-4">
                You're on track to achieve your dream role at {activeTrack.company}
              </p>
              <div className="flex flex-wrap gap-3">
                <Badge className="bg-white/20 text-white border-white/30 backdrop-blur-sm">
                  <Building2 className="w-3 h-3 mr-1" />
                  {activeTrack.company}
                </Badge>
                <Badge className="bg-white/20 text-white border-white/30 backdrop-blur-sm">
                  <Briefcase className="w-3 h-3 mr-1" />
                  {activeTrack.role}
                </Badge>
                <Badge className="bg-white/20 text-white border-white/30 backdrop-blur-sm">
                  <IndianRupee className="w-3 h-3 mr-1" />
                  {activeTrack.package}
                </Badge>
              </div>
            </div>
            <div className="flex flex-col gap-3">
              <Card className="bg-white/10 backdrop-blur-md border-white/20">
                <CardContent className="pt-4 pb-4 px-6 text-center">
                  <div className="text-4xl font-bold mb-1">{activeTrack.currentScore}%</div>
                  <div className="text-xs text-blue-100">Current Score</div>
                  <div className="flex items-center justify-center gap-1 mt-2">
                    {scoreChange > 0 ? (
                      <ArrowUp className="w-4 h-4 text-green-300" />
                    ) : (
                      <ArrowDown className="w-4 h-4 text-red-300" />
                    )}
                    <span className="text-sm font-semibold">
                      {scoreChange > 0 ? '+' : ''}{scoreChange}% this week
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-white hover:shadow-lg transition-shadow cursor-pointer">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Target Gap</p>
                <p className="text-2xl font-bold text-blue-600">
                  {activeTrack.targetScore - activeTrack.currentScore}%
                </p>
              </div>
              <div className="bg-blue-100 p-3 rounded-lg">
                <Target className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-white hover:shadow-lg transition-shadow cursor-pointer">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Weekly Tasks</p>
                <p className="text-2xl font-bold text-green-600">
                  {completedTasks}/{weeklyTasks.length}
                </p>
              </div>
              <div className="bg-green-100 p-3 rounded-lg">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-white hover:shadow-lg transition-shadow cursor-pointer">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Semesters</p>
                <p className="text-2xl font-bold text-purple-600">
                  {semesterRoadmap.filter(s => s.status === 'completed').length}/
                  {semesterRoadmap.length}
                </p>
              </div>
              <div className="bg-purple-100 p-3 rounded-lg">
                <Calendar className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="border-2 border-orange-200 bg-gradient-to-br from-orange-50 to-white hover:shadow-lg transition-shadow cursor-pointer">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Performance</p>
                <p className="text-2xl font-bold text-orange-600">{scoreInfo.label}</p>
              </div>
              <div className="bg-orange-100 p-3 rounded-lg">
                <TrendingUp className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        </motion.div>
      </div>

      {/* Weekly Comparison */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <WeeklyComparison />
      </motion.div>

      {/* Activity Heatmap & Achievements */}
      <div className="grid grid-cols-1 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55 }}
        >
          <ActivityHeatmap />
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <AchievementBadges />
        </motion.div>
      </div>

      {/* Daily Goals, Problem Solving, and Recent Updates */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.65 }}
          className="lg:col-span-1"
        >
          <DailyGoals />
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="lg:col-span-1"
        >
          <ProblemSolvingTracker />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.72 }}
          className="lg:col-span-1"
        >
          <RecentUpdates />
        </motion.div>
      </div>

      {/* Main Content - Performance & Roadmap */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Performance Speedometer */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.75 }}
        >
          <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-white hover:shadow-xl transition-all">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-purple-600" />
              Performance Speedometer
            </CardTitle>
            <CardDescription>Real-time performance tracking</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Speedometer Gauge */}
            <div className="flex justify-center">
              <div className="relative w-64 h-64">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 200 200">
                  <circle cx="100" cy="100" r="85" fill="none" stroke="#e5e7eb" strokeWidth="20" />
                  <circle cx="100" cy="100" r="85" fill="none" stroke="#ef4444" strokeWidth="20"
                    strokeDasharray={`${(40 / 100) * 534} 534`} strokeLinecap="round" />
                  <circle cx="100" cy="100" r="85" fill="none" stroke="#eab308" strokeWidth="20"
                    strokeDasharray={`${(30 / 100) * 534} 534`} strokeDashoffset={-((40 / 100) * 534)} strokeLinecap="round" />
                  <circle cx="100" cy="100" r="85" fill="none" stroke="#22c55e" strokeWidth="20"
                    strokeDasharray={`${(15 / 100) * 534} 534`} strokeDashoffset={-((70 / 100) * 534)} strokeLinecap="round" />
                  <circle cx="100" cy="100" r="85" fill="none" stroke="#3b82f6" strokeWidth="20"
                    strokeDasharray={`${(15 / 100) * 534} 534`} strokeDashoffset={-((85 / 100) * 534)} strokeLinecap="round" />
                  <circle cx="100" cy="100" r="75" fill="none" stroke={scoreInfo.color} strokeWidth="8"
                    strokeDasharray={`${(activeTrack.currentScore / 100) * 471} 471`} strokeLinecap="round" />
                </svg>
                
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="text-5xl font-bold mb-1" style={{ color: scoreInfo.color }}>
                    {activeTrack.currentScore}
                  </div>
                  <div className="text-xs text-gray-600 mb-2">Current Score</div>
                  <Badge className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                    {scoreInfo.label}
                  </Badge>
                </div>

                <div 
                  className="absolute top-1/2 left-1/2 w-1 h-28 bg-gray-900 origin-bottom transition-transform duration-700"
                  style={{ transform: `translate(-50%, -100%) rotate(${rotation}deg)` }}
                >
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-3 h-3 bg-gray-900 rounded-full"></div>
                </div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-5 h-5 bg-gray-900 rounded-full border-2 border-white"></div>
              </div>
            </div>

            {/* Performance Breakdown */}
            <div className="space-y-3">
              <h4 className="font-semibold text-sm">Performance Breakdown</h4>
              {performanceMetrics.map((metric, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">{metric.category}</span>
                    <div className="flex items-center gap-2">
                      {metric.change !== 0 && (
                        <span className={`text-xs ${metric.change > 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {metric.change > 0 ? '+' : ''}{metric.change}%
                        </span>
                      )}
                      <span className="font-bold">{metric.current}%</span>
                    </div>
                  </div>
                  <Progress value={metric.current} className="h-1.5" />
                </div>
              ))}
            </div>

            <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:shadow-lg transition-shadow">
              View Detailed Analytics
            </Button>
          </CardContent>
        </Card>
        </motion.div>

        {/* Learning Roadmap */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.85 }}
        >
          <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-white hover:shadow-xl transition-all">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-blue-600" />
              Learning Roadmap
            </CardTitle>
            <CardDescription>Your personalized path to success</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Tabs value={selectedRoadmapView} onValueChange={(v) => setSelectedRoadmapView(v as any)}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="semester">Semester View</TabsTrigger>
                <TabsTrigger value="weekly">This Week</TabsTrigger>
              </TabsList>

              <TabsContent value="semester" className="space-y-3 mt-4">
                {semesterRoadmap.map((sem, idx) => (
                  <Card key={idx} className={`border-2 transition-all ${
                    sem.status === 'completed' ? 'border-green-200 bg-green-50/50' :
                    sem.status === 'in-progress' ? 'border-blue-300 bg-blue-50/50 shadow-md' :
                    'border-gray-200 bg-gray-50/50 opacity-60'
                  }`}>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          sem.status === 'completed' ? 'bg-green-500' :
                          sem.status === 'in-progress' ? 'bg-blue-500 animate-pulse' :
                          'bg-gray-300'
                        }`}>
                          {sem.status === 'completed' && <CheckCircle2 className="w-5 h-5 text-white" />}
                          {sem.status === 'in-progress' && <Play className="w-5 h-5 text-white" />}
                          {sem.status === 'locked' && <Circle className="w-5 h-5 text-gray-500" />}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <h4 className="font-semibold">{sem.semester}</h4>
                            <span className={`text-sm font-bold ${
                              sem.status === 'completed' ? 'text-green-600' :
                              sem.status === 'in-progress' ? 'text-blue-600' :
                              'text-gray-400'
                            }`}>
                              {sem.progress}%
                            </span>
                          </div>
                          <p className="text-xs text-gray-600">
                            {sem.completedMilestones}/{sem.milestones} milestones completed
                          </p>
                        </div>
                      </div>
                      <Progress value={sem.progress} className="h-1.5" />
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="weekly" className="space-y-2 mt-4">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-sm font-medium">Week 4 Progress</p>
                  <Badge variant="outline">{completedTasks}/{weeklyTasks.length} done</Badge>
                </div>
                {weeklyTasks.map((task, idx) => (
                  <Card key={idx} className={`border ${
                    task.status === 'completed' ? 'border-green-200 bg-green-50/50' :
                    task.status === 'in-progress' ? 'border-blue-200 bg-blue-50/50' :
                    'border-gray-200'
                  }`}>
                    <CardContent className="p-3">
                      <div className="flex items-center gap-2 mb-2">
                        {task.status === 'completed' && <CheckCircle2 className="w-4 h-4 text-green-600" />}
                        {task.status === 'in-progress' && <Play className="w-4 h-4 text-blue-600" />}
                        {task.status === 'pending' && <Circle className="w-4 h-4 text-gray-400" />}
                        <span className="text-sm font-medium flex-1">{task.name}</span>
                        <Badge variant="outline" className={`text-xs ${getCategoryColor(task.category)}`}>
                          {task.category}
                        </Badge>
                      </div>
                      {task.status !== 'pending' && (
                        <Progress value={task.progress} className="h-1" />
                      )}
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>

            <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:shadow-lg transition-shadow">
              <ChevronRight className="w-4 h-4 mr-2" />
              View Full Roadmap
            </Button>
          </CardContent>
        </Card>
        </motion.div>
      </div>

      {/* AI Insights & Recommendations */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.95 }}
      >
        <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 hover:shadow-xl transition-all">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <div className="bg-gradient-to-br from-indigo-600 to-purple-600 p-3 rounded-xl">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                AI-Powered Insights
                <Badge className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">Live</Badge>
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white/80 backdrop-blur-sm p-4 rounded-lg border border-indigo-100">
                  <div className="flex items-start gap-2 mb-2">
                    <TrendingUp className="w-5 h-5 text-green-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-sm">Great Progress!</h4>
                      <p className="text-xs text-gray-600 mt-1">
                        You've improved by +8% this month. Keep up the excellent work on DSA practice.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="bg-white/80 backdrop-blur-sm p-4 rounded-lg border border-orange-100">
                  <div className="flex items-start gap-2 mb-2">
                    <Target className="w-5 h-5 text-orange-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-sm">Focus Area</h4>
                      <p className="text-xs text-gray-600 mt-1">
                        Complete System Design module to improve technical skills by 12% and close the gap.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="bg-white/80 backdrop-blur-sm p-4 rounded-lg border border-blue-100">
                  <div className="flex items-start gap-2 mb-2">
                    <Award className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-sm">Next Milestone</h4>
                      <p className="text-xs text-gray-600 mt-1">
                        Complete 30 more LeetCode problems to unlock the Advanced Algorithms module.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      </motion.div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.05 }}
          whileHover={{ scale: 1.05 }}
        >
          <Card className="border-2 border-blue-200 hover:border-blue-400 transition-all cursor-pointer hover:shadow-xl">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <BookOpen className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-semibold mb-2">Continue Learning</h3>
              <p className="text-xs text-gray-600 mb-4">
                Resume your current module and track progress
              </p>
              <Button variant="outline" className="w-full border-blue-600 text-blue-600">
                Resume
              </Button>
            </div>
          </CardContent>
        </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.15 }}
          whileHover={{ scale: 1.05 }}
        >
          <Card className="border-2 border-purple-200 hover:border-purple-400 transition-all cursor-pointer hover:shadow-xl">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <Target className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-semibold mb-2">Practice Problems</h3>
              <p className="text-xs text-gray-600 mb-4">
                Solve curated DSA problems for your level
              </p>
              <Button variant="outline" className="w-full border-purple-600 text-purple-600">
                Start Practice
              </Button>
            </div>
          </CardContent>
        </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.25 }}
          whileHover={{ scale: 1.05 }}
        >
          <Card className="border-2 border-green-200 hover:border-green-400 transition-all cursor-pointer hover:shadow-xl">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="bg-green-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <Award className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-semibold mb-2">Mock Interview</h3>
              <p className="text-xs text-gray-600 mb-4">
                Practice with AI-powered mock interviews
              </p>
              <Button variant="outline" className="w-full border-green-600 text-green-600">
                Schedule
              </Button>
            </div>
          </CardContent>
        </Card>
        </motion.div>
      </div>
    </div>
  );
}