import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { TrendingUp, TrendingDown, Users, Award, Code, BookOpen, Target } from 'lucide-react';
import { motion } from 'motion/react';

export function WeeklyComparison() {
  const comparisonStats = [
    {
      metric: 'Problems Solved',
      thisWeek: 23,
      lastWeek: 18,
      icon: Code,
      color: 'blue',
      unit: 'problems'
    },
    {
      metric: 'Study Hours',
      thisWeek: 15,
      lastWeek: 12,
      icon: BookOpen,
      color: 'purple',
      unit: 'hours'
    },
    {
      metric: 'Practice Tests',
      thisWeek: 4,
      lastWeek: 5,
      icon: Target,
      color: 'green',
      unit: 'tests'
    },
    {
      metric: 'Rank Position',
      thisWeek: 47,
      lastWeek: 52,
      icon: Award,
      color: 'orange',
      unit: 'rank',
      inverse: true // lower is better
    },
  ];

  const getColorClasses = (color: string) => {
    const colors: Record<string, any> = {
      blue: {
        bg: 'bg-blue-50',
        border: 'border-blue-200',
        icon: 'bg-blue-100 text-blue-600',
        text: 'text-blue-600',
        gradient: 'from-blue-500 to-blue-600'
      },
      purple: {
        bg: 'bg-purple-50',
        border: 'border-purple-200',
        icon: 'bg-purple-100 text-purple-600',
        text: 'text-purple-600',
        gradient: 'from-purple-500 to-purple-600'
      },
      green: {
        bg: 'bg-green-50',
        border: 'border-green-200',
        icon: 'bg-green-100 text-green-600',
        text: 'text-green-600',
        gradient: 'from-green-500 to-green-600'
      },
      orange: {
        bg: 'bg-orange-50',
        border: 'border-orange-200',
        icon: 'bg-orange-100 text-orange-600',
        text: 'text-orange-600',
        gradient: 'from-orange-500 to-orange-600'
      },
    };
    return colors[color];
  };

  const calculateChange = (stat: typeof comparisonStats[0]) => {
    const change = stat.thisWeek - stat.lastWeek;
    const percentChange = Math.round((Math.abs(change) / stat.lastWeek) * 100);
    const isImprovement = stat.inverse ? change < 0 : change > 0;
    return { change, percentChange, isImprovement };
  };

  return (
    <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 to-white">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-indigo-600" />
              Weekly Comparison
            </CardTitle>
            <CardDescription>Compare this week's performance with last week</CardDescription>
          </div>
          <Badge className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
            This Week vs Last Week
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {comparisonStats.map((stat, idx) => {
            const { change, percentChange, isImprovement } = calculateChange(stat);
            const colors = getColorClasses(stat.color);
            const Icon = stat.icon;
            
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * idx }}
              >
                <Card className={`border-2 ${colors.border} ${colors.bg} hover:shadow-lg transition-all cursor-pointer`}>
                  <CardContent className="pt-6">
                    <div className="space-y-3">
                      {/* Icon and Metric Name */}
                      <div className="flex items-center justify-between">
                        <div className={`p-2 rounded-lg ${colors.icon}`}>
                          <Icon className="w-5 h-5" />
                        </div>
                        {change !== 0 && (
                          <Badge 
                            variant="outline" 
                            className={`${
                              isImprovement 
                                ? 'bg-green-50 text-green-700 border-green-300' 
                                : 'bg-red-50 text-red-700 border-red-300'
                            }`}
                          >
                            {isImprovement ? (
                              <TrendingUp className="w-3 h-3 mr-1" />
                            ) : (
                              <TrendingDown className="w-3 h-3 mr-1" />
                            )}
                            {percentChange}%
                          </Badge>
                        )}
                      </div>

                      {/* Metric Name */}
                      <div>
                        <h4 className="text-sm font-medium text-gray-600">{stat.metric}</h4>
                      </div>

                      {/* This Week vs Last Week */}
                      <div className="space-y-2">
                        <div className="flex items-baseline gap-2">
                          <span className={`text-3xl font-bold ${colors.text}`}>
                            {stat.thisWeek}
                          </span>
                          <span className="text-sm text-gray-600">this week</span>
                        </div>
                        
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-gray-600">
                            Last week: {stat.lastWeek} {stat.unit}
                          </span>
                          {change !== 0 && (
                            <span className={`font-semibold ${
                              isImprovement ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {change > 0 ? '+' : ''}{change}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Progress Indicator */}
                      <div className="pt-2 border-t border-gray-200">
                        {isImprovement ? (
                          <div className="flex items-center gap-1 text-xs text-green-600">
                            <TrendingUp className="w-3 h-3" />
                            <span>Great improvement!</span>
                          </div>
                        ) : change < 0 ? (
                          <div className="flex items-center gap-1 text-xs text-red-600">
                            <TrendingDown className="w-3 h-3" />
                            <span>Keep pushing!</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 text-xs text-gray-600">
                            <span>Same as last week</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Overall Summary */}
        <motion.div
          className="mt-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border-2 border-green-200"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <div className="flex items-start gap-3">
            <div className="bg-green-100 p-2 rounded-lg">
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-sm mb-1">Weekly Summary</h4>
              <p className="text-xs text-gray-700">
                You're performing better than last week in{' '}
                <span className="font-bold text-green-700">
                  {comparisonStats.filter(s => calculateChange(s).isImprovement).length} out of {comparisonStats.length}
                </span>{' '}
                metrics. Keep up the excellent work! 🚀
              </p>
            </div>
            <Badge className="bg-white text-green-600 border-green-300">
              <Award className="w-3 h-3 mr-1" />
              On Track
            </Badge>
          </div>
        </motion.div>
      </CardContent>
    </Card>
  );
}
