import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Bell, TrendingUp, Award, Target, CheckCircle2, Zap, Star } from 'lucide-react';
import { motion } from 'motion/react';

export function RecentUpdates() {
  const updates = [
    {
      id: 1,
      type: 'achievement',
      icon: Award,
      title: 'New Achievement Unlocked!',
      description: 'You earned the "Week Warrior" badge for maintaining a 7-day streak',
      time: '2 hours ago',
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
      borderColor: 'border-yellow-200'
    },
    {
      id: 2,
      type: 'milestone',
      icon: Target,
      title: 'Milestone Reached',
      description: 'You completed 200+ LeetCode problems. Keep going!',
      time: '5 hours ago',
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200'
    },
    {
      id: 3,
      type: 'improvement',
      icon: TrendingUp,
      title: 'Performance Improved',
      description: 'Your score increased by 5 points this week',
      time: '1 day ago',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200'
    },
    {
      id: 4,
      type: 'goal',
      icon: CheckCircle2,
      title: 'Daily Goal Completed',
      description: 'All daily goals completed for yesterday. Streak maintained!',
      time: '1 day ago',
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200'
    },
  ];

  return (
    <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-white">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-blue-600" />
              Recent Updates
            </CardTitle>
            <CardDescription>Your latest achievements and progress</CardDescription>
          </div>
          <Badge className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
            {updates.length} New
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {updates.map((update, idx) => {
            const Icon = update.icon;
            return (
              <motion.div
                key={update.id}
                className={`p-4 rounded-lg border-2 ${update.borderColor} ${update.bgColor} hover:shadow-md transition-all cursor-pointer relative overflow-hidden group`}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 * idx }}
                whileHover={{ scale: 1.02 }}
              >
                {/* Animated background gradient on hover */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-0 group-hover:opacity-20 transition-opacity duration-300" />
                
                <div className="relative flex items-start gap-3">
                  <div className={`p-2 rounded-lg ${update.bgColor} ring-2 ring-white`}>
                    <Icon className={`w-5 h-5 ${update.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <h4 className="font-semibold text-sm">{update.title}</h4>
                      <span className="text-xs text-gray-500 whitespace-nowrap">{update.time}</span>
                    </div>
                    <p className="text-xs text-gray-700">{update.description}</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* View All Button */}
        <motion.button
          className="w-full mt-4 py-2 text-sm font-medium text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          View All Updates →
        </motion.button>
      </CardContent>
    </Card>
  );
}
