import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Textarea } from '@/app/components/ui/textarea';
import { Progress } from '@/app/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/app/components/ui/dialog';
import { Users, TrendingUp, AlertTriangle, CheckCircle2, Star } from 'lucide-react';
import { Slider } from '@/app/components/ui/slider';

export function MentorDashboard() {
  const [activeTab, setActiveTab] = useState('overview');

  const students = [
    {
      id: 1,
      name: 'Raj Kumar',
      semester: 3,
      company: 'Google',
      role: 'Software Engineer',
      speedometerScore: 73,
      academicConsistency: 4.2,
      learningDiscipline: 4.0,
      communication: 3.8,
      overallRating: 4.0,
      status: 'good',
      lastReview: '2026-01-15',
    },
    {
      id: 2,
      name: 'Priya Sharma',
      semester: 3,
      company: 'Microsoft',
      role: 'Full Stack Developer',
      speedometerScore: 85,
      academicConsistency: 4.8,
      learningDiscipline: 4.5,
      communication: 4.6,
      overallRating: 4.6,
      status: 'excellent',
      lastReview: '2026-01-16',
    },
    {
      id: 3,
      name: 'Neha Singh',
      semester: 3,
      company: 'Google',
      role: 'Software Engineer',
      speedometerScore: 58,
      academicConsistency: 3.2,
      learningDiscipline: 3.0,
      communication: 3.5,
      overallRating: 3.2,
      status: 'needs-attention',
      lastReview: '2026-01-17',
    },
  ];

  const MentorEvaluationDialog = ({ student }: any) => {
    const [academicConsistency, setAcademicConsistency] = useState(student.academicConsistency);
    const [learningDiscipline, setLearningDiscipline] = useState(student.learningDiscipline);
    const [communication, setCommunication] = useState(student.communication);
    const [feedback, setFeedback] = useState('');

    const overallRating = ((academicConsistency + learningDiscipline + communication) / 3).toFixed(1);

    return (
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Mentor Evaluation - {student.name}</DialogTitle>
          <DialogDescription>
            Provide behavioral and academic assessment
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <Card className="bg-blue-50">
            <CardContent className="pt-6">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Career Track</p>
                  <p className="font-semibold">{student.company} - {student.role}</p>
                </div>
                <div>
                  <p className="text-gray-600">Current Performance</p>
                  <p className="font-semibold">{student.speedometerScore}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Evaluation Criteria */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Behavioral Assessment</CardTitle>
              <CardDescription>Rate student on a scale of 1-5</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-medium text-sm">Academic Consistency</label>
                  <span className="text-lg font-bold text-blue-600">{academicConsistency.toFixed(1)}</span>
                </div>
                <Slider
                  value={[academicConsistency]}
                  onValueChange={([val]) => setAcademicConsistency(val)}
                  min={1}
                  max={5}
                  step={0.1}
                  className="w-full"
                />
                <p className="text-xs text-gray-600">
                  Regular class attendance, assignment submission, exam performance
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-medium text-sm">Learning Discipline</label>
                  <span className="text-lg font-bold text-blue-600">{learningDiscipline.toFixed(1)}</span>
                </div>
                <Slider
                  value={[learningDiscipline]}
                  onValueChange={([val]) => setLearningDiscipline(val)}
                  min={1}
                  max={5}
                  step={0.1}
                  className="w-full"
                />
                <p className="text-xs text-gray-600">
                  Self-study habits, curiosity, willingness to learn new concepts
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-medium text-sm">Communication Skills</label>
                  <span className="text-lg font-bold text-blue-600">{communication.toFixed(1)}</span>
                </div>
                <Slider
                  value={[communication]}
                  onValueChange={([val]) => setCommunication(val)}
                  min={1}
                  max={5}
                  step={0.1}
                  className="w-full"
                />
                <p className="text-xs text-gray-600">
                  Verbal expression, written communication, presentation skills
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Overall Rating */}
          <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200">
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-2">Overall Mentor Rating</p>
                <div className="text-4xl font-bold text-purple-600 mb-2">{overallRating} / 5.0</div>
                <div className="flex items-center justify-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-5 h-5 ${
                        star <= Math.round(parseFloat(overallRating))
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Feedback */}
          <div className="space-y-2">
            <label className="block text-sm font-medium">Mentor Feedback & Recommendations</label>
            <Textarea
              placeholder="Provide detailed feedback on student's behavior, strengths, areas for improvement..."
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              rows={5}
            />
          </div>

          {/* Submit */}
          <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600">
            Submit Evaluation
          </Button>
        </div>
      </DialogContent>
    );
  };

  const getStatusBadge = (status: string) => {
    if (status === 'excellent') return { label: 'Excellent', color: 'bg-green-600' };
    if (status === 'good') return { label: 'Good Progress', color: 'bg-blue-600' };
    return { label: 'Needs Attention', color: 'bg-orange-600' };
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Mentor Dashboard</h2>
        <p className="text-gray-600">Monitor and guide student performance with behavioral assessments</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 lg:w-auto lg:inline-grid">
          <TabsTrigger value="overview">
            <Users className="w-4 h-4 mr-2" />
            My Students
          </TabsTrigger>
          <TabsTrigger value="alerts">
            <AlertTriangle className="w-4 h-4 mr-2" />
            Alerts & Interventions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{students.length}</div>
                  <div className="text-xs text-gray-600">Total Students</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold">
                    {students.filter(s => s.status === 'excellent' || s.status === 'good').length}
                  </div>
                  <div className="text-xs text-gray-600">On Track</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <AlertTriangle className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold">
                    {students.filter(s => s.status === 'needs-attention').length}
                  </div>
                  <div className="text-xs text-gray-600">Need Support</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <Star className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold">
                    {(students.reduce((sum, s) => sum + s.overallRating, 0) / students.length).toFixed(1)}
                  </div>
                  <div className="text-xs text-gray-600">Avg Rating</div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Student List */}
          <Card className="border-2">
            <CardHeader>
              <CardTitle>Student Performance Overview</CardTitle>
              <CardDescription>Monitor and evaluate your mentees</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {students.map((student) => {
                const statusBadge = getStatusBadge(student.status);
                return (
                  <Card key={student.id} className="border-2 hover:border-blue-300 transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 flex-1">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-purple-600">{student.speedometerScore}</div>
                            <div className="text-xs text-gray-600">Score</div>
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-semibold">{student.name}</h3>
                              <Badge variant="outline" className="text-xs">Sem {student.semester}</Badge>
                            </div>
                            <p className="text-sm text-gray-600 mb-2">
                              {student.company} - {student.role}
                            </p>
                            <div className="grid grid-cols-3 gap-3 text-xs">
                              <div>
                                <span className="text-gray-600">Academic:</span>
                                <span className="font-semibold ml-1">{student.academicConsistency}/5</span>
                              </div>
                              <div>
                                <span className="text-gray-600">Discipline:</span>
                                <span className="font-semibold ml-1">{student.learningDiscipline}/5</span>
                              </div>
                              <div>
                                <span className="text-gray-600">Communication:</span>
                                <span className="font-semibold ml-1">{student.communication}/5</span>
                              </div>
                            </div>
                            <div className="mt-2">
                              <div className="flex items-center gap-2">
                                <Progress value={student.overallRating * 20} className="h-1 flex-1" />
                                <span className="text-xs font-medium">{student.overallRating}/5</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge className={`${statusBadge.color} text-white`}>
                            {statusBadge.label}
                          </Badge>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm">
                                Evaluate
                              </Button>
                            </DialogTrigger>
                            <MentorEvaluationDialog student={student} />
                          </Dialog>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-6">
          <Card className="border-2 border-orange-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600" />
                Students Requiring Intervention
              </CardTitle>
              <CardDescription>Students flagged by the system for mentor intervention</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {students.filter(s => s.status === 'needs-attention').map((student) => (
                <Card key={student.id} className="bg-orange-50 border-orange-200">
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold">{student.name}</h3>
                        <Badge variant="destructive">Action Required</Badge>
                      </div>
                      <div className="bg-white p-3 rounded-lg border text-sm">
                        <p className="font-medium text-red-600 mb-2">⚠️ Performance Below Threshold</p>
                        <ul className="list-disc list-inside text-gray-700 space-y-1 text-xs">
                          <li>Speedometer score: {student.speedometerScore}% (Below 70%)</li>
                          <li>3 consecutive weeks of declining performance</li>
                          <li>Multiple roadmap tasks overdue</li>
                          <li>Recommended: One-on-one counseling session</li>
                        </ul>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" className="flex-1">Schedule Meeting</Button>
                        <Button size="sm" variant="outline" className="flex-1">Provide Feedback</Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
