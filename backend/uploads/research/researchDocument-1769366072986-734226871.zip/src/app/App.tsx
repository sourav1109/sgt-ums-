import React, { useState } from 'react';
import { Card } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { LoginScreen } from '@/app/components/LoginScreen';
import { StudentDashboard } from '@/app/components/StudentDashboard';
import { PlacementCoordinatorDashboard } from '@/app/components/PlacementCoordinatorDashboard';
import { MentorDashboard } from '@/app/components/MentorDashboard';
import { SuperAdminDashboard } from '@/app/components/SuperAdminDashboard';
import { GraduationCap, LogOut } from 'lucide-react';

export type UserRole = 'student' | 'placement-coordinator' | 'mentor' | 'super-admin' | null;

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserRole>(null);
  const [userName, setUserName] = useState<string>('');

  const handleLogin = (role: UserRole, name: string) => {
    setCurrentUser(role);
    setUserName(name);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setUserName('');
  };

  if (!currentUser) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-blue-600 to-purple-600 p-2 rounded-lg">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Career Guidance System</h1>
                <p className="text-xs text-gray-600">AI-Powered Career Planning</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{userName}</p>
                <p className="text-xs text-gray-600 capitalize">{currentUser?.replace('-', ' ')}</p>
              </div>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        {currentUser === 'student' && <StudentDashboard />}
        {currentUser === 'placement-coordinator' && <PlacementCoordinatorDashboard />}
        {currentUser === 'mentor' && <MentorDashboard />}
        {currentUser === 'super-admin' && <SuperAdminDashboard />}
      </main>
    </div>
  );
}
